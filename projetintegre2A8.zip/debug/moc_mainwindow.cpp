/****************************************************************************
** Meta object code from reading C++ file 'mainwindow.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.9.9)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../mainwindow.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'mainwindow.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.9.9. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_MainWindow_t {
    QByteArrayData data[113];
    char stringdata0[2793];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_MainWindow_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_MainWindow_t qt_meta_stringdata_MainWindow = {
    {
QT_MOC_LITERAL(0, 0, 10), // "MainWindow"
QT_MOC_LITERAL(1, 11, 21), // "on_pushButton_clicked"
QT_MOC_LITERAL(2, 33, 0), // ""
QT_MOC_LITERAL(3, 34, 23), // "on_pushButton_2_clicked"
QT_MOC_LITERAL(4, 58, 23), // "on_pushButton_4_clicked"
QT_MOC_LITERAL(5, 82, 23), // "on_pushButton_7_clicked"
QT_MOC_LITERAL(6, 106, 23), // "on_pushButton_8_clicked"
QT_MOC_LITERAL(7, 130, 24), // "on_pushButton_11_clicked"
QT_MOC_LITERAL(8, 155, 24), // "on_pushButton_12_clicked"
QT_MOC_LITERAL(9, 180, 24), // "on_pushButton_13_clicked"
QT_MOC_LITERAL(10, 205, 23), // "on_pushButton_3_clicked"
QT_MOC_LITERAL(11, 229, 23), // "on_pushButton_6_clicked"
QT_MOC_LITERAL(12, 253, 31), // "on_comboBox_currentIndexChanged"
QT_MOC_LITERAL(13, 285, 5), // "index"
QT_MOC_LITERAL(14, 291, 24), // "on_pushButton_15_clicked"
QT_MOC_LITERAL(15, 316, 24), // "on_pushButton_16_clicked"
QT_MOC_LITERAL(16, 341, 24), // "on_pushButton_17_clicked"
QT_MOC_LITERAL(17, 366, 31), // "on_lineEdit_cherche_textChanged"
QT_MOC_LITERAL(18, 398, 4), // "arg1"
QT_MOC_LITERAL(19, 403, 35), // "on_lineEdit_cherche_cin_textC..."
QT_MOC_LITERAL(20, 439, 29), // "on_pushButton_connect_clicked"
QT_MOC_LITERAL(21, 469, 23), // "on_pushButton_9_clicked"
QT_MOC_LITERAL(22, 493, 24), // "on_pushButton_10_clicked"
QT_MOC_LITERAL(23, 518, 24), // "on_pushButton_14_clicked"
QT_MOC_LITERAL(24, 543, 17), // "on_logout_clicked"
QT_MOC_LITERAL(25, 561, 38), // "on_lineEdit_cherche_number_te..."
QT_MOC_LITERAL(26, 600, 15), // "on_chat_clicked"
QT_MOC_LITERAL(27, 616, 24), // "on_pushButton_24_clicked"
QT_MOC_LITERAL(28, 641, 16), // "on_combo_clicked"
QT_MOC_LITERAL(29, 658, 18), // "on_valider_clicked"
QT_MOC_LITERAL(30, 677, 28), // "on_pushButton_delete_clicked"
QT_MOC_LITERAL(31, 706, 17), // "on_update_clicked"
QT_MOC_LITERAL(32, 724, 39), // "on_comboBox_buyer_3_currentIn..."
QT_MOC_LITERAL(33, 764, 26), // "on_sort_name_buyer_clicked"
QT_MOC_LITERAL(34, 791, 29), // "on_sort_request_buyer_clicked"
QT_MOC_LITERAL(35, 821, 28), // "on_sort_adress_buyer_clicked"
QT_MOC_LITERAL(36, 850, 24), // "on_sort_id_buyer_clicked"
QT_MOC_LITERAL(37, 875, 26), // "on_chercher_id_textChanged"
QT_MOC_LITERAL(38, 902, 28), // "on_chercher_name_textChanged"
QT_MOC_LITERAL(39, 931, 31), // "on_chercher_request_textChanged"
QT_MOC_LITERAL(40, 963, 19), // "on_mailling_clicked"
QT_MOC_LITERAL(41, 983, 24), // "on_inserer_photo_clicked"
QT_MOC_LITERAL(42, 1008, 20), // "on_recommand_clicked"
QT_MOC_LITERAL(43, 1029, 24), // "on_pushButton_23_clicked"
QT_MOC_LITERAL(44, 1054, 18), // "on_photo_2_clicked"
QT_MOC_LITERAL(45, 1073, 17), // "on_add_ag_clicked"
QT_MOC_LITERAL(46, 1091, 19), // "on_pb_add_2_clicked"
QT_MOC_LITERAL(47, 1111, 24), // "on_pushButton_20_clicked"
QT_MOC_LITERAL(48, 1136, 22), // "on_pd_update_2_clicked"
QT_MOC_LITERAL(49, 1159, 33), // "on_comboBox_5_currentIndexCha..."
QT_MOC_LITERAL(50, 1193, 22), // "on_pb_delete_2_clicked"
QT_MOC_LITERAL(51, 1216, 28), // "on_numtosearch_2_textChanged"
QT_MOC_LITERAL(52, 1245, 29), // "on_typetosearch_2_textChanged"
QT_MOC_LITERAL(53, 1275, 34), // "on_startdatetosearch_2_textCh..."
QT_MOC_LITERAL(54, 1310, 21), // "on_sortById_2_clicked"
QT_MOC_LITERAL(55, 1332, 23), // "on_sortByType_2_clicked"
QT_MOC_LITERAL(56, 1356, 24), // "on_sortByPrice_2_clicked"
QT_MOC_LITERAL(57, 1381, 20), // "on_pb_read_2_clicked"
QT_MOC_LITERAL(58, 1402, 29), // "on_tabWidget_3_currentChanged"
QT_MOC_LITERAL(59, 1432, 23), // "on_pb_history_2_clicked"
QT_MOC_LITERAL(60, 1456, 21), // "on_pbExport_2_clicked"
QT_MOC_LITERAL(61, 1478, 24), // "on_pushButton_19_clicked"
QT_MOC_LITERAL(62, 1503, 16), // "on_add_2_clicked"
QT_MOC_LITERAL(63, 1520, 24), // "on_pushButton_42_clicked"
QT_MOC_LITERAL(64, 1545, 19), // "on_update_3_clicked"
QT_MOC_LITERAL(65, 1565, 22), // "on_supprimer_2_clicked"
QT_MOC_LITERAL(66, 1588, 19), // "on_sort_par_clicked"
QT_MOC_LITERAL(67, 1608, 21), // "on_sort_par_2_clicked"
QT_MOC_LITERAL(68, 1630, 21), // "on_sort_par_3_clicked"
QT_MOC_LITERAL(69, 1652, 25), // "on_chercher_4_textChanged"
QT_MOC_LITERAL(70, 1678, 25), // "on_chercher_5_textChanged"
QT_MOC_LITERAL(71, 1704, 22), // "on_tri_stock_7_clicked"
QT_MOC_LITERAL(72, 1727, 22), // "on_tri_stock_8_clicked"
QT_MOC_LITERAL(73, 1750, 15), // "on_ig_2_clicked"
QT_MOC_LITERAL(74, 1766, 15), // "on_fb_2_clicked"
QT_MOC_LITERAL(75, 1782, 21), // "on_linkedin_2_clicked"
QT_MOC_LITERAL(76, 1804, 22), // "on_tri_stock_9_clicked"
QT_MOC_LITERAL(77, 1827, 23), // "on_tri_stock_10_clicked"
QT_MOC_LITERAL(78, 1851, 24), // "on_pushButton_18_clicked"
QT_MOC_LITERAL(79, 1876, 17), // "on_pb_Add_clicked"
QT_MOC_LITERAL(80, 1894, 18), // "on_pb_supp_clicked"
QT_MOC_LITERAL(81, 1913, 37), // "on_comboBox_agent_currentInde..."
QT_MOC_LITERAL(82, 1951, 19), // "on_pb_modif_clicked"
QT_MOC_LITERAL(83, 1971, 21), // "on_Sort_by_id_clicked"
QT_MOC_LITERAL(84, 1993, 23), // "on_Sort_by_name_clicked"
QT_MOC_LITERAL(85, 2017, 25), // "on_Sort_by_adress_clicked"
QT_MOC_LITERAL(86, 2043, 26), // "on_search_id_2_textChanged"
QT_MOC_LITERAL(87, 2070, 28), // "on_search_name_2_textChanged"
QT_MOC_LITERAL(88, 2099, 30), // "on_search_adress_2_textChanged"
QT_MOC_LITERAL(89, 2130, 15), // "on_todo_clicked"
QT_MOC_LITERAL(90, 2146, 22), // "on_generer_pdf_clicked"
QT_MOC_LITERAL(91, 2169, 37), // "on_pushButton_database_insert..."
QT_MOC_LITERAL(92, 2207, 24), // "on_pushButton_21_clicked"
QT_MOC_LITERAL(93, 2232, 24), // "on_pushButton_29_clicked"
QT_MOC_LITERAL(94, 2257, 24), // "on_pushButton_30_clicked"
QT_MOC_LITERAL(95, 2282, 22), // "on_update_prop_clicked"
QT_MOC_LITERAL(96, 2305, 33), // "on_comboBox_7_currentIndexCha..."
QT_MOC_LITERAL(97, 2339, 33), // "on_pushButton_delete_prop_cli..."
QT_MOC_LITERAL(98, 2373, 27), // "on_tableView_2_prop_clicked"
QT_MOC_LITERAL(99, 2401, 24), // "on_pushButton_31_clicked"
QT_MOC_LITERAL(100, 2426, 24), // "on_pushButton_32_clicked"
QT_MOC_LITERAL(101, 2451, 24), // "on_pushButton_33_clicked"
QT_MOC_LITERAL(102, 2476, 24), // "on_pushButton_34_clicked"
QT_MOC_LITERAL(103, 2501, 24), // "on_pushButton_35_clicked"
QT_MOC_LITERAL(104, 2526, 24), // "on_pushButton_36_clicked"
QT_MOC_LITERAL(105, 2551, 40), // "on_lineEdit_cherche_function_..."
QT_MOC_LITERAL(106, 2592, 39), // "on_lineEdit_cherche_function_..."
QT_MOC_LITERAL(107, 2632, 17), // "on_chat_2_clicked"
QT_MOC_LITERAL(108, 2650, 38), // "on_pushButton_security_arduin..."
QT_MOC_LITERAL(109, 2689, 24), // "on_pushButton_27_clicked"
QT_MOC_LITERAL(110, 2714, 40), // "on_pushButton_security_arduin..."
QT_MOC_LITERAL(111, 2755, 24), // "on_pushButton_28_clicked"
QT_MOC_LITERAL(112, 2780, 12) // "update_label"

    },
    "MainWindow\0on_pushButton_clicked\0\0"
    "on_pushButton_2_clicked\0on_pushButton_4_clicked\0"
    "on_pushButton_7_clicked\0on_pushButton_8_clicked\0"
    "on_pushButton_11_clicked\0"
    "on_pushButton_12_clicked\0"
    "on_pushButton_13_clicked\0"
    "on_pushButton_3_clicked\0on_pushButton_6_clicked\0"
    "on_comboBox_currentIndexChanged\0index\0"
    "on_pushButton_15_clicked\0"
    "on_pushButton_16_clicked\0"
    "on_pushButton_17_clicked\0"
    "on_lineEdit_cherche_textChanged\0arg1\0"
    "on_lineEdit_cherche_cin_textChanged\0"
    "on_pushButton_connect_clicked\0"
    "on_pushButton_9_clicked\0"
    "on_pushButton_10_clicked\0"
    "on_pushButton_14_clicked\0on_logout_clicked\0"
    "on_lineEdit_cherche_number_textChanged\0"
    "on_chat_clicked\0on_pushButton_24_clicked\0"
    "on_combo_clicked\0on_valider_clicked\0"
    "on_pushButton_delete_clicked\0"
    "on_update_clicked\0"
    "on_comboBox_buyer_3_currentIndexChanged\0"
    "on_sort_name_buyer_clicked\0"
    "on_sort_request_buyer_clicked\0"
    "on_sort_adress_buyer_clicked\0"
    "on_sort_id_buyer_clicked\0"
    "on_chercher_id_textChanged\0"
    "on_chercher_name_textChanged\0"
    "on_chercher_request_textChanged\0"
    "on_mailling_clicked\0on_inserer_photo_clicked\0"
    "on_recommand_clicked\0on_pushButton_23_clicked\0"
    "on_photo_2_clicked\0on_add_ag_clicked\0"
    "on_pb_add_2_clicked\0on_pushButton_20_clicked\0"
    "on_pd_update_2_clicked\0"
    "on_comboBox_5_currentIndexChanged\0"
    "on_pb_delete_2_clicked\0"
    "on_numtosearch_2_textChanged\0"
    "on_typetosearch_2_textChanged\0"
    "on_startdatetosearch_2_textChanged\0"
    "on_sortById_2_clicked\0on_sortByType_2_clicked\0"
    "on_sortByPrice_2_clicked\0on_pb_read_2_clicked\0"
    "on_tabWidget_3_currentChanged\0"
    "on_pb_history_2_clicked\0on_pbExport_2_clicked\0"
    "on_pushButton_19_clicked\0on_add_2_clicked\0"
    "on_pushButton_42_clicked\0on_update_3_clicked\0"
    "on_supprimer_2_clicked\0on_sort_par_clicked\0"
    "on_sort_par_2_clicked\0on_sort_par_3_clicked\0"
    "on_chercher_4_textChanged\0"
    "on_chercher_5_textChanged\0"
    "on_tri_stock_7_clicked\0on_tri_stock_8_clicked\0"
    "on_ig_2_clicked\0on_fb_2_clicked\0"
    "on_linkedin_2_clicked\0on_tri_stock_9_clicked\0"
    "on_tri_stock_10_clicked\0"
    "on_pushButton_18_clicked\0on_pb_Add_clicked\0"
    "on_pb_supp_clicked\0"
    "on_comboBox_agent_currentIndexChanged\0"
    "on_pb_modif_clicked\0on_Sort_by_id_clicked\0"
    "on_Sort_by_name_clicked\0"
    "on_Sort_by_adress_clicked\0"
    "on_search_id_2_textChanged\0"
    "on_search_name_2_textChanged\0"
    "on_search_adress_2_textChanged\0"
    "on_todo_clicked\0on_generer_pdf_clicked\0"
    "on_pushButton_database_insert_clicked\0"
    "on_pushButton_21_clicked\0"
    "on_pushButton_29_clicked\0"
    "on_pushButton_30_clicked\0"
    "on_update_prop_clicked\0"
    "on_comboBox_7_currentIndexChanged\0"
    "on_pushButton_delete_prop_clicked\0"
    "on_tableView_2_prop_clicked\0"
    "on_pushButton_31_clicked\0"
    "on_pushButton_32_clicked\0"
    "on_pushButton_33_clicked\0"
    "on_pushButton_34_clicked\0"
    "on_pushButton_35_clicked\0"
    "on_pushButton_36_clicked\0"
    "on_lineEdit_cherche_function_textChanged\0"
    "on_lineEdit_cherche_function_textEdited\0"
    "on_chat_2_clicked\0"
    "on_pushButton_security_arduino_clicked\0"
    "on_pushButton_27_clicked\0"
    "on_pushButton_security_arduino_2_clicked\0"
    "on_pushButton_28_clicked\0update_label"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_MainWindow[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
     110,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    0,  564,    2, 0x08 /* Private */,
       3,    0,  565,    2, 0x08 /* Private */,
       4,    0,  566,    2, 0x08 /* Private */,
       5,    0,  567,    2, 0x08 /* Private */,
       6,    0,  568,    2, 0x08 /* Private */,
       7,    0,  569,    2, 0x08 /* Private */,
       8,    0,  570,    2, 0x08 /* Private */,
       9,    0,  571,    2, 0x08 /* Private */,
      10,    0,  572,    2, 0x08 /* Private */,
      11,    0,  573,    2, 0x08 /* Private */,
      12,    1,  574,    2, 0x08 /* Private */,
      14,    0,  577,    2, 0x08 /* Private */,
      15,    0,  578,    2, 0x08 /* Private */,
      16,    0,  579,    2, 0x08 /* Private */,
      17,    1,  580,    2, 0x08 /* Private */,
      19,    1,  583,    2, 0x08 /* Private */,
      20,    0,  586,    2, 0x08 /* Private */,
      21,    0,  587,    2, 0x08 /* Private */,
      22,    0,  588,    2, 0x08 /* Private */,
      23,    0,  589,    2, 0x08 /* Private */,
      24,    0,  590,    2, 0x08 /* Private */,
      25,    1,  591,    2, 0x08 /* Private */,
      26,    0,  594,    2, 0x08 /* Private */,
      27,    0,  595,    2, 0x08 /* Private */,
      28,    0,  596,    2, 0x08 /* Private */,
      29,    0,  597,    2, 0x08 /* Private */,
      30,    0,  598,    2, 0x08 /* Private */,
      31,    0,  599,    2, 0x08 /* Private */,
      32,    1,  600,    2, 0x08 /* Private */,
      33,    0,  603,    2, 0x08 /* Private */,
      34,    0,  604,    2, 0x08 /* Private */,
      35,    0,  605,    2, 0x08 /* Private */,
      36,    0,  606,    2, 0x08 /* Private */,
      37,    1,  607,    2, 0x08 /* Private */,
      38,    1,  610,    2, 0x08 /* Private */,
      39,    1,  613,    2, 0x08 /* Private */,
      40,    0,  616,    2, 0x08 /* Private */,
      41,    0,  617,    2, 0x08 /* Private */,
      42,    0,  618,    2, 0x08 /* Private */,
      43,    0,  619,    2, 0x08 /* Private */,
      44,    0,  620,    2, 0x08 /* Private */,
      45,    0,  621,    2, 0x08 /* Private */,
      46,    0,  622,    2, 0x08 /* Private */,
      47,    0,  623,    2, 0x08 /* Private */,
      48,    0,  624,    2, 0x08 /* Private */,
      49,    1,  625,    2, 0x08 /* Private */,
      49,    1,  628,    2, 0x08 /* Private */,
      50,    0,  631,    2, 0x08 /* Private */,
      51,    1,  632,    2, 0x08 /* Private */,
      52,    1,  635,    2, 0x08 /* Private */,
      53,    1,  638,    2, 0x08 /* Private */,
      54,    0,  641,    2, 0x08 /* Private */,
      55,    0,  642,    2, 0x08 /* Private */,
      56,    0,  643,    2, 0x08 /* Private */,
      57,    0,  644,    2, 0x08 /* Private */,
      58,    1,  645,    2, 0x08 /* Private */,
      59,    0,  648,    2, 0x08 /* Private */,
      60,    0,  649,    2, 0x08 /* Private */,
      61,    0,  650,    2, 0x08 /* Private */,
      62,    0,  651,    2, 0x08 /* Private */,
      63,    0,  652,    2, 0x08 /* Private */,
      64,    0,  653,    2, 0x08 /* Private */,
      65,    0,  654,    2, 0x08 /* Private */,
      66,    0,  655,    2, 0x08 /* Private */,
      67,    0,  656,    2, 0x08 /* Private */,
      68,    0,  657,    2, 0x08 /* Private */,
      69,    1,  658,    2, 0x08 /* Private */,
      70,    1,  661,    2, 0x08 /* Private */,
      71,    0,  664,    2, 0x08 /* Private */,
      72,    0,  665,    2, 0x08 /* Private */,
      73,    0,  666,    2, 0x08 /* Private */,
      74,    0,  667,    2, 0x08 /* Private */,
      75,    0,  668,    2, 0x08 /* Private */,
      76,    0,  669,    2, 0x08 /* Private */,
      77,    0,  670,    2, 0x08 /* Private */,
      78,    0,  671,    2, 0x08 /* Private */,
      79,    0,  672,    2, 0x08 /* Private */,
      80,    0,  673,    2, 0x08 /* Private */,
      81,    1,  674,    2, 0x08 /* Private */,
      82,    0,  677,    2, 0x08 /* Private */,
      83,    0,  678,    2, 0x08 /* Private */,
      84,    0,  679,    2, 0x08 /* Private */,
      85,    0,  680,    2, 0x08 /* Private */,
      86,    1,  681,    2, 0x08 /* Private */,
      87,    1,  684,    2, 0x08 /* Private */,
      88,    1,  687,    2, 0x08 /* Private */,
      89,    0,  690,    2, 0x08 /* Private */,
      90,    0,  691,    2, 0x08 /* Private */,
      91,    0,  692,    2, 0x08 /* Private */,
      92,    0,  693,    2, 0x08 /* Private */,
      93,    0,  694,    2, 0x08 /* Private */,
      94,    0,  695,    2, 0x08 /* Private */,
      95,    0,  696,    2, 0x08 /* Private */,
      96,    1,  697,    2, 0x08 /* Private */,
      97,    0,  700,    2, 0x08 /* Private */,
      98,    1,  701,    2, 0x08 /* Private */,
      99,    0,  704,    2, 0x08 /* Private */,
     100,    0,  705,    2, 0x08 /* Private */,
     101,    0,  706,    2, 0x08 /* Private */,
     102,    0,  707,    2, 0x08 /* Private */,
     103,    0,  708,    2, 0x08 /* Private */,
     104,    0,  709,    2, 0x08 /* Private */,
     105,    1,  710,    2, 0x08 /* Private */,
     106,    1,  713,    2, 0x08 /* Private */,
     107,    0,  716,    2, 0x08 /* Private */,
     108,    0,  717,    2, 0x08 /* Private */,
     109,    0,  718,    2, 0x08 /* Private */,
     110,    0,  719,    2, 0x08 /* Private */,
     111,    0,  720,    2, 0x08 /* Private */,
     112,    0,  721,    2, 0x08 /* Private */,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,   13,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString,   18,
    QMetaType::Void, QMetaType::QString,   18,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString,   18,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,   13,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString,   18,
    QMetaType::Void, QMetaType::QString,   18,
    QMetaType::Void, QMetaType::QString,   18,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString,   18,
    QMetaType::Void, QMetaType::Int,   13,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString,   18,
    QMetaType::Void, QMetaType::QString,   18,
    QMetaType::Void, QMetaType::QString,   18,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,   13,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString,   18,
    QMetaType::Void, QMetaType::QString,   18,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,   13,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString,   18,
    QMetaType::Void, QMetaType::QString,   18,
    QMetaType::Void, QMetaType::QString,   18,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,   13,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QModelIndex,   13,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString,   18,
    QMetaType::Void, QMetaType::QString,   18,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

void MainWindow::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        MainWindow *_t = static_cast<MainWindow *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->on_pushButton_clicked(); break;
        case 1: _t->on_pushButton_2_clicked(); break;
        case 2: _t->on_pushButton_4_clicked(); break;
        case 3: _t->on_pushButton_7_clicked(); break;
        case 4: _t->on_pushButton_8_clicked(); break;
        case 5: _t->on_pushButton_11_clicked(); break;
        case 6: _t->on_pushButton_12_clicked(); break;
        case 7: _t->on_pushButton_13_clicked(); break;
        case 8: _t->on_pushButton_3_clicked(); break;
        case 9: _t->on_pushButton_6_clicked(); break;
        case 10: _t->on_comboBox_currentIndexChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 11: _t->on_pushButton_15_clicked(); break;
        case 12: _t->on_pushButton_16_clicked(); break;
        case 13: _t->on_pushButton_17_clicked(); break;
        case 14: _t->on_lineEdit_cherche_textChanged((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 15: _t->on_lineEdit_cherche_cin_textChanged((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 16: _t->on_pushButton_connect_clicked(); break;
        case 17: _t->on_pushButton_9_clicked(); break;
        case 18: _t->on_pushButton_10_clicked(); break;
        case 19: _t->on_pushButton_14_clicked(); break;
        case 20: _t->on_logout_clicked(); break;
        case 21: _t->on_lineEdit_cherche_number_textChanged((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 22: _t->on_chat_clicked(); break;
        case 23: _t->on_pushButton_24_clicked(); break;
        case 24: _t->on_combo_clicked(); break;
        case 25: _t->on_valider_clicked(); break;
        case 26: _t->on_pushButton_delete_clicked(); break;
        case 27: _t->on_update_clicked(); break;
        case 28: _t->on_comboBox_buyer_3_currentIndexChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 29: _t->on_sort_name_buyer_clicked(); break;
        case 30: _t->on_sort_request_buyer_clicked(); break;
        case 31: _t->on_sort_adress_buyer_clicked(); break;
        case 32: _t->on_sort_id_buyer_clicked(); break;
        case 33: _t->on_chercher_id_textChanged((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 34: _t->on_chercher_name_textChanged((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 35: _t->on_chercher_request_textChanged((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 36: _t->on_mailling_clicked(); break;
        case 37: _t->on_inserer_photo_clicked(); break;
        case 38: _t->on_recommand_clicked(); break;
        case 39: _t->on_pushButton_23_clicked(); break;
        case 40: _t->on_photo_2_clicked(); break;
        case 41: _t->on_add_ag_clicked(); break;
        case 42: _t->on_pb_add_2_clicked(); break;
        case 43: _t->on_pushButton_20_clicked(); break;
        case 44: _t->on_pd_update_2_clicked(); break;
        case 45: _t->on_comboBox_5_currentIndexChanged((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 46: _t->on_comboBox_5_currentIndexChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 47: _t->on_pb_delete_2_clicked(); break;
        case 48: _t->on_numtosearch_2_textChanged((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 49: _t->on_typetosearch_2_textChanged((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 50: _t->on_startdatetosearch_2_textChanged((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 51: _t->on_sortById_2_clicked(); break;
        case 52: _t->on_sortByType_2_clicked(); break;
        case 53: _t->on_sortByPrice_2_clicked(); break;
        case 54: _t->on_pb_read_2_clicked(); break;
        case 55: _t->on_tabWidget_3_currentChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 56: _t->on_pb_history_2_clicked(); break;
        case 57: _t->on_pbExport_2_clicked(); break;
        case 58: _t->on_pushButton_19_clicked(); break;
        case 59: _t->on_add_2_clicked(); break;
        case 60: _t->on_pushButton_42_clicked(); break;
        case 61: _t->on_update_3_clicked(); break;
        case 62: _t->on_supprimer_2_clicked(); break;
        case 63: _t->on_sort_par_clicked(); break;
        case 64: _t->on_sort_par_2_clicked(); break;
        case 65: _t->on_sort_par_3_clicked(); break;
        case 66: _t->on_chercher_4_textChanged((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 67: _t->on_chercher_5_textChanged((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 68: _t->on_tri_stock_7_clicked(); break;
        case 69: _t->on_tri_stock_8_clicked(); break;
        case 70: _t->on_ig_2_clicked(); break;
        case 71: _t->on_fb_2_clicked(); break;
        case 72: _t->on_linkedin_2_clicked(); break;
        case 73: _t->on_tri_stock_9_clicked(); break;
        case 74: _t->on_tri_stock_10_clicked(); break;
        case 75: _t->on_pushButton_18_clicked(); break;
        case 76: _t->on_pb_Add_clicked(); break;
        case 77: _t->on_pb_supp_clicked(); break;
        case 78: _t->on_comboBox_agent_currentIndexChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 79: _t->on_pb_modif_clicked(); break;
        case 80: _t->on_Sort_by_id_clicked(); break;
        case 81: _t->on_Sort_by_name_clicked(); break;
        case 82: _t->on_Sort_by_adress_clicked(); break;
        case 83: _t->on_search_id_2_textChanged((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 84: _t->on_search_name_2_textChanged((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 85: _t->on_search_adress_2_textChanged((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 86: _t->on_todo_clicked(); break;
        case 87: _t->on_generer_pdf_clicked(); break;
        case 88: _t->on_pushButton_database_insert_clicked(); break;
        case 89: _t->on_pushButton_21_clicked(); break;
        case 90: _t->on_pushButton_29_clicked(); break;
        case 91: _t->on_pushButton_30_clicked(); break;
        case 92: _t->on_update_prop_clicked(); break;
        case 93: _t->on_comboBox_7_currentIndexChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 94: _t->on_pushButton_delete_prop_clicked(); break;
        case 95: _t->on_tableView_2_prop_clicked((*reinterpret_cast< const QModelIndex(*)>(_a[1]))); break;
        case 96: _t->on_pushButton_31_clicked(); break;
        case 97: _t->on_pushButton_32_clicked(); break;
        case 98: _t->on_pushButton_33_clicked(); break;
        case 99: _t->on_pushButton_34_clicked(); break;
        case 100: _t->on_pushButton_35_clicked(); break;
        case 101: _t->on_pushButton_36_clicked(); break;
        case 102: _t->on_lineEdit_cherche_function_textChanged((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        //case 103: _t->on_lineEdit_cherche_function_textEdited((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 104: _t->on_chat_2_clicked(); break;
        case 105: _t->on_pushButton_security_arduino_clicked(); break;
       // case 106: _t->on_pushButton_27_clicked(); break;
        case 107: _t->on_pushButton_security_arduino_2_clicked(); break;
        case 108: _t->on_pushButton_28_clicked(); break;
        case 109: _t->update_label(); break;
        default: ;
        }
    }
}

const QMetaObject MainWindow::staticMetaObject = {
    { &QMainWindow::staticMetaObject, qt_meta_stringdata_MainWindow.data,
      qt_meta_data_MainWindow,  qt_static_metacall, nullptr, nullptr}
};


const QMetaObject *MainWindow::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *MainWindow::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_MainWindow.stringdata0))
        return static_cast<void*>(this);
    return QMainWindow::qt_metacast(_clname);
}

int MainWindow::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 110)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 110;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 110)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 110;
    }
    return _id;
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
