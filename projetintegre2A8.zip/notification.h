#ifndef NOTIFICATION_H
#define NOTIFICATION_H
#include<QSystemTrayIcon>

class Notification

{
public:
Notification();
void notification_ajoutab();
void notification_supprimerab();
void notification_modifierab();
};



#endif // NOTIFICATION_H
