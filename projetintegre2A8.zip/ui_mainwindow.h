/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.9.9
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QFrame>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPlainTextEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStackedWidget>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QTabWidget>
#include <QtWidgets/QTableView>
#include <QtWidgets/QTextBrowser>
#include <QtWidgets/QTextEdit>
#include <QtWidgets/QWidget>
#include "qcustomplot.h"

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralwidget;
    QStackedWidget *stackedWidget;
    QWidget *page_8;
    QPushButton *pushButton_7;
    QPushButton *pushButton_14;
    QPushButton *pushButton_18;
    QPushButton *pushButton_19;
    QPushButton *pushButton_20;
    QPushButton *pushButton_21;
    QPushButton *pushButton_22;
    QWidget *page;
    QPushButton *pushButton_9;
    QPushButton *pushButton_10;
    QLabel *label_4;
    QTabWidget *tabWidget_5;
    QWidget *tab_8;
    QLabel *label_96;
    QLabel *label_97;
    QLabel *label_98;
    QLabel *label_99;
    QLabel *label_100;
    QLabel *label_101;
    QLineEdit *name_par_2;
    QLineEdit *type_par_2;
    QLineEdit *duration_par_2;
    QLineEdit *contract_language_par_2;
    QLineEdit *sub_num_par_2;
    QPushButton *add_2;
    QLineEdit *id_par_2;
    QLabel *label_103;
    QWidget *tab_13;
    QTableView *tab_produit_3;
    QPushButton *sort_par_2;
    QPushButton *sort_par;
    QPushButton *sort_par_3;
    QLabel *label_104;
    QLineEdit *chercher_4;
    QLabel *label_105;
    QLineEdit *chercher_5;
    QPushButton *supprimer_2;
    QLabel *label_106;
    QLabel *label_107;
    QLineEdit *type_up_2;
    QLineEdit *lineEdit_11;
    QLabel *label_108;
    QLineEdit *name_up_2;
    QLabel *label_109;
    QLabel *label_110;
    QLineEdit *id_up_2;
    QLineEdit *duration_up_2;
    QLabel *label_111;
    QLabel *label_112;
    QLineEdit *conlang_up_2;
    QPushButton *update_3;
    QLineEdit *id_dell_2;
    QPushButton *pushButton_42;
    QLineEdit *subnum_up_2;
    QLabel *label_113;
    QComboBox *idbox_2;
    QPushButton *tri_stock_7;
    QPushButton *tri_stock_8;
    QPushButton *tri_stock_9;
    QPushButton *tri_stock_10;
    QWidget *tab_14;
    QPushButton *ig_2;
    QPushButton *fb_2;
    QPushButton *linkedin_2;
    QLabel *label_114;
    QLabel *label_115;
    QLabel *label_116;
    QWidget *page_2;
    QTabWidget *tabWidget_3;
    QWidget *tab_9;
    QLabel *label_76;
    QPushButton *pb_add_2;
    QLabel *label_77;
    QLineEdit *le_edate_2;
    QLabel *label_79;
    QLabel *label_80;
    QLineEdit *le_price_2;
    QLabel *label_81;
    QLineEdit *le_durt_2;
    QLineEdit *le_sdate_2;
    QLineEdit *le_type_2;
    QLabel *label_82;
    QLabel *label_83;
    QLabel *label_84;
    QLineEdit *le_num_3;
    QComboBox *comboBox_4;
    QWidget *tab_10;
    QTableView *tab_subscriptions_2;
    QPushButton *sortByType_2;
    QPushButton *sortById_2;
    QPushButton *sortByPrice_2;
    QPushButton *searchnum_2;
    QLabel *label_85;
    QLineEdit *numtosearch_2;
    QLabel *label_86;
    QLineEdit *typetosearch_2;
    QPushButton *searchType_2;
    QLabel *label_87;
    QLineEdit *startdatetosearch_2;
    QPushButton *searchStartDate_2;
    QLabel *label_88;
    QLineEdit *le_duration_modif_2;
    QLineEdit *le_edate_modif_2;
    QLineEdit *le_sdate_modif_2;
    QLabel *label_89;
    QLineEdit *le_type_modif_2;
    QLabel *label_90;
    QLabel *label_91;
    QLabel *label_92;
    QLineEdit *le_price_modif_2;
    QLabel *label_93;
    QLabel *label_94;
    QLineEdit *le_idBuy_modif_2;
    QPushButton *pb_delete_2;
    QLineEdit *le_num_modif_2;
    QPushButton *pd_update_2;
    QComboBox *comboBox_5;
    QPushButton *pb_read_2;
    QPushButton *pbExport_2;
    QWidget *tab_11;
    QCustomPlot *plot_2;
    QWidget *tab_12;
    QPushButton *pb_history_2;
    QTextBrowser *textBrowser_2;
    QWidget *page_3;
    QGroupBox *groupBox_2;
    QPushButton *pushButton_12;
    QTabWidget *tabWidget_2;
    QWidget *tab;
    QTableView *tabagent;
    QLabel *label_25;
    QLineEdit *lineEdit_password_2;
    QLabel *label_23;
    QLabel *label_19;
    QLineEdit *lineEdit_mail_2;
    QLineEdit *lineEdit_adress_2;
    QLabel *label_21;
    QLabel *label_24;
    QLineEdit *lineEdit_lastname_2;
    QLabel *label_20;
    QLineEdit *lineEdit_login_2;
    QLineEdit *lineEdit_name_2;
    QLineEdit *lineEdit_number_2;
    QLineEdit *lineEdit_function_2;
    QLabel *label_17;
    QLabel *label_18;
    QLineEdit *lineEdit_cin_3;
    QLabel *label_22;
    QPushButton *pushButton_6;
    QComboBox *comboBox_agent;
    QLabel *label;
    QPushButton *pushButton_15;
    QPushButton *pushButton_16;
    QPushButton *pushButton_17;
    QLineEdit *lineEdit_cherche;
    QLabel *label_38;
    QLabel *label_39;
    QLineEdit *lineEdit_cherche_cin;
    QPushButton *pushButton_23;
    QLabel *label_40;
    QLineEdit *lineEdit_cherche_function;
    QPushButton *chat_2;
    QWidget *tab_5;
    QPushButton *logout;
    QGroupBox *groupBox;
    QLabel *label_16;
    QPushButton *pushButton_25;
    QLabel *label_45;
    QLineEdit *agent_cin;
    QPushButton *add_ag;
    QLineEdit *agent_lastname;
    QLineEdit *agent_mail;
    QLineEdit *agent_adress;
    QLineEdit *agent_name;
    QLineEdit *agent_num;
    QLineEdit *agent_login;
    QLineEdit *agent_function;
    QLineEdit *agent_pass;
    QLabel *label_46;
    QLabel *label_47;
    QLabel *label_48;
    QLabel *label_49;
    QLabel *label_50;
    QLabel *label_51;
    QLabel *label_53;
    QLabel *label_54;
    QLabel *label_56;
    QPushButton *photo_2;
    QLabel *lbl_image_2;
    QWidget *page_4;
    QTabWidget *tabWidget;
    QWidget *tab_3;
    QLabel *label_3;
    QPushButton *valider;
    QPushButton *inserer_photo;
    QLabel *label_26;
    QLineEdit *lineEdit_mail_buyer;
    QLabel *label_5;
    QLabel *label_55;
    QLineEdit *lineEdit_request_buyer;
    QLineEdit *lineEdit_adress_buyer;
    QLabel *label_27;
    QLineEdit *lineEdit_name_buyer;
    QLineEdit *lineEdit_num_buyer;
    QLineEdit *lineEdit_lastname_buyer;
    QLabel *label_52;
    QLabel *label_28;
    QLabel *label_29;
    QLineEdit *lineEdit_id_buyer;
    QLabel *label_30;
    QComboBox *comboBox_buyer_1;
    QComboBox *comboBox_buyer_2;
    QWidget *tab_4;
    QTableView *tab_produit;
    QPushButton *sort_request_buyer;
    QPushButton *sort_name_buyer;
    QPushButton *sort_adress_buyer;
    QPushButton *rechercher_2;
    QLabel *label_31;
    QLineEdit *chercher_id;
    QLabel *label_32;
    QLineEdit *chercher_name;
    QPushButton *rechercher_3;
    QLabel *label_33;
    QLineEdit *chercher_request;
    QPushButton *rechercher_4;
    QPushButton *sort_id_buyer;
    QLabel *label_34;
    QLineEdit *update_name;
    QLineEdit *update_mail;
    QLineEdit *update_num;
    QLabel *label_35;
    QLineEdit *update_lastname;
    QLabel *label_36;
    QLabel *label_37;
    QLabel *label_41;
    QLineEdit *update_adress;
    QLabel *label_42;
    QLabel *label_43;
    QLineEdit *update_request;
    QPushButton *read;
    QPushButton *pushButton_delete;
    QLineEdit *lineEdit_del;
    QLineEdit *update_id;
    QPushButton *update;
    QComboBox *comboBox_buyer_3;
    QPushButton *pushButton_13;
    QPushButton *mailling;
    QTableView *tableView2;
    QLabel *label_44;
    QLineEdit *city;
    QPushButton *recommand;
    QWidget *page_6;
    QTabWidget *tabWidget_4;
    QWidget *tab_6;
    QLabel *label_2;
    QPushButton *pb_Add;
    QLabel *label_6;
    QComboBox *comboBox_3;
    QComboBox *comboBox_6;
    QLabel *label_7;
    QLineEdit *num_sel;
    QLineEdit *mail_sel;
    QLineEdit *name_sel;
    QLabel *label_8;
    QLineEdit *id_sel;
    QLineEdit *adress_sel;
    QLabel *label_9;
    QLineEdit *lastname_sel;
    QLabel *label_10;
    QPushButton *generer_pdf;
    QWidget *tab_2;
    QTableView *tab_seller;
    QPushButton *pb_modif;
    QPushButton *pb_supp;
    QPushButton *Sort_by_id;
    QPushButton *Sort_by_name;
    QPushButton *Sort_by_adress;
    QPushButton *search_id;
    QPushButton *pb_read;
    QLabel *label_11;
    QLineEdit *id_supp;
    QLabel *label_12;
    QLineEdit *id_modif;
    QLabel *label_13;
    QLineEdit *lastname_modif;
    QLabel *label_14;
    QLineEdit *name_modif;
    QLabel *label_15;
    QLineEdit *adress_modif;
    QLabel *label_57;
    QLineEdit *num_modif;
    QLabel *label_58;
    QLineEdit *mail_modif;
    QComboBox *comboBox;
    QLabel *label_59;
    QPushButton *search_name;
    QPushButton *search_adress;
    QLineEdit *search_id_2;
    QLineEdit *search_name_2;
    QLineEdit *search_adress_2;
    QLabel *label_60;
    QLabel *label_61;
    QLabel *label_62;
    QPushButton *todo;
    QTextEdit *textEdit;
    QWidget *page_7;
    QTabWidget *tabWidget_6;
    QWidget *tab_7;
    QFrame *frame;
    QStackedWidget *stackedWidget_2;
    QWidget *page_9;
    QPushButton *pushButton_security_arduino;
    QPushButton *pushButton_security_arduino_2;
    QPushButton *pushButton_28;
    QLabel *label_63;
    QLabel *label_64;
    QWidget *page_10;
    QWidget *tab_15;
    QGroupBox *groupBox_3;
    QGridLayout *gridLayout;
    QLabel *label_65;
    QLineEdit *lineEdit_longitude_prop;
    QLineEdit *lineEdit_price_pro;
    QLabel *label_66;
    QLabel *label_67;
    QLineEdit *lineEdit_latitude_prop;
    QLineEdit *lineEdit_Id_prop;
    QLineEdit *lineEdit_Type_prop;
    QLabel *label_68;
    QLabel *label_69;
    QPushButton *pushButton_29;
    QLineEdit *lineEdit_2;
    QPushButton *pushButton_30;
    QLineEdit *lineEdit_3;
    QPushButton *pushButton_database_insert;
    QTableView *tableView_2_prop;
    QPushButton *pushButton_delete_prop;
    QComboBox *comboBox_7;
    QPushButton *update_prop;
    QComboBox *comboBox_8;
    QComboBox *comboBox_9;
    QLabel *label_70;
    QLabel *label_71;
    QLabel *label_72;
    QLabel *label_73;
    QLabel *label_74;
    QLineEdit *lineEdit_find_id_prop;
    QLineEdit *lineEdit_find_type_prop;
    QLineEdit *lineEdit_find_price_prop;
    QPushButton *pushButton_31;
    QPushButton *pushButton_32;
    QPushButton *pushButton_33;
    QPushButton *pushButton_34;
    QPushButton *pushButton_35;
    QPushButton *pushButton_36;
    QPlainTextEdit *plainTextEdit_2;
    QLabel *label_75;
    QPushButton *pushButton_5;
    QPushButton *pushButton_37;
    QPushButton *pushButton_38;
    QComboBox *comboBox_10;
    QWidget *page_5;
    QPlainTextEdit *plainTextEdit;
    QLineEdit *lineEdit;
    QPushButton *chat;
    QPushButton *pushButton_24;
    QLineEdit *lineEdit_login_3;
    QComboBox *comboBox_2;
    QPushButton *combo;
    QMenuBar *menubar;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QStringLiteral("MainWindow"));
        MainWindow->resize(1570, 793);
        QIcon icon;
        icon.addFile(QStringLiteral("../../../Downloads/279105962_364393082142777_3805701867299913099_n.png"), QSize(), QIcon::Normal, QIcon::Off);
        MainWindow->setWindowIcon(icon);
        centralwidget = new QWidget(MainWindow);
        centralwidget->setObjectName(QStringLiteral("centralwidget"));
        centralwidget->setStyleSheet(QLatin1String("\n"
"	background-color: QLinearGradient(x1:0, y1:0, x2:0, y2:1, stop:1 #212121, stop:.4 #343434);\n"
"	color: #000000;\n"
"	border-color: #000000;"));
        stackedWidget = new QStackedWidget(centralwidget);
        stackedWidget->setObjectName(QStringLiteral("stackedWidget"));
        stackedWidget->setGeometry(QRect(0, 30, 1561, 721));
        page_8 = new QWidget();
        page_8->setObjectName(QStringLiteral("page_8"));
        pushButton_7 = new QPushButton(page_8);
        pushButton_7->setObjectName(QStringLiteral("pushButton_7"));
        pushButton_7->setEnabled(true);
        pushButton_7->setGeometry(QRect(110, 120, 251, 111));
        pushButton_7->setStyleSheet(QLatin1String("background-color: qlineargradient(spread:repeat, x1:1, y1:0, x2:1, y2:1, stop:0 rgba(254, 171, 66, 255),stop:1 rgba(255, 153, 0, 255));\n"
"	color: #000;\n"
"	font-size: 14pt;\n"
"	border-radius: 4px;\n"
"	padding: 10px;\n"
""));
        QIcon icon1;
        icon1.addFile(QStringLiteral("../add.png"), QSize(), QIcon::Normal, QIcon::Off);
        pushButton_7->setIcon(icon1);
        pushButton_7->setCheckable(false);
        pushButton_14 = new QPushButton(page_8);
        pushButton_14->setObjectName(QStringLiteral("pushButton_14"));
        pushButton_14->setGeometry(QRect(430, 120, 251, 111));
        pushButton_14->setStyleSheet(QLatin1String("background-color: qlineargradient(spread:repeat, x1:1, y1:0, x2:1, y2:1, stop:0 rgba(254, 171, 66, 255),stop:1 rgba(255, 153, 0, 255));\n"
"	color: #000;\n"
"	font-size: 14pt;\n"
"	border-radius: 4px;\n"
"	padding: 10px;\n"
""));
        pushButton_14->setIcon(icon1);
        pushButton_14->setCheckable(false);
        pushButton_18 = new QPushButton(page_8);
        pushButton_18->setObjectName(QStringLiteral("pushButton_18"));
        pushButton_18->setGeometry(QRect(440, 280, 251, 111));
        pushButton_18->setStyleSheet(QLatin1String("background-color: qlineargradient(spread:repeat, x1:1, y1:0, x2:1, y2:1, stop:0 rgba(254, 171, 66, 255),stop:1 rgba(255, 153, 0, 255));\n"
"	color: #000;\n"
"	font-size: 14pt;\n"
"	border-radius: 4px;\n"
"	padding: 10px;\n"
""));
        pushButton_18->setIcon(icon1);
        pushButton_18->setCheckable(false);
        pushButton_19 = new QPushButton(page_8);
        pushButton_19->setObjectName(QStringLiteral("pushButton_19"));
        pushButton_19->setGeometry(QRect(110, 280, 251, 111));
        pushButton_19->setStyleSheet(QLatin1String("background-color: qlineargradient(spread:repeat, x1:1, y1:0, x2:1, y2:1, stop:0 rgba(254, 171, 66, 255),stop:1 rgba(255, 153, 0, 255));\n"
"	color: #000;\n"
"	font-size: 14pt;\n"
"	border-radius: 4px;\n"
"	padding: 10px;\n"
""));
        pushButton_19->setIcon(icon1);
        pushButton_19->setCheckable(false);
        pushButton_20 = new QPushButton(page_8);
        pushButton_20->setObjectName(QStringLiteral("pushButton_20"));
        pushButton_20->setGeometry(QRect(110, 430, 251, 111));
        pushButton_20->setStyleSheet(QLatin1String("background-color: qlineargradient(spread:repeat, x1:1, y1:0, x2:1, y2:1, stop:0 rgba(254, 171, 66, 255),stop:1 rgba(255, 153, 0, 255));\n"
"	color: #000;\n"
"	font-size: 14pt;\n"
"	border-radius: 4px;\n"
"	padding: 10px;\n"
""));
        pushButton_20->setIcon(icon1);
        pushButton_20->setCheckable(false);
        pushButton_21 = new QPushButton(page_8);
        pushButton_21->setObjectName(QStringLiteral("pushButton_21"));
        pushButton_21->setGeometry(QRect(440, 440, 251, 111));
        pushButton_21->setStyleSheet(QLatin1String("background-color: qlineargradient(spread:repeat, x1:1, y1:0, x2:1, y2:1, stop:0 rgba(254, 171, 66, 255),stop:1 rgba(255, 153, 0, 255));\n"
"	color: #000;\n"
"	font-size: 14pt;\n"
"	border-radius: 4px;\n"
"	padding: 10px;\n"
""));
        pushButton_21->setIcon(icon1);
        pushButton_21->setCheckable(false);
        pushButton_22 = new QPushButton(page_8);
        pushButton_22->setObjectName(QStringLiteral("pushButton_22"));
        pushButton_22->setGeometry(QRect(110, 570, 251, 111));
        pushButton_22->setStyleSheet(QLatin1String("background-color: qlineargradient(spread:repeat, x1:1, y1:0, x2:1, y2:1, stop:0 rgba(254, 171, 66, 255),stop:1 rgba(255, 153, 0, 255));\n"
"	color: #000;\n"
"	font-size: 14pt;\n"
"	border-radius: 4px;\n"
"	padding: 10px;\n"
""));
        pushButton_22->setIcon(icon1);
        pushButton_22->setCheckable(false);
        stackedWidget->addWidget(page_8);
        page = new QWidget();
        page->setObjectName(QStringLiteral("page"));
        pushButton_9 = new QPushButton(page);
        pushButton_9->setObjectName(QStringLiteral("pushButton_9"));
        pushButton_9->setGeometry(QRect(10, 650, 211, 51));
        pushButton_9->setStyleSheet(QLatin1String("background-color: qlineargradient(spread:repeat, x1:1, y1:0, x2:1, y2:1, stop:0 rgba(254, 171, 66, 255),stop:1 rgba(255, 153, 0, 255));\n"
"	color: #000;\n"
"	font-size: 14pt;\n"
"	border-radius: 4px;\n"
"	padding: 10px;\n"
""));
        QIcon icon2;
        icon2.addFile(QStringLiteral("../Previous page.png"), QSize(), QIcon::Normal, QIcon::Off);
        pushButton_9->setIcon(icon2);
        pushButton_10 = new QPushButton(page);
        pushButton_10->setObjectName(QStringLiteral("pushButton_10"));
        pushButton_10->setGeometry(QRect(1430, 650, 121, 51));
        pushButton_10->setStyleSheet(QLatin1String("background-color: qlineargradient(spread:repeat, x1:1, y1:0, x2:1, y2:1, stop:0 rgba(254, 171, 66, 255),stop:1 rgba(255, 153, 0, 255));\n"
"	color: #000;\n"
"	font-size: 14pt;\n"
"	border-radius: 4px;\n"
"	padding: 10px;\n"
""));
        QIcon icon3;
        icon3.addFile(QStringLiteral("../logout.png"), QSize(), QIcon::Normal, QIcon::Off);
        pushButton_10->setIcon(icon3);
        label_4 = new QLabel(page);
        label_4->setObjectName(QStringLiteral("label_4"));
        label_4->setGeometry(QRect(340, 0, 501, 111));
        label_4->setStyleSheet(QLatin1String("background-color: transparent;\n"
"	color: #fff;\n"
"	font-size: 14pt;\n"
"	border-color: #000000;\n"
""));
        tabWidget_5 = new QTabWidget(page);
        tabWidget_5->setObjectName(QStringLiteral("tabWidget_5"));
        tabWidget_5->setGeometry(QRect(40, 150, 781, 491));
        tabWidget_5->setStyleSheet(QLatin1String("QTabBar::tab\n"
"{\n"
"	font-size: 8pt;\n"
"	font-weight: bold;\n"
"	width: 80px;\n"
"    border: 1px solid #444;\n"
"    border-bottom-style: none;\n"
"	border-top-style: none;\n"
"    background-color: #323232;\n"
"    padding-top: 3px;\n"
"    padding-bottom: 2px;\n"
"    margin-right: -1px;\n"
"\n"
"}\n"
"\n"
"QTabWidget::pane \n"
"{\n"
"    border: 1px solid qlineargradient(spread:repeat, x1:1, y1:0, x2:1, y2:1, stop:0 rgba(254, 171, 66, 255),stop:1 rgba(255, 153, 0, 255));\n"
"    top: 1px;\n"
"\n"
"}\n"
"\n"
"QTabBar::tab:last\n"
"{\n"
"    margin-right: 0; \n"
"\n"
"}\n"
"\n"
"QTabBar::tab:first:!selected\n"
"{\n"
"	margin-left: 0px; \n"
"\n"
"}\n"
"\n"
"QTabBar::tab:!selected\n"
"{\n"
"    color: #fff;\n"
"    border-bottom-style: solid;\n"
"    margin-top: 3px;\n"
"    background-color: QLinearGradient(x1:0, y1:0, x2:0, y2:1, stop:1 #212121, stop:.4 #343434);\n"
"\n"
"}\n"
"\n"
"QTabBar::tab:selected\n"
"{\n"
"	background-color: qlineargradient(spread:repeat, x1:1, y1:0, x2:1, y2:1, stop:0 rgba(254, "
                        "171, 66, 255),stop:1 rgba(255, 153, 0, 255));\n"
"	color: #000;\n"
"    margin-bottom: 0px;\n"
"\n"
"}\n"
"\n"
"QTabBar::tab:!selected:hover\n"
"{\n"
"    background-color: QLinearGradient(x1:0, y1:0, x2:0, y2:1, stop:1 #212121, stop:0.4 #343434, stop:0.2 #343434, stop:0.1 #ffaa00);\n"
"\n"
"}"));
        tab_8 = new QWidget();
        tab_8->setObjectName(QStringLiteral("tab_8"));
        label_96 = new QLabel(tab_8);
        label_96->setObjectName(QStringLiteral("label_96"));
        label_96->setGeometry(QRect(85, 20, 281, 20));
        label_96->setStyleSheet(QLatin1String("QLabel\n"
"{\n"
"	background-color: transparent;\n"
"	color: #fff;\n"
"	font-size: 14pt;\n"
"	border-color: #000000;\n"
"\n"
"}\n"
""));
        label_97 = new QLabel(tab_8);
        label_97->setObjectName(QStringLiteral("label_97"));
        label_97->setGeometry(QRect(50, 70, 56, 16));
        label_97->setStyleSheet(QLatin1String("QLabel\n"
"{\n"
"	background-color: transparent;\n"
"	color: #fff;\n"
"	font-size: 14pt;\n"
"	border-color: #000000;\n"
"\n"
"}\n"
""));
        label_98 = new QLabel(tab_8);
        label_98->setObjectName(QStringLiteral("label_98"));
        label_98->setGeometry(QRect(50, 110, 56, 16));
        label_98->setStyleSheet(QLatin1String("QLabel\n"
"{\n"
"	background-color: transparent;\n"
"	color: #fff;\n"
"	font-size: 14pt;\n"
"	border-color: #000000;\n"
"\n"
"}\n"
""));
        label_99 = new QLabel(tab_8);
        label_99->setObjectName(QStringLiteral("label_99"));
        label_99->setGeometry(QRect(50, 140, 56, 16));
        label_99->setStyleSheet(QLatin1String("QLabel\n"
"{\n"
"	background-color: transparent;\n"
"	color: #fff;\n"
"	font-size: 14pt;\n"
"	border-color: #000000;\n"
"\n"
"}\n"
""));
        label_100 = new QLabel(tab_8);
        label_100->setObjectName(QStringLiteral("label_100"));
        label_100->setGeometry(QRect(15, 180, 101, 20));
        label_100->setStyleSheet(QLatin1String("QLabel\n"
"{\n"
"	background-color: transparent;\n"
"	color: #fff;\n"
"	font-size: 14pt;\n"
"	border-color: #000000;\n"
"\n"
"}\n"
""));
        label_101 = new QLabel(tab_8);
        label_101->setObjectName(QStringLiteral("label_101"));
        label_101->setGeometry(QRect(30, 210, 91, 20));
        label_101->setStyleSheet(QLatin1String("QLabel\n"
"{\n"
"	background-color: transparent;\n"
"	color: #fff;\n"
"	font-size: 14pt;\n"
"	border-color: #000000;\n"
"\n"
"}\n"
""));
        name_par_2 = new QLineEdit(tab_8);
        name_par_2->setObjectName(QStringLiteral("name_par_2"));
        name_par_2->setGeometry(QRect(150, 70, 113, 22));
        name_par_2->setStyleSheet(QStringLiteral("color: rgb(255, 255, 255);"));
        type_par_2 = new QLineEdit(tab_8);
        type_par_2->setObjectName(QStringLiteral("type_par_2"));
        type_par_2->setGeometry(QRect(150, 100, 113, 22));
        type_par_2->setStyleSheet(QStringLiteral("color: rgb(255, 255, 255);"));
        duration_par_2 = new QLineEdit(tab_8);
        duration_par_2->setObjectName(QStringLiteral("duration_par_2"));
        duration_par_2->setGeometry(QRect(150, 140, 113, 22));
        duration_par_2->setStyleSheet(QStringLiteral("color: rgb(255, 255, 255);"));
        contract_language_par_2 = new QLineEdit(tab_8);
        contract_language_par_2->setObjectName(QStringLiteral("contract_language_par_2"));
        contract_language_par_2->setGeometry(QRect(150, 180, 113, 22));
        contract_language_par_2->setStyleSheet(QStringLiteral("color: rgb(255, 255, 255);"));
        sub_num_par_2 = new QLineEdit(tab_8);
        sub_num_par_2->setObjectName(QStringLiteral("sub_num_par_2"));
        sub_num_par_2->setGeometry(QRect(150, 210, 113, 22));
        sub_num_par_2->setStyleSheet(QStringLiteral("color: rgb(255, 255, 255);"));
        add_2 = new QPushButton(tab_8);
        add_2->setObjectName(QStringLiteral("add_2"));
        add_2->setGeometry(QRect(400, 260, 80, 41));
        add_2->setStyleSheet(QLatin1String("QPushButton\n"
"{background-color: rgb(200,133,0);\n"
"color : white;\n"
"font: 10pt Arial;\n"
"            border-radius: 4px;\n"
"            text-shadow: 0 1px 1px rgba(0, 0, 0, 0.2);\n"
"border: 2px solid rgb(200,133,0);\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"border: 2px solid rgb(200,146,0);\n"
"background-color : rgb(200,149,47);\n"
"}"));
        id_par_2 = new QLineEdit(tab_8);
        id_par_2->setObjectName(QStringLiteral("id_par_2"));
        id_par_2->setGeometry(QRect(150, 250, 113, 24));
        id_par_2->setStyleSheet(QStringLiteral("color: rgb(255, 255, 255);"));
        label_103 = new QLabel(tab_8);
        label_103->setObjectName(QStringLiteral("label_103"));
        label_103->setGeometry(QRect(60, 250, 71, 16));
        label_103->setStyleSheet(QLatin1String("QLabel\n"
"{\n"
"	background-color: transparent;\n"
"	color: #fff;\n"
"	font-size: 14pt;\n"
"	border-color: #000000;\n"
"\n"
"}\n"
""));
        tabWidget_5->addTab(tab_8, QString());
        tab_13 = new QWidget();
        tab_13->setObjectName(QStringLiteral("tab_13"));
        tab_produit_3 = new QTableView(tab_13);
        tab_produit_3->setObjectName(QStringLiteral("tab_produit_3"));
        tab_produit_3->setGeometry(QRect(10, 10, 761, 191));
        tab_produit_3->setStyleSheet(QLatin1String("QHeaderView::section{\n"
"    background-color:rgb(90,90,90);\n"
"      color:rgb(200,200,200);\n"
"    border:1px solid rgb(60,60,60);\n"
"    border-bottom:1px solid rgb(70,70,70);\n"
"    height:27px;\n"
"    min-width:55px;\n"
"}\n"
"QHeaderView::section:hover\n"
"{\n"
"    background-color:rgb(80,80,80);\n"
"\n"
"}\n"
"QTableView\n"
"{\n"
"	background: rgb(55,55,55);\n"
"}\n"
"QTableView{\n"
"    selection-background-color:rgb(255,0,0);\n"
"    background-color:rgb(50,50,50);\n"
"    border:1px solid rgb(70,70,70);\n"
"    color:rgb(200,200,200)\n"
"}\n"
"\n"
"QTableView::item\n"
"{\n"
"       border:1px solid rgb(65,65,65);\n"
"	color:rgb(200,200,200);\n"
"\n"
"}\n"
"QTableView::item:hover\n"
"{\n"
"    background-color: rgb(30,30,30);\n"
"    font: 75 9pt \"Microsoft YaHei\";\n"
"    color:rgb(31,163,246);\n"
"}\n"
"QTableView::item::selected\n"
"{\n"
"    background-color: rgb(30,30,30);\n"
"    font: 75 9pt \"Microsoft YaHei\";\n"
"    color:rgb(31,163,246);\n"
"}\n"
""));
        sort_par_2 = new QPushButton(tab_13);
        sort_par_2->setObjectName(QStringLiteral("sort_par_2"));
        sort_par_2->setGeometry(QRect(230, 210, 131, 28));
        sort_par_2->setStyleSheet(QLatin1String("QPushButton\n"
"{background-color: rgb(200,133,0);\n"
"color : white;\n"
"font: 10pt Arial;\n"
"            border-radius: 4px;\n"
"            text-shadow: 0 1px 1px rgba(0, 0, 0, 0.2);\n"
"border: 2px solid rgb(200,133,0);\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"border: 2px solid rgb(200,146,0);\n"
"background-color : rgb(200,149,47);\n"
"}"));
        sort_par = new QPushButton(tab_13);
        sort_par->setObjectName(QStringLiteral("sort_par"));
        sort_par->setGeometry(QRect(72, 210, 111, 28));
        sort_par->setStyleSheet(QLatin1String("QPushButton\n"
"{background-color: rgb(200,133,0);\n"
"color : white;\n"
"font: 10pt Arial;\n"
"            border-radius: 4px;\n"
"            text-shadow: 0 1px 1px rgba(0, 0, 0, 0.2);\n"
"border: 2px solid rgb(200,133,0);\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"border: 2px solid rgb(200,146,0);\n"
"background-color : rgb(200,149,47);\n"
"}"));
        sort_par_3 = new QPushButton(tab_13);
        sort_par_3->setObjectName(QStringLiteral("sort_par_3"));
        sort_par_3->setGeometry(QRect(410, 210, 131, 28));
        sort_par_3->setStyleSheet(QLatin1String("QPushButton\n"
"{background-color: rgb(200,133,0);\n"
"color : white;\n"
"font: 10pt Arial;\n"
"            border-radius: 4px;\n"
"            text-shadow: 0 1px 1px rgba(0, 0, 0, 0.2);\n"
"border: 2px solid rgb(200,133,0);\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"border: 2px solid rgb(200,146,0);\n"
"background-color : rgb(200,149,47);\n"
"}"));
        label_104 = new QLabel(tab_13);
        label_104->setObjectName(QStringLiteral("label_104"));
        label_104->setGeometry(QRect(60, 270, 131, 20));
        QFont font;
        font.setPointSize(14);
        label_104->setFont(font);
        label_104->setStyleSheet(QLatin1String("QLabel\n"
"{\n"
"	background-color: transparent;\n"
"	color: #fff;\n"
"	font-size: 14pt;\n"
"	border-color: #000000;\n"
"\n"
"}\n"
""));
        chercher_4 = new QLineEdit(tab_13);
        chercher_4->setObjectName(QStringLiteral("chercher_4"));
        chercher_4->setGeometry(QRect(260, 270, 111, 22));
        chercher_4->setStyleSheet(QStringLiteral("color: rgb(255, 255, 255);"));
        label_105 = new QLabel(tab_13);
        label_105->setObjectName(QStringLiteral("label_105"));
        label_105->setGeometry(QRect(60, 320, 141, 20));
        label_105->setFont(font);
        label_105->setStyleSheet(QLatin1String("QLabel\n"
"{\n"
"	background-color: transparent;\n"
"	color: #fff;\n"
"	font-size: 14pt;\n"
"	border-color: #000000;\n"
"\n"
"}\n"
""));
        chercher_5 = new QLineEdit(tab_13);
        chercher_5->setObjectName(QStringLiteral("chercher_5"));
        chercher_5->setGeometry(QRect(260, 320, 113, 22));
        chercher_5->setStyleSheet(QStringLiteral("color: rgb(255, 255, 255);"));
        supprimer_2 = new QPushButton(tab_13);
        supprimer_2->setObjectName(QStringLiteral("supprimer_2"));
        supprimer_2->setGeometry(QRect(270, 420, 93, 31));
        supprimer_2->setStyleSheet(QLatin1String("QPushButton\n"
"{background-color: rgb(200,133,0);\n"
"color : white;\n"
"font: 10pt Arial;\n"
"            border-radius: 4px;\n"
"            text-shadow: 0 1px 1px rgba(0, 0, 0, 0.2);\n"
"border: 2px solid rgb(200,133,0);\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"border: 2px solid rgb(200,146,0);\n"
"background-color : rgb(200,149,47);\n"
"}"));
        label_106 = new QLabel(tab_13);
        label_106->setObjectName(QStringLiteral("label_106"));
        label_106->setGeometry(QRect(40, 420, 56, 16));
        label_106->setFont(font);
        label_106->setStyleSheet(QLatin1String("QLabel\n"
"{\n"
"	background-color: transparent;\n"
"	color: #fff;\n"
"	font-size: 14pt;\n"
"	border-color: #000000;\n"
"\n"
"}\n"
""));
        label_107 = new QLabel(tab_13);
        label_107->setObjectName(QStringLiteral("label_107"));
        label_107->setGeometry(QRect(491, 240, 56, 16));
        label_107->setFont(font);
        label_107->setStyleSheet(QLatin1String("QLabel\n"
"{\n"
"	background-color: transparent;\n"
"	color: #fff;\n"
"	font-size: 14pt;\n"
"	border-color: #000000;\n"
"\n"
"}\n"
""));
        type_up_2 = new QLineEdit(tab_13);
        type_up_2->setObjectName(QStringLiteral("type_up_2"));
        type_up_2->setGeometry(QRect(611, 300, 113, 22));
        type_up_2->setStyleSheet(QStringLiteral("color: rgb(255, 255, 255);"));
        lineEdit_11 = new QLineEdit(tab_13);
        lineEdit_11->setObjectName(QStringLiteral("lineEdit_11"));
        lineEdit_11->setGeometry(QRect(571, 480, 171, 22));
        lineEdit_11->setStyleSheet(QLatin1String("QLineEdit{\n"
"border: 2px solid rgb(37,39,48);\n"
"border -radius: 20px;\n"
"color: #FFF;\n"
"padding -left: 20px;\n"
"padding -right: 20px;\n"
"background-color:rgb(34,36,44);\n"
"}\n"
"QLineEdit:hover{\n"
"border: 2px solid rgb(48,50,62);\n"
"}\n"
"QLineEdit:focus{\n"
"border: 2px solid rgb(85,170,255);\n"
"background-color: rgb(43,45,56);\n"
"}"));
        label_108 = new QLabel(tab_13);
        label_108->setObjectName(QStringLiteral("label_108"));
        label_108->setGeometry(QRect(491, 336, 71, 20));
        QFont font1;
        font1.setPointSize(12);
        label_108->setFont(font1);
        label_108->setStyleSheet(QStringLiteral("color: rgb(255, 255, 255);"));
        name_up_2 = new QLineEdit(tab_13);
        name_up_2->setObjectName(QStringLiteral("name_up_2"));
        name_up_2->setGeometry(QRect(611, 270, 113, 22));
        name_up_2->setStyleSheet(QStringLiteral("color: rgb(255, 255, 255);"));
        label_109 = new QLabel(tab_13);
        label_109->setObjectName(QStringLiteral("label_109"));
        label_109->setGeometry(QRect(501, 480, 61, 16));
        label_109->setFont(font1);
        label_109->setStyleSheet(QStringLiteral("color: rgb(255, 255, 255);"));
        label_110 = new QLabel(tab_13);
        label_110->setObjectName(QStringLiteral("label_110"));
        label_110->setGeometry(QRect(491, 270, 91, 21));
        label_110->setFont(font);
        label_110->setStyleSheet(QLatin1String("QLabel\n"
"{\n"
"	background-color: transparent;\n"
"	color: #fff;\n"
"	font-size: 14pt;\n"
"	border-color: #000000;\n"
"\n"
"}\n"
""));
        id_up_2 = new QLineEdit(tab_13);
        id_up_2->setObjectName(QStringLiteral("id_up_2"));
        id_up_2->setGeometry(QRect(611, 240, 113, 22));
        id_up_2->setStyleSheet(QStringLiteral("color: rgb(255, 255, 255);"));
        duration_up_2 = new QLineEdit(tab_13);
        duration_up_2->setObjectName(QStringLiteral("duration_up_2"));
        duration_up_2->setGeometry(QRect(611, 330, 113, 22));
        duration_up_2->setStyleSheet(QStringLiteral("color: rgb(255, 255, 255);"));
        label_111 = new QLabel(tab_13);
        label_111->setObjectName(QStringLiteral("label_111"));
        label_111->setGeometry(QRect(491, 360, 71, 31));
        label_111->setFont(font);
        label_111->setStyleSheet(QLatin1String("QLabel\n"
"{\n"
"	background-color: transparent;\n"
"	color: #fff;\n"
"	font-size: 14pt;\n"
"	border-color: #000000;\n"
"\n"
"}\n"
""));
        label_112 = new QLabel(tab_13);
        label_112->setObjectName(QStringLiteral("label_112"));
        label_112->setGeometry(QRect(491, 310, 56, 16));
        label_112->setFont(font);
        label_112->setStyleSheet(QLatin1String("QLabel\n"
"{\n"
"	background-color: transparent;\n"
"	color: #fff;\n"
"	font-size: 14pt;\n"
"	border-color: #000000;\n"
"\n"
"}\n"
""));
        conlang_up_2 = new QLineEdit(tab_13);
        conlang_up_2->setObjectName(QStringLiteral("conlang_up_2"));
        conlang_up_2->setGeometry(QRect(611, 360, 113, 22));
        conlang_up_2->setStyleSheet(QStringLiteral("color: rgb(255, 255, 255);"));
        update_3 = new QPushButton(tab_13);
        update_3->setObjectName(QStringLiteral("update_3"));
        update_3->setGeometry(QRect(620, 420, 93, 31));
        update_3->setStyleSheet(QLatin1String("QPushButton\n"
"{background-color: rgb(200,133,0);\n"
"color : white;\n"
"font: 10pt Arial;\n"
"            border-radius: 4px;\n"
"            text-shadow: 0 1px 1px rgba(0, 0, 0, 0.2);\n"
"border: 2px solid rgb(200,133,0);\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"border: 2px solid rgb(200,146,0);\n"
"background-color : rgb(200,149,47);\n"
"}"));
        id_dell_2 = new QLineEdit(tab_13);
        id_dell_2->setObjectName(QStringLiteral("id_dell_2"));
        id_dell_2->setGeometry(QRect(110, 420, 113, 22));
        id_dell_2->setStyleSheet(QStringLiteral("color: rgb(255, 255, 255);"));
        pushButton_42 = new QPushButton(tab_13);
        pushButton_42->setObjectName(QStringLiteral("pushButton_42"));
        pushButton_42->setGeometry(QRect(470, 420, 101, 31));
        pushButton_42->setStyleSheet(QLatin1String("QPushButton\n"
"{background-color: rgb(200,133,0);\n"
"color : white;\n"
"font: 10pt Arial;\n"
"            border-radius: 4px;\n"
"            text-shadow: 0 1px 1px rgba(0, 0, 0, 0.2);\n"
"border: 2px solid rgb(200,133,0);\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"border: 2px solid rgb(200,146,0);\n"
"background-color : rgb(200,149,47);\n"
"}"));
        subnum_up_2 = new QLineEdit(tab_13);
        subnum_up_2->setObjectName(QStringLiteral("subnum_up_2"));
        subnum_up_2->setGeometry(QRect(610, 390, 113, 22));
        subnum_up_2->setStyleSheet(QStringLiteral("color: rgb(255, 255, 255);"));
        label_113 = new QLabel(tab_13);
        label_113->setObjectName(QStringLiteral("label_113"));
        label_113->setGeometry(QRect(490, 390, 71, 31));
        label_113->setFont(font);
        label_113->setStyleSheet(QLatin1String("QLabel\n"
"{\n"
"	background-color: transparent;\n"
"	color: #fff;\n"
"	font-size: 14pt;\n"
"	border-color: #000000;\n"
"\n"
"}\n"
""));
        idbox_2 = new QComboBox(tab_13);
        idbox_2->setObjectName(QStringLiteral("idbox_2"));
        idbox_2->setEnabled(true);
        idbox_2->setGeometry(QRect(630, 210, 75, 24));
        idbox_2->setMouseTracking(true);
        idbox_2->setStyleSheet(QLatin1String("color: rgb(255, 255, 255);\n"
"  selection-background-color: #D0D0D0;\n"
"  selection-color: #000000;"));
        tri_stock_7 = new QPushButton(tab_13);
        tri_stock_7->setObjectName(QStringLiteral("tri_stock_7"));
        tri_stock_7->setGeometry(QRect(30, 360, 61, 28));
        tri_stock_7->setStyleSheet(QLatin1String("QPushButton\n"
"{background-color: rgb(200,133,0);\n"
"color : white;\n"
"font: 10pt Arial;\n"
"            border-radius: 4px;\n"
"            text-shadow: 0 1px 1px rgba(0, 0, 0, 0.2);\n"
"border: 2px solid rgb(200,133,0);\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"border: 2px solid rgb(200,146,0);\n"
"background-color : rgb(200,149,47);\n"
"}"));
        tri_stock_8 = new QPushButton(tab_13);
        tri_stock_8->setObjectName(QStringLiteral("tri_stock_8"));
        tri_stock_8->setGeometry(QRect(380, 420, 71, 28));
        tri_stock_8->setStyleSheet(QLatin1String("QPushButton\n"
"{background-color: rgb(200,133,0);\n"
"color : white;\n"
"font: 10pt Arial;\n"
"            border-radius: 4px;\n"
"            text-shadow: 0 1px 1px rgba(0, 0, 0, 0.2);\n"
"border: 2px solid rgb(200,133,0);\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"border: 2px solid rgb(200,146,0);\n"
"background-color : rgb(200,149,47);\n"
"}"));
        tri_stock_9 = new QPushButton(tab_13);
        tri_stock_9->setObjectName(QStringLiteral("tri_stock_9"));
        tri_stock_9->setGeometry(QRect(110, 360, 61, 28));
        tri_stock_9->setStyleSheet(QLatin1String("QPushButton\n"
"{background-color: rgb(200,133,0);\n"
"color : white;\n"
"font: 10pt Arial;\n"
"            border-radius: 4px;\n"
"            text-shadow: 0 1px 1px rgba(0, 0, 0, 0.2);\n"
"border: 2px solid rgb(200,133,0);\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"border: 2px solid rgb(200,146,0);\n"
"background-color : rgb(200,149,47);\n"
"}"));
        tri_stock_10 = new QPushButton(tab_13);
        tri_stock_10->setObjectName(QStringLiteral("tri_stock_10"));
        tri_stock_10->setGeometry(QRect(190, 360, 61, 28));
        tri_stock_10->setStyleSheet(QLatin1String("QPushButton\n"
"{background-color: rgb(200,133,0);\n"
"color : white;\n"
"font: 10pt Arial;\n"
"            border-radius: 4px;\n"
"            text-shadow: 0 1px 1px rgba(0, 0, 0, 0.2);\n"
"border: 2px solid rgb(200,133,0);\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"border: 2px solid rgb(200,146,0);\n"
"background-color : rgb(200,149,47);\n"
"}"));
        tabWidget_5->addTab(tab_13, QString());
        tab_14 = new QWidget();
        tab_14->setObjectName(QStringLiteral("tab_14"));
        ig_2 = new QPushButton(tab_14);
        ig_2->setObjectName(QStringLiteral("ig_2"));
        ig_2->setGeometry(QRect(40, 350, 181, 71));
        ig_2->setStyleSheet(QLatin1String("QPushButton\n"
"{background-color: rgb(200,133,0);\n"
"color : white;\n"
"font: 10pt Arial;\n"
"            border-radius: 4px;\n"
"            text-shadow: 0 1px 1px rgba(0, 0, 0, 0.2);\n"
"border: 2px solid rgb(200,133,0);\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"border: 2px solid rgb(200,146,0);\n"
"background-color : rgb(200,149,47);\n"
"}"));
        fb_2 = new QPushButton(tab_14);
        fb_2->setObjectName(QStringLiteral("fb_2"));
        fb_2->setGeometry(QRect(280, 350, 181, 71));
        fb_2->setStyleSheet(QLatin1String("QPushButton\n"
"{background-color: rgb(200,133,0);\n"
"color : white;\n"
"font: 10pt Arial;\n"
"            border-radius: 4px;\n"
"            text-shadow: 0 1px 1px rgba(0, 0, 0, 0.2);\n"
"border: 2px solid rgb(200,133,0);\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"border: 2px solid rgb(200,146,0);\n"
"background-color : rgb(200,149,47);\n"
"}"));
        linkedin_2 = new QPushButton(tab_14);
        linkedin_2->setObjectName(QStringLiteral("linkedin_2"));
        linkedin_2->setGeometry(QRect(520, 350, 181, 71));
        linkedin_2->setStyleSheet(QLatin1String("QPushButton\n"
"{background-color: rgb(200,133,0);\n"
"color : white;\n"
"font: 10pt Arial;\n"
"            border-radius: 4px;\n"
"            text-shadow: 0 1px 1px rgba(0, 0, 0, 0.2);\n"
"border: 2px solid rgb(200,133,0);\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"border: 2px solid rgb(200,146,0);\n"
"background-color : rgb(200,149,47);\n"
"}"));
        label_114 = new QLabel(tab_14);
        label_114->setObjectName(QStringLiteral("label_114"));
        label_114->setGeometry(QRect(30, 110, 211, 211));
        label_114->setPixmap(QPixmap(QString::fromUtf8("../../Smart_Real_Estate_Agency_2A8-partners_baha/ig.png")));
        label_114->setScaledContents(true);
        label_115 = new QLabel(tab_14);
        label_115->setObjectName(QStringLiteral("label_115"));
        label_115->setGeometry(QRect(270, 110, 211, 211));
        label_115->setPixmap(QPixmap(QString::fromUtf8("../../Smart_Real_Estate_Agency_2A8-partners_baha/fb.png")));
        label_115->setScaledContents(true);
        label_116 = new QLabel(tab_14);
        label_116->setObjectName(QStringLiteral("label_116"));
        label_116->setGeometry(QRect(520, 120, 191, 191));
        label_116->setPixmap(QPixmap(QString::fromUtf8("../../Smart_Real_Estate_Agency_2A8-partners_baha/linkedin.png")));
        label_116->setScaledContents(true);
        tabWidget_5->addTab(tab_14, QString());
        stackedWidget->addWidget(page);
        page_2 = new QWidget();
        page_2->setObjectName(QStringLiteral("page_2"));
        page_2->setStyleSheet(QLatin1String("\n"
"	background-color: QLinearGradient(x1:0, y1:0, x2:0, y2:1, stop:1 #212121, stop:.4 #343434);\n"
"	color: #000000;\n"
"	border-color: #000000;"));
        tabWidget_3 = new QTabWidget(page_2);
        tabWidget_3->setObjectName(QStringLiteral("tabWidget_3"));
        tabWidget_3->setGeometry(QRect(10, 20, 1491, 661));
        tabWidget_3->setStyleSheet(QLatin1String("QTabBar::tab\n"
"{\n"
"	font-size: 8pt;\n"
"	font-weight: bold;\n"
"	width: 80px;\n"
"    border: 1px solid #444;\n"
"    border-bottom-style: none;\n"
"	border-top-style: none;\n"
"    background-color: #323232;\n"
"    padding-top: 3px;\n"
"    padding-bottom: 2px;\n"
"    margin-right: -1px;\n"
"\n"
"}\n"
"\n"
"QTabWidget::pane \n"
"{\n"
"    border: 1px solid qlineargradient(spread:repeat, x1:1, y1:0, x2:1, y2:1, stop:0 rgba(254, 171, 66, 255),stop:1 rgba(255, 153, 0, 255));\n"
"    top: 1px;\n"
"\n"
"}\n"
"\n"
"QTabBar::tab:last\n"
"{\n"
"    margin-right: 0; \n"
"\n"
"}\n"
"\n"
"QTabBar::tab:first:!selected\n"
"{\n"
"	margin-left: 0px; \n"
"\n"
"}\n"
"\n"
"QTabBar::tab:!selected\n"
"{\n"
"    color: #fff;\n"
"    border-bottom-style: solid;\n"
"    margin-top: 3px;\n"
"    background-color: QLinearGradient(x1:0, y1:0, x2:0, y2:1, stop:1 #212121, stop:.4 #343434);\n"
"\n"
"}\n"
"\n"
"QTabBar::tab:selected\n"
"{\n"
"	background-color: qlineargradient(spread:repeat, x1:1, y1:0, x2:1, y2:1, stop:0 rgba(254, "
                        "171, 66, 255),stop:1 rgba(255, 153, 0, 255));\n"
"	color: #000;\n"
"    margin-bottom: 0px;\n"
"\n"
"}\n"
"\n"
"QTabBar::tab:!selected:hover\n"
"{\n"
"    background-color: QLinearGradient(x1:0, y1:0, x2:0, y2:1, stop:1 #212121, stop:0.4 #343434, stop:0.2 #343434, stop:0.1 #ffaa00);\n"
"\n"
"}\n"
""));
        tab_9 = new QWidget();
        tab_9->setObjectName(QStringLiteral("tab_9"));
        tab_9->setStyleSheet(QLatin1String("QWidget\n"
"{\n"
"	background-color: QLinearGradient(x1:0, y1:0, x2:0, y2:1, stop:1 #212121, stop:.4 #343434);\n"
"	color: #000000;\n"
"	border-color: #000000;\n"
"\n"
"}"));
        label_76 = new QLabel(tab_9);
        label_76->setObjectName(QStringLiteral("label_76"));
        label_76->setGeometry(QRect(340, 20, 281, 20));
        label_76->setFont(font);
        label_76->setStyleSheet(QLatin1String("QLabel\n"
"{\n"
"	background-color: transparent;\n"
"	color: #fff;\n"
"	font-size: 14pt;\n"
"	border-color: #000000;\n"
"\n"
"}"));
        pb_add_2 = new QPushButton(tab_9);
        pb_add_2->setObjectName(QStringLiteral("pb_add_2"));
        pb_add_2->setGeometry(QRect(810, 410, 121, 51));
        pb_add_2->setStyleSheet(QLatin1String("QPushButton\n"
"{background-color: rgb(200,133,0);\n"
"color : white;\n"
"font: 10pt Arial;\n"
"            border-radius: 4px;\n"
"            text-shadow: 0 1px 1px rgba(0, 0, 0, 0.2);\n"
"border: 2px solid rgb(200,133,0);\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"border: 2px solid rgb(200,146,0);\n"
"background-color : rgb(200,149,47);\n"
"}"));
        label_77 = new QLabel(tab_9);
        label_77->setObjectName(QStringLiteral("label_77"));
        label_77->setGeometry(QRect(510, 260, 111, 21));
        label_77->setFont(font);
        label_77->setStyleSheet(QLatin1String("QLabel\n"
"{\n"
"	background-color: transparent;\n"
"	color: #fff;\n"
"	font-size: 14pt;\n"
"	border-color: #000000;\n"
"\n"
"}\n"
""));
        le_edate_2 = new QLineEdit(tab_9);
        le_edate_2->setObjectName(QStringLiteral("le_edate_2"));
        le_edate_2->setGeometry(QRect(650, 260, 141, 22));
        le_edate_2->setStyleSheet(QStringLiteral("color: rgb(255, 255, 255);"));
        label_79 = new QLabel(tab_9);
        label_79->setObjectName(QStringLiteral("label_79"));
        label_79->setGeometry(QRect(60, 170, 102, 31));
        label_79->setFont(font);
        label_79->setStyleSheet(QLatin1String("QLabel\n"
"{\n"
"	background-color: transparent;\n"
"	color: #fff;\n"
"	font-size: 14pt;\n"
"	border-color: #000000;\n"
"\n"
"}"));
        label_80 = new QLabel(tab_9);
        label_80->setObjectName(QStringLiteral("label_80"));
        label_80->setGeometry(QRect(520, 100, 81, 25));
        label_80->setFont(font);
        label_80->setStyleSheet(QLatin1String("QLabel\n"
"{\n"
"	background-color: transparent;\n"
"	color: #fff;\n"
"	font-size: 14pt;\n"
"	border-color: #000000;\n"
"\n"
"}"));
        le_price_2 = new QLineEdit(tab_9);
        le_price_2->setObjectName(QStringLiteral("le_price_2"));
        le_price_2->setGeometry(QRect(170, 340, 143, 22));
        le_price_2->setStyleSheet(QStringLiteral("color: rgb(255, 255, 255);"));
        label_81 = new QLabel(tab_9);
        label_81->setObjectName(QStringLiteral("label_81"));
        label_81->setGeometry(QRect(60, 340, 91, 25));
        label_81->setFont(font);
        label_81->setStyleSheet(QLatin1String("QLabel\n"
"{\n"
"	background-color: transparent;\n"
"	color: #fff;\n"
"	font-size: 14pt;\n"
"	border-color: #000000;\n"
"\n"
"}"));
        le_durt_2 = new QLineEdit(tab_9);
        le_durt_2->setObjectName(QStringLiteral("le_durt_2"));
        le_durt_2->setGeometry(QRect(170, 260, 143, 22));
        le_durt_2->setStyleSheet(QStringLiteral("color: rgb(255, 255, 255);"));
        le_sdate_2 = new QLineEdit(tab_9);
        le_sdate_2->setObjectName(QStringLiteral("le_sdate_2"));
        le_sdate_2->setGeometry(QRect(650, 180, 141, 22));
        le_sdate_2->setStyleSheet(QStringLiteral("color: rgb(255, 255, 255);"));
        le_type_2 = new QLineEdit(tab_9);
        le_type_2->setObjectName(QStringLiteral("le_type_2"));
        le_type_2->setGeometry(QRect(170, 180, 143, 22));
        le_type_2->setStyleSheet(QStringLiteral("color: rgb(255, 255, 255);"));
        label_82 = new QLabel(tab_9);
        label_82->setObjectName(QStringLiteral("label_82"));
        label_82->setGeometry(QRect(500, 170, 171, 31));
        label_82->setFont(font);
        label_82->setStyleSheet(QLatin1String("QLabel\n"
"{\n"
"	background-color: transparent;\n"
"	color: #fff;\n"
"	font-size: 14pt;\n"
"	border-color: #000000;\n"
"\n"
"}"));
        label_83 = new QLabel(tab_9);
        label_83->setObjectName(QStringLiteral("label_83"));
        label_83->setGeometry(QRect(50, 100, 91, 25));
        label_83->setFont(font);
        label_83->setStyleSheet(QLatin1String("QLabel\n"
"{\n"
"	background-color: transparent;\n"
"	color: #fff;\n"
"	font-size: 14pt;\n"
"	border-color: #000000;\n"
"\n"
"}\n"
""));
        label_84 = new QLabel(tab_9);
        label_84->setObjectName(QStringLiteral("label_84"));
        label_84->setGeometry(QRect(50, 260, 111, 25));
        label_84->setFont(font);
        label_84->setStyleSheet(QLatin1String("QLabel\n"
"{\n"
"	background-color: transparent;\n"
"	color: #fff;\n"
"	font-size: 14pt;\n"
"	border-color: #000000;\n"
"\n"
"}\n"
""));
        le_num_3 = new QLineEdit(tab_9);
        le_num_3->setObjectName(QStringLiteral("le_num_3"));
        le_num_3->setGeometry(QRect(170, 100, 143, 22));
        le_num_3->setStyleSheet(QStringLiteral("color: rgb(255, 255, 255);"));
        comboBox_4 = new QComboBox(tab_9);
        comboBox_4->setObjectName(QStringLiteral("comboBox_4"));
        comboBox_4->setGeometry(QRect(650, 100, 141, 22));
        comboBox_4->setStyleSheet(QStringLiteral("color: rgb(255, 255, 255);"));
        tabWidget_3->addTab(tab_9, QString());
        tab_10 = new QWidget();
        tab_10->setObjectName(QStringLiteral("tab_10"));
        tab_10->setStyleSheet(QLatin1String("QWidget\n"
"{\n"
"	background-color: QLinearGradient(x1:0, y1:0, x2:0, y2:1, stop:1 #212121, stop:.4 #343434);\n"
"	color: #000000;\n"
"	border-color: #000000;\n"
"\n"
"}"));
        tab_subscriptions_2 = new QTableView(tab_10);
        tab_subscriptions_2->setObjectName(QStringLiteral("tab_subscriptions_2"));
        tab_subscriptions_2->setGeometry(QRect(0, 0, 961, 251));
        tab_subscriptions_2->setStyleSheet(QLatin1String("QTableView {border: 3px solid #C8952F;text-align: top;padding: 4px;border-radius: 7px;border-bottom-left-radius: 7px;background: QLinearGradient( x1: 0, y1: 0, x2: 1, y2: 0,stop: 0 #fff, stop: 1 #eee,stop: 0.5 #ddd,stop: 1 #eee );width: 15px;}\n"
"QTableView::item:focus{selection-background-color: yellow;}\n"
"\n"
"\n"
" QScrollBar{\n"
"         background: QLinearGradient( x1: 0, y1: 0, x2: 1, y2: 0,stop: 0 #fff, stop: 1 #eee,stop: 0.5 #ddd,stop: 1 #eee );\n"
" }\n"
"\n"
" QScrollBar:vertical {\n"
"     border: 3px solid #C8952F;\n"
"     padding: 4px;\n"
"     border-radius: 7px;\n"
"     border-bottom-left-radius: 7px;\n"
"     background: QLinearGradient( x1: 0, y1: 0, x2: 1, y2: 0,stop: 0 #fff, stop: 1 #eee,stop: 0.5 #ddd,stop: 1 #eee );\n"
"     width: 45px;\n"
"     margin: 48px 0 48px 0;\n"
" }\n"
"\n"
" QScrollBar::handle:vertical {\n"
"     background: #C8952F;\n"
"     border: 3px solid #C8952F;\n"
"     padding: 0px;\n"
"     border-radius: 7px;\n"
"     border-bottom-left-radius: 7px;\n"
"     min"
                        "-height: 40px;\n"
" }\n"
" QScrollBar::add-line:vertical {\n"
"     background: #C8952F;\n"
"     border: 3px solid #C8952F;\n"
"     padding: 0px;\n"
"     border-radius: 7px;\n"
"     border-bottom-left-radius: 7px;\n"
"     height: 40px;\n"
"     subcontrol-position: bottom;\n"
"     subcontrol-origin: margin;\n"
" }\n"
"\n"
" QScrollBar::sub-line:vertical {\n"
"     background: #C8952F;\n"
"     border: 3px solid #C8952F;\n"
"     padding: 0px;\n"
"     border-radius: 7px;\n"
"     border-bottom-left-radius: 7px;\n"
"     height: 40px;\n"
"     subcontrol-position: top;\n"
"     subcontrol-origin: margin;\n"
" }\n"
" QScrollBar::up-arrow:vertical, QScrollBar::down-arrow:vertical {\n"
"     border: 2px solid grey;\n"
"     width: 3px;\n"
"     height: 3px;\n"
"     background: white;\n"
" }\n"
"\n"
" QScrollBar::add-page:vertical, QScrollBar::sub-page:vertical {\n"
"     background: none;\n"
" }\n"
" QScrollBar:horizental {\n"
"     border: 3px solid #C8952F;\n"
"     padding: 4px;\n"
"     border-radius: 7"
                        "px;\n"
"     border-bottom-left-radius: 7px;\n"
"     background: QLinearGradient( x1: 0, y1: 0, x2: 1, y2: 0,stop: 0 #fff, stop: 1 #eee,stop: 0.5 #ddd,stop: 1 #eee );\n"
"     width: 45px;\n"
"     margin: 48px 0 48px 0;\n"
" }\n"
"\n"
" QScrollBar::handle:horizental {\n"
"     background: #C8952F;\n"
"     border: 3px solid #C8952F;\n"
"     padding: 0px;\n"
"     border-radius: 7px;\n"
"     border-bottom-left-radius: 7px;\n"
"     min-height: 40px;\n"
" }\n"
" QScrollBar::add-line:horizental {\n"
"     background: #C8952F;\n"
"     border: 3px solid #C8952F;\n"
"     padding: 0px;\n"
"     border-radius: 7px;\n"
"     border-bottom-left-radius: 7px;\n"
"     height: 40px;\n"
"     subcontrol-position: bottom;\n"
"     subcontrol-origin: margin;\n"
" }\n"
"\n"
" QScrollBar::sub-line:horizental {\n"
"     background: #C8952F;\n"
"     border: 3px solid #C8952F;\n"
"     padding: 0px;\n"
"     border-radius: 7px;\n"
"     border-bottom-left-radius: 7px;\n"
"     height: 40px;\n"
"     subcontrol-position: top"
                        ";\n"
"     subcontrol-origin: margin;\n"
" }\n"
" QScrollBar::up-arrow:horizental, QScrollBar::down-arrow:horizental{\n"
"     border: 2px solid grey;\n"
"     width: 3px;\n"
"     height: 3px;\n"
"     background: white;\n"
" }\n"
"\n"
" QScrollBar::add-page:horizental, QScrollBar::sub-page:horizental {\n"
"     background: none;\n"
" }"));
        sortByType_2 = new QPushButton(tab_10);
        sortByType_2->setObjectName(QStringLiteral("sortByType_2"));
        sortByType_2->setGeometry(QRect(180, 520, 131, 28));
        sortByType_2->setStyleSheet(QLatin1String("QPushButton\n"
"{background-color: rgb(200,133,0);\n"
"color : white;\n"
"font: 10pt Arial;\n"
"            border-radius: 4px;\n"
"            text-shadow: 0 1px 1px rgba(0, 0, 0, 0.2);\n"
"border: 2px solid rgb(200,133,0);\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"border: 2px solid rgb(200,146,0);\n"
"background-color : rgb(200,149,47);\n"
"}\n"
""));
        sortById_2 = new QPushButton(tab_10);
        sortById_2->setObjectName(QStringLiteral("sortById_2"));
        sortById_2->setGeometry(QRect(40, 520, 93, 28));
        sortById_2->setStyleSheet(QLatin1String("QPushButton\n"
"{background-color: rgb(200,133,0);\n"
"color : white;\n"
"font: 10pt Arial;\n"
"            border-radius: 4px;\n"
"            text-shadow: 0 1px 1px rgba(0, 0, 0, 0.2);\n"
"border: 2px solid rgb(200,133,0);\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"border: 2px solid rgb(200,146,0);\n"
"background-color : rgb(200,149,47);\n"
"}"));
        sortByPrice_2 = new QPushButton(tab_10);
        sortByPrice_2->setObjectName(QStringLiteral("sortByPrice_2"));
        sortByPrice_2->setGeometry(QRect(360, 520, 131, 28));
        sortByPrice_2->setStyleSheet(QLatin1String("QPushButton\n"
"{background-color: rgb(200,133,0);\n"
"color : white;\n"
"font: 10pt Arial;\n"
"            border-radius: 4px;\n"
"            text-shadow: 0 1px 1px rgba(0, 0, 0, 0.2);\n"
"border: 2px solid rgb(200,133,0);\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"border: 2px solid rgb(200,146,0);\n"
"background-color : rgb(200,149,47);\n"
"}\n"
""));
        searchnum_2 = new QPushButton(tab_10);
        searchnum_2->setObjectName(QStringLiteral("searchnum_2"));
        searchnum_2->setGeometry(QRect(400, 320, 93, 28));
        searchnum_2->setStyleSheet(QLatin1String("QPushButton\n"
"{background-color: rgb(200,133,0);\n"
"color : white;\n"
"font: 10pt Arial;\n"
"            border-radius: 4px;\n"
"            text-shadow: 0 1px 1px rgba(0, 0, 0, 0.2);\n"
"border: 2px solid rgb(200,133,0);\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"border: 2px solid rgb(200,146,0);\n"
"background-color : rgb(200,149,47);\n"
"}"));
        label_85 = new QLabel(tab_10);
        label_85->setObjectName(QStringLiteral("label_85"));
        label_85->setGeometry(QRect(40, 320, 161, 20));
        label_85->setFont(font);
        label_85->setStyleSheet(QLatin1String("QLabel\n"
"{\n"
"	background-color: transparent;\n"
"	color: #fff;\n"
"	font-size: 14pt;\n"
"	border-color: #000000;\n"
"\n"
"}"));
        numtosearch_2 = new QLineEdit(tab_10);
        numtosearch_2->setObjectName(QStringLiteral("numtosearch_2"));
        numtosearch_2->setGeometry(QRect(240, 320, 111, 22));
        numtosearch_2->setStyleSheet(QStringLiteral("color: rgb(255, 255, 255);"));
        label_86 = new QLabel(tab_10);
        label_86->setObjectName(QStringLiteral("label_86"));
        label_86->setGeometry(QRect(40, 370, 141, 20));
        label_86->setFont(font);
        label_86->setStyleSheet(QLatin1String("QLabel\n"
"{\n"
"	background-color: transparent;\n"
"	color: #fff;\n"
"	font-size: 14pt;\n"
"	border-color: #000000;\n"
"\n"
"}"));
        typetosearch_2 = new QLineEdit(tab_10);
        typetosearch_2->setObjectName(QStringLiteral("typetosearch_2"));
        typetosearch_2->setGeometry(QRect(240, 370, 113, 22));
        typetosearch_2->setStyleSheet(QStringLiteral("color: rgb(255, 255, 255);"));
        searchType_2 = new QPushButton(tab_10);
        searchType_2->setObjectName(QStringLiteral("searchType_2"));
        searchType_2->setGeometry(QRect(400, 370, 93, 28));
        searchType_2->setStyleSheet(QLatin1String("QPushButton\n"
"{background-color: rgb(200,133,0);\n"
"color : white;\n"
"font: 10pt Arial;\n"
"            border-radius: 4px;\n"
"            text-shadow: 0 1px 1px rgba(0, 0, 0, 0.2);\n"
"border: 2px solid rgb(200,133,0);\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"border: 2px solid rgb(200,146,0);\n"
"background-color : rgb(200,149,47);\n"
"}"));
        label_87 = new QLabel(tab_10);
        label_87->setObjectName(QStringLiteral("label_87"));
        label_87->setGeometry(QRect(40, 420, 181, 21));
        label_87->setFont(font);
        label_87->setStyleSheet(QLatin1String("QLabel\n"
"{\n"
"	background-color: transparent;\n"
"	color: #fff;\n"
"	font-size: 14pt;\n"
"	border-color: #000000;\n"
"\n"
"}"));
        startdatetosearch_2 = new QLineEdit(tab_10);
        startdatetosearch_2->setObjectName(QStringLiteral("startdatetosearch_2"));
        startdatetosearch_2->setGeometry(QRect(240, 420, 113, 22));
        startdatetosearch_2->setStyleSheet(QLatin1String("color: rgb(255, 255, 255);\n"
""));
        searchStartDate_2 = new QPushButton(tab_10);
        searchStartDate_2->setObjectName(QStringLiteral("searchStartDate_2"));
        searchStartDate_2->setGeometry(QRect(400, 420, 93, 28));
        searchStartDate_2->setStyleSheet(QLatin1String("QPushButton\n"
"{background-color: rgb(200,133,0);\n"
"color : white;\n"
"font: 10pt Arial;\n"
"            border-radius: 4px;\n"
"            text-shadow: 0 1px 1px rgba(0, 0, 0, 0.2);\n"
"border: 2px solid rgb(200,133,0);\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"border: 2px solid rgb(200,146,0);\n"
"background-color : rgb(200,149,47);\n"
"}"));
        label_88 = new QLabel(tab_10);
        label_88->setObjectName(QStringLiteral("label_88"));
        label_88->setGeometry(QRect(635, 270, 91, 20));
        label_88->setFont(font);
        label_88->setStyleSheet(QLatin1String("QLabel\n"
"{\n"
"	background-color: transparent;\n"
"	color: #fff;\n"
"	font-size: 14pt;\n"
"	border-color: #000000;\n"
"\n"
"}"));
        le_duration_modif_2 = new QLineEdit(tab_10);
        le_duration_modif_2->setObjectName(QStringLiteral("le_duration_modif_2"));
        le_duration_modif_2->setGeometry(QRect(740, 330, 171, 22));
        le_duration_modif_2->setStyleSheet(QStringLiteral("color: rgb(255, 255, 255);"));
        le_edate_modif_2 = new QLineEdit(tab_10);
        le_edate_modif_2->setObjectName(QStringLiteral("le_edate_modif_2"));
        le_edate_modif_2->setGeometry(QRect(740, 460, 171, 22));
        le_edate_modif_2->setStyleSheet(QStringLiteral("color: rgb(255, 255, 255);"));
        le_sdate_modif_2 = new QLineEdit(tab_10);
        le_sdate_modif_2->setObjectName(QStringLiteral("le_sdate_modif_2"));
        le_sdate_modif_2->setGeometry(QRect(740, 420, 171, 22));
        le_sdate_modif_2->setStyleSheet(QStringLiteral("color: rgb(255, 255, 255);"));
        label_89 = new QLabel(tab_10);
        label_89->setObjectName(QStringLiteral("label_89"));
        label_89->setGeometry(QRect(640, 360, 71, 21));
        label_89->setFont(font);
        label_89->setStyleSheet(QLatin1String("QLabel\n"
"{\n"
"	background-color: transparent;\n"
"	color: #fff;\n"
"	font-size: 14pt;\n"
"	border-color: #000000;\n"
"\n"
"}"));
        le_type_modif_2 = new QLineEdit(tab_10);
        le_type_modif_2->setObjectName(QStringLiteral("le_type_modif_2"));
        le_type_modif_2->setGeometry(QRect(740, 300, 171, 22));
        le_type_modif_2->setStyleSheet(QStringLiteral("color: rgb(255, 255, 255);"));
        label_90 = new QLabel(tab_10);
        label_90->setObjectName(QStringLiteral("label_90"));
        label_90->setGeometry(QRect(620, 420, 151, 21));
        label_90->setFont(font);
        label_90->setStyleSheet(QLatin1String("QLabel\n"
"{\n"
"	background-color: transparent;\n"
"	color: #fff;\n"
"	font-size: 14pt;\n"
"	border-color: #000000;\n"
"\n"
"}"));
        label_91 = new QLabel(tab_10);
        label_91->setObjectName(QStringLiteral("label_91"));
        label_91->setGeometry(QRect(620, 460, 101, 16));
        label_91->setFont(font);
        label_91->setStyleSheet(QLatin1String("QLabel\n"
"{\n"
"	background-color: transparent;\n"
"	color: #fff;\n"
"	font-size: 14pt;\n"
"	border-color: #000000;\n"
"\n"
"}"));
        label_92 = new QLabel(tab_10);
        label_92->setObjectName(QStringLiteral("label_92"));
        label_92->setGeometry(QRect(640, 290, 91, 31));
        label_92->setFont(font);
        label_92->setStyleSheet(QLatin1String("QLabel\n"
"{\n"
"	background-color: transparent;\n"
"	color: #fff;\n"
"	font-size: 14pt;\n"
"	border-color: #000000;\n"
"\n"
"}"));
        le_price_modif_2 = new QLineEdit(tab_10);
        le_price_modif_2->setObjectName(QStringLiteral("le_price_modif_2"));
        le_price_modif_2->setGeometry(QRect(740, 360, 171, 22));
        le_price_modif_2->setStyleSheet(QStringLiteral("color: rgb(255, 255, 255);"));
        label_93 = new QLabel(tab_10);
        label_93->setObjectName(QStringLiteral("label_93"));
        label_93->setGeometry(QRect(630, 380, 131, 31));
        label_93->setFont(font);
        label_93->setStyleSheet(QLatin1String("QLabel\n"
"{\n"
"	background-color: transparent;\n"
"	color: #fff;\n"
"	font-size: 14pt;\n"
"	border-color: #000000;\n"
"\n"
"}"));
        label_94 = new QLabel(tab_10);
        label_94->setObjectName(QStringLiteral("label_94"));
        label_94->setGeometry(QRect(630, 330, 91, 21));
        label_94->setFont(font);
        label_94->setStyleSheet(QLatin1String("QLabel\n"
"{\n"
"	background-color: transparent;\n"
"	color: #fff;\n"
"	font-size: 14pt;\n"
"	border-color: #000000;\n"
"\n"
"}"));
        le_idBuy_modif_2 = new QLineEdit(tab_10);
        le_idBuy_modif_2->setObjectName(QStringLiteral("le_idBuy_modif_2"));
        le_idBuy_modif_2->setGeometry(QRect(740, 390, 171, 22));
        le_idBuy_modif_2->setStyleSheet(QStringLiteral("color: rgb(255, 255, 255);"));
        pb_delete_2 = new QPushButton(tab_10);
        pb_delete_2->setObjectName(QStringLiteral("pb_delete_2"));
        pb_delete_2->setGeometry(QRect(870, 550, 93, 28));
        pb_delete_2->setStyleSheet(QLatin1String("QPushButton\n"
"{background-color: rgb(200,133,0);\n"
"color : white;\n"
"font: 10pt Arial;\n"
"            border-radius: 4px;\n"
"            text-shadow: 0 1px 1px rgba(0, 0, 0, 0.2);\n"
"border: 2px solid rgb(200,133,0);\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"border: 2px solid rgb(200,146,0);\n"
"background-color : rgb(200,149,47);\n"
"}"));
        le_num_modif_2 = new QLineEdit(tab_10);
        le_num_modif_2->setObjectName(QStringLiteral("le_num_modif_2"));
        le_num_modif_2->setGeometry(QRect(740, 270, 171, 22));
        le_num_modif_2->setStyleSheet(QStringLiteral("color: rgb(255, 255, 255);"));
        pd_update_2 = new QPushButton(tab_10);
        pd_update_2->setObjectName(QStringLiteral("pd_update_2"));
        pd_update_2->setGeometry(QRect(780, 500, 93, 28));
        pd_update_2->setStyleSheet(QLatin1String("QPushButton\n"
"{background-color: rgb(200,133,0);\n"
"color : white;\n"
"font: 10pt Arial;\n"
"            border-radius: 4px;\n"
"            text-shadow: 0 1px 1px rgba(0, 0, 0, 0.2);\n"
"border: 2px solid rgb(200,133,0);\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"border: 2px solid rgb(200,146,0);\n"
"background-color : rgb(200,149,47);\n"
"}"));
        comboBox_5 = new QComboBox(tab_10);
        comboBox_5->setObjectName(QStringLiteral("comboBox_5"));
        comboBox_5->setGeometry(QRect(740, 550, 73, 22));
        comboBox_5->setStyleSheet(QStringLiteral("color: rgb(255, 255, 255);"));
        pb_read_2 = new QPushButton(tab_10);
        pb_read_2->setObjectName(QStringLiteral("pb_read_2"));
        pb_read_2->setGeometry(QRect(570, 540, 93, 28));
        pb_read_2->setStyleSheet(QLatin1String("QPushButton\n"
"{background-color: rgb(200,133,0);\n"
"color : white;\n"
"font: 10pt Arial;\n"
"            border-radius: 4px;\n"
"            text-shadow: 0 1px 1px rgba(0, 0, 0, 0.2);\n"
"border: 2px solid rgb(200,133,0);\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"border: 2px solid rgb(200,146,0);\n"
"background-color : rgb(200,149,47);\n"
"}"));
        pbExport_2 = new QPushButton(tab_10);
        pbExport_2->setObjectName(QStringLiteral("pbExport_2"));
        pbExport_2->setGeometry(QRect(500, 280, 93, 28));
        pbExport_2->setStyleSheet(QLatin1String("QPushButton\n"
"{background-color: rgb(200,133,0);\n"
"color : white;\n"
"font: 10pt Arial;\n"
"            border-radius: 4px;\n"
"            text-shadow: 0 1px 1px rgba(0, 0, 0, 0.2);\n"
"border: 2px solid rgb(200,133,0);\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"border: 2px solid rgb(200,146,0);\n"
"background-color : rgb(200,149,47);\n"
"}\n"
""));
        tabWidget_3->addTab(tab_10, QString());
        tab_11 = new QWidget();
        tab_11->setObjectName(QStringLiteral("tab_11"));
        plot_2 = new QCustomPlot(tab_11);
        plot_2->setObjectName(QStringLiteral("plot_2"));
        plot_2->setGeometry(QRect(60, 40, 961, 511));
        tabWidget_3->addTab(tab_11, QString());
        tab_12 = new QWidget();
        tab_12->setObjectName(QStringLiteral("tab_12"));
        pb_history_2 = new QPushButton(tab_12);
        pb_history_2->setObjectName(QStringLiteral("pb_history_2"));
        pb_history_2->setGeometry(QRect(460, 50, 141, 28));
        pb_history_2->setStyleSheet(QLatin1String("QPushButton\n"
"{background-color: rgb(200,133,0);\n"
"color : white;\n"
"font: 10pt Arial;\n"
"            border-radius: 4px;\n"
"            text-shadow: 0 1px 1px rgba(0, 0, 0, 0.2);\n"
"border: 2px solid rgb(200,133,0);\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"border: 2px solid rgb(200,146,0);\n"
"background-color : rgb(200,149,47);\n"
"}\n"
"\n"
"\n"
""));
        textBrowser_2 = new QTextBrowser(tab_12);
        textBrowser_2->setObjectName(QStringLiteral("textBrowser_2"));
        textBrowser_2->setGeometry(QRect(150, 100, 761, 411));
        textBrowser_2->setStyleSheet(QLatin1String("background-color: rgb(250,250,250);\n"
"color : red;\n"
"font: 10pt Arial;\n"
"            border-radius: 4px;\n"
"            text-shadow: 0 1px 1px rgba(0, 0, 0, 0.2);\n"
"border: 2px solid rgb(200,133,0);"));
        tabWidget_3->addTab(tab_12, QString());
        stackedWidget->addWidget(page_2);
        page_3 = new QWidget();
        page_3->setObjectName(QStringLiteral("page_3"));
        page_3->setStyleSheet(QLatin1String("\n"
"	background-color: QLinearGradient(x1:0, y1:0, x2:0, y2:1, stop:1 #212121, stop:.4 #343434);\n"
"	color: #000000;\n"
"	border-color: #000000;"));
        groupBox_2 = new QGroupBox(page_3);
        groupBox_2->setObjectName(QStringLiteral("groupBox_2"));
        groupBox_2->setGeometry(QRect(-10, 0, 1221, 721));
        pushButton_12 = new QPushButton(groupBox_2);
        pushButton_12->setObjectName(QStringLiteral("pushButton_12"));
        pushButton_12->setGeometry(QRect(0, 660, 211, 51));
        pushButton_12->setStyleSheet(QLatin1String("\n"
"background-color: qlineargradient(spread:repeat, x1:1, y1:0, x2:1, y2:1, stop:0 rgba(254, 171, 66, 255),stop:1 rgba(255, 153, 0, 255));\n"
"	color: #000;\n"
"	font-size: 14pt;\n"
"	border-radius: 4px;\n"
"	padding: 10px;\n"
""));
        pushButton_12->setIcon(icon2);
        tabWidget_2 = new QTabWidget(groupBox_2);
        tabWidget_2->setObjectName(QStringLiteral("tabWidget_2"));
        tabWidget_2->setGeometry(QRect(10, 17, 1191, 641));
        tabWidget_2->setStyleSheet(QLatin1String("border: 1px solid qlineargradient(spread:repeat, x1:1, y1:0, x2:1, y2:1, stop:0 rgba(254, 171, 66, 255),stop:1 rgba(255, 153, 0, 255));\n"
"    top: 1px;"));
        tab = new QWidget();
        tab->setObjectName(QStringLiteral("tab"));
        tab->setStyleSheet(QLatin1String("\n"
"	background-color: QLinearGradient(x1:0, y1:0, x2:0, y2:1, stop:1 #212121, stop:.4 #343434);\n"
"	color: #000000;\n"
"	border-color: #000000;"));
        tabagent = new QTableView(tab);
        tabagent->setObjectName(QStringLiteral("tabagent"));
        tabagent->setGeometry(QRect(0, 0, 1051, 211));
        tabagent->setStyleSheet(QLatin1String("QTableView {border: 3px solid #5E749C;text-align: top;padding: 4px;border-radius: 7px;border-bottom-left-radius: 7px;background: QLinearGradient( x1: 0, y1: 0, x2: 1, y2: 0,stop: 0 #fff, stop: 1 #eee,stop: 0.5 #ddd,stop: 1 #eee );width: 15px;}\n"
"QTableView::item:focus{selection-background-color: yellow;}\n"
"\n"
"\n"
" QScrollBar{\n"
"         background: QLinearGradient( x1: 0, y1: 0, x2: 1, y2: 0,stop: 0 #fff, stop: 1 #eee,stop: 0.5 #ddd,stop: 1 #eee );\n"
" }\n"
"\n"
" QScrollBar:vertical {\n"
"     border: 3px solid #5E749C;\n"
"     padding: 4px;\n"
"     border-radius: 7px;\n"
"     border-bottom-left-radius: 7px;\n"
"     background: QLinearGradient( x1: 0, y1: 0, x2: 1, y2: 0,stop: 0 #fff, stop: 1 #eee,stop: 0.5 #ddd,stop: 1 #eee );\n"
"     width: 45px;\n"
"     margin: 48px 0 48px 0;\n"
" }\n"
"\n"
" QScrollBar::handle:vertical {\n"
"     background: dark blue;\n"
"     border: 3px solid #5E749C;\n"
"     padding: 0px;\n"
"     border-radius: 7px;\n"
"     border-bottom-left-radius: 7px;\n"
"     m"
                        "in-height: 40px;\n"
" }\n"
" QScrollBar::add-line:vertical {\n"
"     background: dark blue;\n"
"     border: 3px solid #5E749C;\n"
"     padding: 0px;\n"
"     border-radius: 7px;\n"
"     border-bottom-left-radius: 7px;\n"
"     height: 40px;\n"
"     subcontrol-position: bottom;\n"
"     subcontrol-origin: margin;\n"
" }\n"
"\n"
" QScrollBar::sub-line:vertical {\n"
"     background: dark blue;\n"
"     border: 3px solid #5E749C;\n"
"     padding: 0px;\n"
"     border-radius: 7px;\n"
"     border-bottom-left-radius: 7px;\n"
"     height: 40px;\n"
"     subcontrol-position: top;\n"
"     subcontrol-origin: margin;\n"
" }\n"
" QScrollBar::up-arrow:vertical, QScrollBar::down-arrow:vertical {\n"
"     border: 2px solid grey;\n"
"     width: 3px;\n"
"     height: 3px;\n"
"     background: white;\n"
" }\n"
"\n"
" QScrollBar::add-page:vertical, QScrollBar::sub-page:vertical {\n"
"     background: none;\n"
" }\n"
"\n"
""));
        label_25 = new QLabel(tab);
        label_25->setObjectName(QStringLiteral("label_25"));
        label_25->setGeometry(QRect(10, 570, 111, 31));
        label_25->setStyleSheet(QLatin1String("background-color: transparent;\n"
"	color: #fff;\n"
"	font-size: 14pt;\n"
"	border-color: #000000;"));
        lineEdit_password_2 = new QLineEdit(tab);
        lineEdit_password_2->setObjectName(QStringLiteral("lineEdit_password_2"));
        lineEdit_password_2->setGeometry(QRect(410, 510, 151, 41));
        lineEdit_password_2->setStyleSheet(QStringLiteral("color :rgb(255, 255, 255)"));
        label_23 = new QLabel(tab);
        label_23->setObjectName(QStringLiteral("label_23"));
        label_23->setGeometry(QRect(290, 360, 111, 31));
        label_23->setStyleSheet(QLatin1String("background-color: transparent;\n"
"	color: #fff;\n"
"	font-size: 14pt;\n"
"	border-color: #000000;"));
        label_19 = new QLabel(tab);
        label_19->setObjectName(QStringLiteral("label_19"));
        label_19->setGeometry(QRect(0, 360, 111, 31));
        label_19->setStyleSheet(QLatin1String("background-color: transparent;\n"
"	color: #fff;\n"
"	font-size: 14pt;\n"
"	border-color: #000000;"));
        lineEdit_mail_2 = new QLineEdit(tab);
        lineEdit_mail_2->setObjectName(QStringLiteral("lineEdit_mail_2"));
        lineEdit_mail_2->setGeometry(QRect(130, 560, 151, 41));
        lineEdit_mail_2->setStyleSheet(QStringLiteral("color :rgb(255, 255, 255)"));
        lineEdit_adress_2 = new QLineEdit(tab);
        lineEdit_adress_2->setObjectName(QStringLiteral("lineEdit_adress_2"));
        lineEdit_adress_2->setGeometry(QRect(410, 350, 151, 41));
        lineEdit_adress_2->setStyleSheet(QStringLiteral("color :rgb(255, 255, 255)"));
        label_21 = new QLabel(tab);
        label_21->setObjectName(QStringLiteral("label_21"));
        label_21->setGeometry(QRect(0, 470, 111, 31));
        label_21->setStyleSheet(QLatin1String("background-color: transparent;\n"
"	color: #fff;\n"
"	font-size: 14pt;\n"
"	border-color: #000000;"));
        label_24 = new QLabel(tab);
        label_24->setObjectName(QStringLiteral("label_24"));
        label_24->setGeometry(QRect(290, 410, 111, 31));
        label_24->setStyleSheet(QLatin1String("background-color: transparent;\n"
"	color: #fff;\n"
"	font-size: 14pt;\n"
"	border-color: #000000;"));
        lineEdit_lastname_2 = new QLineEdit(tab);
        lineEdit_lastname_2->setObjectName(QStringLiteral("lineEdit_lastname_2"));
        lineEdit_lastname_2->setGeometry(QRect(130, 410, 151, 41));
        lineEdit_lastname_2->setStyleSheet(QStringLiteral("color :rgb(255, 255, 255)"));
        label_20 = new QLabel(tab);
        label_20->setObjectName(QStringLiteral("label_20"));
        label_20->setGeometry(QRect(290, 460, 111, 31));
        label_20->setStyleSheet(QLatin1String("background-color: transparent;\n"
"	color: #fff;\n"
"	font-size: 14pt;\n"
"	border-color: #000000;"));
        lineEdit_login_2 = new QLineEdit(tab);
        lineEdit_login_2->setObjectName(QStringLiteral("lineEdit_login_2"));
        lineEdit_login_2->setGeometry(QRect(410, 460, 151, 41));
        lineEdit_login_2->setStyleSheet(QStringLiteral("color :rgb(255, 255, 255)"));
        lineEdit_name_2 = new QLineEdit(tab);
        lineEdit_name_2->setObjectName(QStringLiteral("lineEdit_name_2"));
        lineEdit_name_2->setGeometry(QRect(130, 460, 151, 41));
        lineEdit_name_2->setStyleSheet(QStringLiteral("color :rgb(255, 255, 255)"));
        lineEdit_number_2 = new QLineEdit(tab);
        lineEdit_number_2->setObjectName(QStringLiteral("lineEdit_number_2"));
        lineEdit_number_2->setGeometry(QRect(130, 510, 151, 41));
        lineEdit_number_2->setStyleSheet(QStringLiteral("color :rgb(255, 255, 255)"));
        lineEdit_function_2 = new QLineEdit(tab);
        lineEdit_function_2->setObjectName(QStringLiteral("lineEdit_function_2"));
        lineEdit_function_2->setGeometry(QRect(410, 400, 151, 41));
        lineEdit_function_2->setStyleSheet(QStringLiteral("color :rgb(255, 255, 255)"));
        label_17 = new QLabel(tab);
        label_17->setObjectName(QStringLiteral("label_17"));
        label_17->setGeometry(QRect(10, 520, 111, 31));
        label_17->setStyleSheet(QLatin1String("background-color: transparent;\n"
"	color: #fff;\n"
"	font-size: 14pt;\n"
"	border-color: #000000;"));
        label_18 = new QLabel(tab);
        label_18->setObjectName(QStringLiteral("label_18"));
        label_18->setGeometry(QRect(0, 410, 111, 31));
        label_18->setStyleSheet(QLatin1String("background-color: transparent;\n"
"	color: #fff;\n"
"	font-size: 14pt;\n"
"	border-color: #000000;"));
        lineEdit_cin_3 = new QLineEdit(tab);
        lineEdit_cin_3->setObjectName(QStringLiteral("lineEdit_cin_3"));
        lineEdit_cin_3->setGeometry(QRect(130, 350, 151, 41));
        lineEdit_cin_3->setStyleSheet(QStringLiteral("color :rgb(255, 255, 255)"));
        label_22 = new QLabel(tab);
        label_22->setObjectName(QStringLiteral("label_22"));
        label_22->setGeometry(QRect(290, 510, 111, 31));
        label_22->setStyleSheet(QLatin1String("background-color: transparent;\n"
"	color: #fff;\n"
"	font-size: 14pt;\n"
"	border-color: #000000;"));
        pushButton_6 = new QPushButton(tab);
        pushButton_6->setObjectName(QStringLiteral("pushButton_6"));
        pushButton_6->setGeometry(QRect(640, 540, 131, 61));
        pushButton_6->setStyleSheet(QLatin1String("\n"
"background-color: qlineargradient(spread:repeat, x1:1, y1:0, x2:1, y2:1, stop:0 rgba(254, 171, 66, 255),stop:1 rgba(255, 153, 0, 255));\n"
"	color: #000;\n"
"	font-size: 14pt;\n"
"	border-radius: 4px;\n"
"	padding: 10px;\n"
""));
        pushButton_6->setIcon(icon1);
        pushButton_6->setCheckable(false);
        comboBox_agent = new QComboBox(tab);
        comboBox_agent->setObjectName(QStringLiteral("comboBox_agent"));
        comboBox_agent->setGeometry(QRect(400, 560, 161, 41));
        comboBox_agent->setStyleSheet(QStringLiteral("color :rgb(255, 255, 255)"));
        label = new QLabel(tab);
        label->setObjectName(QStringLiteral("label"));
        label->setGeometry(QRect(300, 560, 111, 41));
        label->setStyleSheet(QLatin1String("background-color: transparent;\n"
"	color: #fff;\n"
"	font-size: 14pt;\n"
"	border-color: #000000;"));
        pushButton_15 = new QPushButton(tab);
        pushButton_15->setObjectName(QStringLiteral("pushButton_15"));
        pushButton_15->setGeometry(QRect(10, 220, 151, 51));
        pushButton_15->setStyleSheet(QLatin1String("\n"
"background-color: qlineargradient(spread:repeat, x1:1, y1:0, x2:1, y2:1, stop:0 rgba(254, 171, 66, 255),stop:1 rgba(255, 153, 0, 255));\n"
"	color: #000;\n"
"	font-size: 14pt;\n"
"	border-radius: 4px;\n"
"	padding: 10px;"));
        pushButton_16 = new QPushButton(tab);
        pushButton_16->setObjectName(QStringLiteral("pushButton_16"));
        pushButton_16->setGeometry(QRect(170, 220, 151, 51));
        pushButton_16->setStyleSheet(QLatin1String("\n"
"background-color: qlineargradient(spread:repeat, x1:1, y1:0, x2:1, y2:1, stop:0 rgba(254, 171, 66, 255),stop:1 rgba(255, 153, 0, 255));\n"
"	color: #000;\n"
"	font-size: 14pt;\n"
"	border-radius: 4px;\n"
"	padding: 10px;"));
        pushButton_17 = new QPushButton(tab);
        pushButton_17->setObjectName(QStringLiteral("pushButton_17"));
        pushButton_17->setGeometry(QRect(330, 220, 151, 51));
        pushButton_17->setStyleSheet(QLatin1String("\n"
"background-color: qlineargradient(spread:repeat, x1:1, y1:0, x2:1, y2:1, stop:0 rgba(254, 171, 66, 255),stop:1 rgba(255, 153, 0, 255));\n"
"	color: #000;\n"
"	font-size: 14pt;\n"
"	border-radius: 4px;\n"
"	padding: 10px;"));
        lineEdit_cherche = new QLineEdit(tab);
        lineEdit_cherche->setObjectName(QStringLiteral("lineEdit_cherche"));
        lineEdit_cherche->setGeometry(QRect(850, 270, 191, 41));
        lineEdit_cherche->setStyleSheet(QStringLiteral("color :rgb(255, 255, 255)"));
        label_38 = new QLabel(tab);
        label_38->setObjectName(QStringLiteral("label_38"));
        label_38->setGeometry(QRect(610, 270, 221, 51));
        label_38->setStyleSheet(QLatin1String("background-color: transparent;\n"
"	color: #fff;\n"
"	font-size: 14pt;\n"
"	border-color: #000000;"));
        label_39 = new QLabel(tab);
        label_39->setObjectName(QStringLiteral("label_39"));
        label_39->setGeometry(QRect(610, 330, 221, 51));
        label_39->setStyleSheet(QLatin1String("background-color: transparent;\n"
"	color: #fff;\n"
"	font-size: 14pt;\n"
"	border-color: #000000;"));
        lineEdit_cherche_cin = new QLineEdit(tab);
        lineEdit_cherche_cin->setObjectName(QStringLiteral("lineEdit_cherche_cin"));
        lineEdit_cherche_cin->setGeometry(QRect(850, 340, 191, 41));
        lineEdit_cherche_cin->setStyleSheet(QStringLiteral("color :rgb(255, 255, 255)"));
        pushButton_23 = new QPushButton(tab);
        pushButton_23->setObjectName(QStringLiteral("pushButton_23"));
        pushButton_23->setGeometry(QRect(850, 530, 131, 71));
        pushButton_23->setStyleSheet(QLatin1String("\n"
"background-color: qlineargradient(spread:repeat, x1:1, y1:0, x2:1, y2:1, stop:0 rgba(254, 171, 66, 255),stop:1 rgba(255, 153, 0, 255));\n"
"	color: #000;\n"
"	font-size: 14pt;\n"
"	border-radius: 4px;\n"
"	padding: 10px;\n"
""));
        pushButton_23->setIcon(icon1);
        pushButton_23->setCheckable(false);
        label_40 = new QLabel(tab);
        label_40->setObjectName(QStringLiteral("label_40"));
        label_40->setGeometry(QRect(610, 390, 221, 51));
        label_40->setStyleSheet(QLatin1String("background-color: transparent;\n"
"	color: #fff;\n"
"	font-size: 14pt;\n"
"	border-color: #000000;"));
        lineEdit_cherche_function = new QLineEdit(tab);
        lineEdit_cherche_function->setObjectName(QStringLiteral("lineEdit_cherche_function"));
        lineEdit_cherche_function->setGeometry(QRect(850, 400, 191, 41));
        lineEdit_cherche_function->setStyleSheet(QStringLiteral("color :rgb(255, 255, 255)"));
        chat_2 = new QPushButton(tab);
        chat_2->setObjectName(QStringLiteral("chat_2"));
        chat_2->setGeometry(QRect(1030, 530, 131, 61));
        chat_2->setStyleSheet(QLatin1String("\n"
"background-color: qlineargradient(spread:repeat, x1:1, y1:0, x2:1, y2:1, stop:0 rgba(254, 171, 66, 255),stop:1 rgba(255, 153, 0, 255));\n"
"	color: #000;\n"
"	font-size: 14pt;\n"
"	border-radius: 4px;\n"
"	padding: 10px;\n"
""));
        chat_2->setIcon(icon1);
        chat_2->setCheckable(false);
        tabWidget_2->addTab(tab, QString());
        tab_5 = new QWidget();
        tab_5->setObjectName(QStringLiteral("tab_5"));
        logout = new QPushButton(tab_5);
        logout->setObjectName(QStringLiteral("logout"));
        logout->setGeometry(QRect(1350, 690, 121, 51));
        logout->setStyleSheet(QLatin1String("background-color: qlineargradient(spread:repeat, x1:1, y1:0, x2:1, y2:1, stop:0 rgba(254, 171, 66, 255),stop:1 rgba(255, 153, 0, 255));\n"
"	color: #000;\n"
"	font-size: 14pt;\n"
"	border-radius: 4px;\n"
"	padding: 10px;\n"
""));
        logout->setIcon(icon3);
        groupBox = new QGroupBox(tab_5);
        groupBox->setObjectName(QStringLiteral("groupBox"));
        groupBox->setGeometry(QRect(10, 20, 1081, 521));
        label_16 = new QLabel(groupBox);
        label_16->setObjectName(QStringLiteral("label_16"));
        label_16->setGeometry(QRect(140, 110, 191, 16));
        label_16->setStyleSheet(QLatin1String("background-color: transparent;\n"
"	color: #fff;\n"
"	font-size: 14pt;\n"
"	border-color: #000000;"));
        pushButton_25 = new QPushButton(groupBox);
        pushButton_25->setObjectName(QStringLiteral("pushButton_25"));
        pushButton_25->setGeometry(QRect(20, 450, 221, 51));
        pushButton_25->setStyleSheet(QLatin1String("background-color: qlineargradient(spread:repeat, x1:1, y1:0, x2:1, y2:1, stop:0 rgba(254, 171, 66, 255),stop:1 rgba(255, 153, 0, 255));\n"
"	color: #000;\n"
"	font-size: 14pt;\n"
"	border-radius: 4px;\n"
"	padding: 10px;\n"
""));
        pushButton_25->setIcon(icon2);
        label_45 = new QLabel(groupBox);
        label_45->setObjectName(QStringLiteral("label_45"));
        label_45->setGeometry(QRect(250, -40, 301, 171));
        label_45->setStyleSheet(QLatin1String("background-color: transparent;\n"
"	color: #fff;\n"
"	font-size: 14pt;\n"
"	border-color: #000000;"));
        agent_cin = new QLineEdit(groupBox);
        agent_cin->setObjectName(QStringLiteral("agent_cin"));
        agent_cin->setGeometry(QRect(140, 100, 151, 41));
        agent_cin->setStyleSheet(QStringLiteral("color :rgb(255, 255, 255)"));
        add_ag = new QPushButton(groupBox);
        add_ag->setObjectName(QStringLiteral("add_ag"));
        add_ag->setGeometry(QRect(340, 430, 171, 71));
        add_ag->setStyleSheet(QLatin1String("\n"
"background-color: qlineargradient(spread:repeat, x1:1, y1:0, x2:1, y2:1, stop:0 rgba(254, 171, 66, 255),stop:1 rgba(255, 153, 0, 255));\n"
"	color: #000;\n"
"	font-size: 14pt;\n"
"	border-radius: 4px;\n"
"	padding: 10px;\n"
""));
        add_ag->setIcon(icon1);
        add_ag->setCheckable(false);
        agent_lastname = new QLineEdit(groupBox);
        agent_lastname->setObjectName(QStringLiteral("agent_lastname"));
        agent_lastname->setGeometry(QRect(140, 160, 151, 41));
        agent_lastname->setStyleSheet(QStringLiteral("color :rgb(255, 255, 255)"));
        agent_mail = new QLineEdit(groupBox);
        agent_mail->setObjectName(QStringLiteral("agent_mail"));
        agent_mail->setGeometry(QRect(140, 340, 151, 41));
        agent_mail->setStyleSheet(QStringLiteral("color :rgb(255, 255, 255)"));
        agent_adress = new QLineEdit(groupBox);
        agent_adress->setObjectName(QStringLiteral("agent_adress"));
        agent_adress->setGeometry(QRect(450, 90, 151, 41));
        agent_adress->setStyleSheet(QStringLiteral("color :rgb(255, 255, 255)"));
        agent_name = new QLineEdit(groupBox);
        agent_name->setObjectName(QStringLiteral("agent_name"));
        agent_name->setGeometry(QRect(140, 220, 151, 41));
        agent_name->setStyleSheet(QStringLiteral("color :rgb(255, 255, 255)"));
        agent_num = new QLineEdit(groupBox);
        agent_num->setObjectName(QStringLiteral("agent_num"));
        agent_num->setGeometry(QRect(140, 280, 151, 41));
        agent_num->setStyleSheet(QStringLiteral("color :rgb(255, 255, 255)"));
        agent_login = new QLineEdit(groupBox);
        agent_login->setObjectName(QStringLiteral("agent_login"));
        agent_login->setGeometry(QRect(440, 220, 151, 41));
        agent_login->setStyleSheet(QStringLiteral("color :rgb(255, 255, 255)"));
        agent_function = new QLineEdit(groupBox);
        agent_function->setObjectName(QStringLiteral("agent_function"));
        agent_function->setGeometry(QRect(450, 150, 151, 41));
        agent_function->setStyleSheet(QStringLiteral("color :rgb(255, 255, 255)"));
        agent_pass = new QLineEdit(groupBox);
        agent_pass->setObjectName(QStringLiteral("agent_pass"));
        agent_pass->setGeometry(QRect(440, 280, 151, 41));
        agent_pass->setStyleSheet(QStringLiteral("color :rgb(255, 255, 255)"));
        label_46 = new QLabel(groupBox);
        label_46->setObjectName(QStringLiteral("label_46"));
        label_46->setGeometry(QRect(20, 170, 111, 31));
        label_46->setStyleSheet(QLatin1String("background-color: transparent;\n"
"	color: #fff;\n"
"	font-size: 14pt;\n"
"	border-color: #000000;"));
        label_47 = new QLabel(groupBox);
        label_47->setObjectName(QStringLiteral("label_47"));
        label_47->setGeometry(QRect(20, 110, 111, 31));
        label_47->setStyleSheet(QLatin1String("background-color: transparent;\n"
"	color: #fff;\n"
"	font-size: 14pt;\n"
"	border-color: #000000;"));
        label_48 = new QLabel(groupBox);
        label_48->setObjectName(QStringLiteral("label_48"));
        label_48->setGeometry(QRect(30, 220, 111, 31));
        label_48->setStyleSheet(QLatin1String("background-color: transparent;\n"
"	color: #fff;\n"
"	font-size: 14pt;\n"
"	border-color: #000000;"));
        label_49 = new QLabel(groupBox);
        label_49->setObjectName(QStringLiteral("label_49"));
        label_49->setGeometry(QRect(20, 280, 111, 31));
        label_49->setStyleSheet(QLatin1String("background-color: transparent;\n"
"	color: #fff;\n"
"	font-size: 14pt;\n"
"	border-color: #000000;"));
        label_50 = new QLabel(groupBox);
        label_50->setObjectName(QStringLiteral("label_50"));
        label_50->setGeometry(QRect(20, 350, 111, 31));
        label_50->setStyleSheet(QLatin1String("background-color: transparent;\n"
"	color: #fff;\n"
"	font-size: 14pt;\n"
"	border-color: #000000;"));
        label_51 = new QLabel(groupBox);
        label_51->setObjectName(QStringLiteral("label_51"));
        label_51->setGeometry(QRect(350, 100, 111, 31));
        label_51->setStyleSheet(QLatin1String("background-color: transparent;\n"
"	color: #fff;\n"
"	font-size: 14pt;\n"
"	border-color: #000000;"));
        label_53 = new QLabel(groupBox);
        label_53->setObjectName(QStringLiteral("label_53"));
        label_53->setGeometry(QRect(340, 160, 111, 31));
        label_53->setStyleSheet(QLatin1String("background-color: transparent;\n"
"	color: #fff;\n"
"	font-size: 14pt;\n"
"	border-color: #000000;"));
        label_54 = new QLabel(groupBox);
        label_54->setObjectName(QStringLiteral("label_54"));
        label_54->setGeometry(QRect(340, 220, 111, 31));
        label_54->setStyleSheet(QLatin1String("background-color: transparent;\n"
"	color: #fff;\n"
"	font-size: 14pt;\n"
"	border-color: #000000;"));
        label_56 = new QLabel(groupBox);
        label_56->setObjectName(QStringLiteral("label_56"));
        label_56->setGeometry(QRect(320, 280, 111, 31));
        label_56->setStyleSheet(QLatin1String("background-color: transparent;\n"
"	color: #fff;\n"
"	font-size: 14pt;\n"
"	border-color: #000000;"));
        photo_2 = new QPushButton(groupBox);
        photo_2->setObjectName(QStringLiteral("photo_2"));
        photo_2->setGeometry(QRect(720, 330, 171, 71));
        photo_2->setStyleSheet(QLatin1String("\n"
"background-color: qlineargradient(spread:repeat, x1:1, y1:0, x2:1, y2:1, stop:0 rgba(254, 171, 66, 255),stop:1 rgba(255, 153, 0, 255));\n"
"	color: #000;\n"
"	font-size: 14pt;\n"
"	border-radius: 4px;\n"
"	padding: 10px;\n"
""));
        photo_2->setIcon(icon1);
        photo_2->setCheckable(false);
        lbl_image_2 = new QLabel(groupBox);
        lbl_image_2->setObjectName(QStringLiteral("lbl_image_2"));
        lbl_image_2->setGeometry(QRect(730, 120, 141, 151));
        tabWidget_2->addTab(tab_5, QString());
        stackedWidget->addWidget(page_3);
        page_4 = new QWidget();
        page_4->setObjectName(QStringLiteral("page_4"));
        page_4->setStyleSheet(QLatin1String("\n"
"	background-color: QLinearGradient(x1:0, y1:0, x2:0, y2:1, stop:1 #212121, stop:.4 #343434);\n"
"	color: #000000;\n"
"	border-color: #000000;"));
        tabWidget = new QTabWidget(page_4);
        tabWidget->setObjectName(QStringLiteral("tabWidget"));
        tabWidget->setGeometry(QRect(0, 30, 1391, 641));
        tab_3 = new QWidget();
        tab_3->setObjectName(QStringLiteral("tab_3"));
        label_3 = new QLabel(tab_3);
        label_3->setObjectName(QStringLiteral("label_3"));
        label_3->setGeometry(QRect(340, 20, 281, 20));
        label_3->setFont(font);
        label_3->setStyleSheet(QStringLiteral("color: rgb(255, 255, 255);"));
        valider = new QPushButton(tab_3);
        valider->setObjectName(QStringLiteral("valider"));
        valider->setGeometry(QRect(480, 390, 101, 31));
        valider->setStyleSheet(QLatin1String("QPushButton\n"
"{background-color: rgb(200,133,0);\n"
"color : white;\n"
"font: 10pt Arial;\n"
"            border-radius: 4px;\n"
"            text-shadow: 0 1px 1px rgba(0, 0, 0, 0.2);\n"
"border: 2px solid rgb(200,133,0);\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"border: 2px solid rgb(200,146,0);\n"
"background-color : rgb(200,149,47);\n"
"}"));
        inserer_photo = new QPushButton(tab_3);
        inserer_photo->setObjectName(QStringLiteral("inserer_photo"));
        inserer_photo->setGeometry(QRect(690, 390, 141, 31));
        inserer_photo->setStyleSheet(QLatin1String("QPushButton\n"
"{background-color: rgb(200,133,0);\n"
"color : white;\n"
"font: 10pt Arial;\n"
"            border-radius: 4px;\n"
"            text-shadow: 0 1px 1px rgba(0, 0, 0, 0.2);\n"
"border: 2px solid rgb(200,133,0);\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"border: 2px solid rgb(200,146,0);\n"
"background-color : rgb(200,149,47);\n"
"}"));
        label_26 = new QLabel(tab_3);
        label_26->setObjectName(QStringLiteral("label_26"));
        label_26->setGeometry(QRect(370, 150, 56, 16));
        label_26->setFont(font1);
        label_26->setStyleSheet(QLatin1String("color: rgb(255, 255, 255);\n"
""));
        lineEdit_mail_buyer = new QLineEdit(tab_3);
        lineEdit_mail_buyer->setObjectName(QStringLiteral("lineEdit_mail_buyer"));
        lineEdit_mail_buyer->setGeometry(QRect(530, 140, 171, 22));
        lineEdit_mail_buyer->setStyleSheet(QStringLiteral("color: rgb(255, 255, 255);"));
        label_5 = new QLabel(tab_3);
        label_5->setObjectName(QStringLiteral("label_5"));
        label_5->setGeometry(QRect(50, 150, 102, 25));
        label_5->setFont(font1);
        label_5->setStyleSheet(QStringLiteral("color: rgb(255, 255, 255);"));
        label_55 = new QLabel(tab_3);
        label_55->setObjectName(QStringLiteral("label_55"));
        label_55->setGeometry(QRect(50, 372, 81, 25));
        label_55->setFont(font1);
        label_55->setStyleSheet(QStringLiteral("color: rgb(255, 255, 255);"));
        lineEdit_request_buyer = new QLineEdit(tab_3);
        lineEdit_request_buyer->setObjectName(QStringLiteral("lineEdit_request_buyer"));
        lineEdit_request_buyer->setGeometry(QRect(158, 373, 143, 22));
        lineEdit_request_buyer->setStyleSheet(QStringLiteral("color: rgb(255, 255, 255);"));
        lineEdit_adress_buyer = new QLineEdit(tab_3);
        lineEdit_adress_buyer->setObjectName(QStringLiteral("lineEdit_adress_buyer"));
        lineEdit_adress_buyer->setGeometry(QRect(158, 299, 143, 22));
        lineEdit_adress_buyer->setStyleSheet(QStringLiteral("color: rgb(255, 255, 255);"));
        label_27 = new QLabel(tab_3);
        label_27->setObjectName(QStringLiteral("label_27"));
        label_27->setGeometry(QRect(50, 298, 91, 25));
        label_27->setFont(font1);
        label_27->setStyleSheet(QStringLiteral("color: rgb(255, 255, 255);"));
        lineEdit_name_buyer = new QLineEdit(tab_3);
        lineEdit_name_buyer->setObjectName(QStringLiteral("lineEdit_name_buyer"));
        lineEdit_name_buyer->setGeometry(QRect(158, 225, 143, 22));
        lineEdit_name_buyer->setStyleSheet(QStringLiteral("color: rgb(255, 255, 255);"));
        lineEdit_num_buyer = new QLineEdit(tab_3);
        lineEdit_num_buyer->setObjectName(QStringLiteral("lineEdit_num_buyer"));
        lineEdit_num_buyer->setGeometry(QRect(590, 80, 108, 22));
        lineEdit_num_buyer->setStyleSheet(QStringLiteral("color: rgb(255, 255, 255);"));
        lineEdit_lastname_buyer = new QLineEdit(tab_3);
        lineEdit_lastname_buyer->setObjectName(QStringLiteral("lineEdit_lastname_buyer"));
        lineEdit_lastname_buyer->setGeometry(QRect(158, 151, 143, 22));
        lineEdit_lastname_buyer->setStyleSheet(QStringLiteral("color: rgb(255, 255, 255);"));
        label_52 = new QLabel(tab_3);
        label_52->setObjectName(QStringLiteral("label_52"));
        label_52->setGeometry(QRect(370, 80, 171, 25));
        label_52->setFont(font1);
        label_52->setStyleSheet(QStringLiteral("color: rgb(255, 255, 255);"));
        label_28 = new QLabel(tab_3);
        label_28->setObjectName(QStringLiteral("label_28"));
        label_28->setGeometry(QRect(50, 76, 31, 25));
        label_28->setFont(font1);
        label_28->setStyleSheet(QLatin1String("color: rgb(255, 255, 255);\n"
""));
        label_29 = new QLabel(tab_3);
        label_29->setObjectName(QStringLiteral("label_29"));
        label_29->setGeometry(QRect(50, 224, 67, 25));
        label_29->setFont(font1);
        label_29->setStyleSheet(QStringLiteral("color: rgb(255, 255, 255);"));
        lineEdit_id_buyer = new QLineEdit(tab_3);
        lineEdit_id_buyer->setObjectName(QStringLiteral("lineEdit_id_buyer"));
        lineEdit_id_buyer->setGeometry(QRect(158, 77, 143, 22));
        lineEdit_id_buyer->setStyleSheet(QStringLiteral("color: rgb(255, 255, 255);"));
        label_30 = new QLabel(tab_3);
        label_30->setObjectName(QStringLiteral("label_30"));
        label_30->setGeometry(QRect(370, 230, 71, 21));
        label_30->setFont(font1);
        label_30->setStyleSheet(QStringLiteral("color: rgb(255, 255, 255);"));
        comboBox_buyer_1 = new QComboBox(tab_3);
        comboBox_buyer_1->setObjectName(QStringLiteral("comboBox_buyer_1"));
        comboBox_buyer_1->setGeometry(QRect(530, 220, 73, 22));
        comboBox_buyer_1->setStyleSheet(QStringLiteral("color: rgb(255, 255, 255);"));
        comboBox_buyer_2 = new QComboBox(tab_3);
        comboBox_buyer_2->setObjectName(QStringLiteral("comboBox_buyer_2"));
        comboBox_buyer_2->setGeometry(QRect(850, 390, 73, 22));
        tabWidget->addTab(tab_3, QString());
        tab_4 = new QWidget();
        tab_4->setObjectName(QStringLiteral("tab_4"));
        tab_produit = new QTableView(tab_4);
        tab_produit->setObjectName(QStringLiteral("tab_produit"));
        tab_produit->setGeometry(QRect(0, 0, 1061, 251));
        tab_produit->setStyleSheet(QLatin1String("QTableView {border: 3px solid #5E749C;text-align: top;padding: 4px;border-radius: 7px;border-bottom-left-radius: 7px;background: QLinearGradient( x1: 0, y1: 0, x2: 1, y2: 0,stop: 0 #fff, stop: 1 #eee,stop: 0.5 #ddd,stop: 1 #eee );width: 15px;}\n"
"QTableView::item:focus{selection-background-color: yellow;}\n"
"\n"
"\n"
" QScrollBar{\n"
"         background: QLinearGradient( x1: 0, y1: 0, x2: 1, y2: 0,stop: 0 #fff, stop: 1 #eee,stop: 0.5 #ddd,stop: 1 #eee );\n"
" }\n"
"\n"
" QScrollBar:vertical {\n"
"     border: 3px solid #5E749C;\n"
"     padding: 4px;\n"
"     border-radius: 7px;\n"
"     border-bottom-left-radius: 7px;\n"
"     background: QLinearGradient( x1: 0, y1: 0, x2: 1, y2: 0,stop: 0 #fff, stop: 1 #eee,stop: 0.5 #ddd,stop: 1 #eee );\n"
"     width: 45px;\n"
"     margin: 48px 0 48px 0;\n"
" }\n"
"\n"
" QScrollBar::handle:vertical {\n"
"     background: dark blue;\n"
"     border: 3px solid #5E749C;\n"
"     padding: 0px;\n"
"     border-radius: 7px;\n"
"     border-bottom-left-radius: 7px;\n"
"     m"
                        "in-height: 40px;\n"
" }\n"
" QScrollBar::add-line:vertical {\n"
"     background: dark blue;\n"
"     border: 3px solid #5E749C;\n"
"     padding: 0px;\n"
"     border-radius: 7px;\n"
"     border-bottom-left-radius: 7px;\n"
"     height: 40px;\n"
"     subcontrol-position: bottom;\n"
"     subcontrol-origin: margin;\n"
" }\n"
"\n"
" QScrollBar::sub-line:vertical {\n"
"     background: dark blue;\n"
"     border: 3px solid #5E749C;\n"
"     padding: 0px;\n"
"     border-radius: 7px;\n"
"     border-bottom-left-radius: 7px;\n"
"     height: 40px;\n"
"     subcontrol-position: top;\n"
"     subcontrol-origin: margin;\n"
" }\n"
" QScrollBar::up-arrow:vertical, QScrollBar::down-arrow:vertical {\n"
"     border: 2px solid grey;\n"
"     width: 3px;\n"
"     height: 3px;\n"
"     background: white;\n"
" }\n"
"\n"
" QScrollBar::add-page:vertical, QScrollBar::sub-page:vertical {\n"
"     background: none;\n"
" }\n"
"QHeaderView::section{\n"
"    background-color:rgb(90,90,90);\n"
"      color:rgb(200,200,200);\n"
"   "
                        " border:1px solid rgb(60,60,60);\n"
"    border-bottom:1px solid rgb(70,70,70);\n"
"    height:27px;\n"
"    min-width:55px;\n"
"}\n"
"QHeaderView::section:hover\n"
"{\n"
"    background-color:rgb(80,80,80);\n"
"\n"
"}\n"
"QTableView\n"
"{\n"
"	background: rgb(55,55,55);\n"
"}\n"
"QTableView{\n"
"    selection-background-color:rgb(255,0,0);\n"
"    background-color:rgb(50,50,50);\n"
"    border:1px solid rgb(70,70,70);\n"
"    color:rgb(200,200,200)\n"
"}\n"
"\n"
"QTableView::item\n"
"{\n"
"       border:1px solid rgb(65,65,65);\n"
"	color:rgb(200,200,200);\n"
"\n"
"}\n"
"QTableView::item:hover\n"
"{\n"
"    background-color: rgb(30,30,30);\n"
"    font: 75 9pt \"Microsoft YaHei\";\n"
"    color:rgb(31,163,246);\n"
"}\n"
"QTableView::item::selected\n"
"{\n"
"    background-color: rgb(30,30,30);\n"
"    font: 75 9pt \"Microsoft YaHei\";\n"
"    color:rgb(31,163,246);\n"
"}"));
        sort_request_buyer = new QPushButton(tab_4);
        sort_request_buyer->setObjectName(QStringLiteral("sort_request_buyer"));
        sort_request_buyer->setGeometry(QRect(160, 260, 141, 28));
        sort_request_buyer->setStyleSheet(QLatin1String("QPushButton\n"
"{background-color: rgb(200,133,0);\n"
"color : white;\n"
"font: 10pt Arial;\n"
"            border-radius: 4px;\n"
"            text-shadow: 0 1px 1px rgba(0, 0, 0, 0.2);\n"
"border: 2px solid rgb(200,133,0);\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"border: 2px solid rgb(200,146,0);\n"
"background-color : rgb(200,149,47);\n"
"}"));
        sort_name_buyer = new QPushButton(tab_4);
        sort_name_buyer->setObjectName(QStringLiteral("sort_name_buyer"));
        sort_name_buyer->setGeometry(QRect(20, 260, 121, 28));
        sort_name_buyer->setStyleSheet(QLatin1String("QPushButton\n"
"{background-color: rgb(200,133,0);\n"
"color : white;\n"
"font: 10pt Arial;\n"
"            border-radius: 4px;\n"
"            text-shadow: 0 1px 1px rgba(0, 0, 0, 0.2);\n"
"border: 2px solid rgb(200,133,0);\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"border: 2px solid rgb(200,146,0);\n"
"background-color : rgb(200,149,47);\n"
"}"));
        sort_adress_buyer = new QPushButton(tab_4);
        sort_adress_buyer->setObjectName(QStringLiteral("sort_adress_buyer"));
        sort_adress_buyer->setGeometry(QRect(320, 260, 131, 28));
        sort_adress_buyer->setStyleSheet(QLatin1String("QPushButton\n"
"{background-color: rgb(200,133,0);\n"
"color : white;\n"
"font: 10pt Arial;\n"
"            border-radius: 4px;\n"
"            text-shadow: 0 1px 1px rgba(0, 0, 0, 0.2);\n"
"border: 2px solid rgb(200,133,0);\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"border: 2px solid rgb(200,146,0);\n"
"background-color : rgb(200,149,47);\n"
"}"));
        rechercher_2 = new QPushButton(tab_4);
        rechercher_2->setObjectName(QStringLiteral("rechercher_2"));
        rechercher_2->setGeometry(QRect(400, 320, 93, 28));
        rechercher_2->setStyleSheet(QLatin1String("QPushButton\n"
"{background-color: rgb(200,133,0);\n"
"color : white;\n"
"font: 10pt Arial;\n"
"            border-radius: 4px;\n"
"            text-shadow: 0 1px 1px rgba(0, 0, 0, 0.2);\n"
"border: 2px solid rgb(200,133,0);\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"border: 2px solid rgb(200,146,0);\n"
"background-color : rgb(200,149,47);\n"
"}"));
        label_31 = new QLabel(tab_4);
        label_31->setObjectName(QStringLiteral("label_31"));
        label_31->setGeometry(QRect(40, 320, 131, 20));
        label_31->setFont(font1);
        label_31->setStyleSheet(QStringLiteral("color: rgb(255, 255, 255);"));
        chercher_id = new QLineEdit(tab_4);
        chercher_id->setObjectName(QStringLiteral("chercher_id"));
        chercher_id->setGeometry(QRect(240, 320, 111, 22));
        chercher_id->setStyleSheet(QStringLiteral("color: rgb(255, 255, 255);"));
        label_32 = new QLabel(tab_4);
        label_32->setObjectName(QStringLiteral("label_32"));
        label_32->setGeometry(QRect(40, 370, 141, 20));
        label_32->setFont(font1);
        label_32->setStyleSheet(QLatin1String("\n"
"color: rgb(255, 255, 255);"));
        chercher_name = new QLineEdit(tab_4);
        chercher_name->setObjectName(QStringLiteral("chercher_name"));
        chercher_name->setGeometry(QRect(240, 370, 113, 22));
        chercher_name->setStyleSheet(QStringLiteral("color: rgb(255, 255, 255);"));
        rechercher_3 = new QPushButton(tab_4);
        rechercher_3->setObjectName(QStringLiteral("rechercher_3"));
        rechercher_3->setGeometry(QRect(400, 370, 93, 28));
        rechercher_3->setStyleSheet(QLatin1String("QPushButton\n"
"{background-color: rgb(200,133,0);\n"
"color : white;\n"
"font: 10pt Arial;\n"
"            border-radius: 4px;\n"
"            text-shadow: 0 1px 1px rgba(0, 0, 0, 0.2);\n"
"border: 2px solid rgb(200,133,0);\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"border: 2px solid rgb(200,146,0);\n"
"background-color : rgb(200,149,47);\n"
"}"));
        label_33 = new QLabel(tab_4);
        label_33->setObjectName(QStringLiteral("label_33"));
        label_33->setGeometry(QRect(40, 420, 181, 20));
        label_33->setFont(font1);
        label_33->setStyleSheet(QStringLiteral("color: rgb(255, 255, 255);"));
        chercher_request = new QLineEdit(tab_4);
        chercher_request->setObjectName(QStringLiteral("chercher_request"));
        chercher_request->setGeometry(QRect(240, 420, 113, 22));
        chercher_request->setStyleSheet(QLatin1String("color: rgb(255, 255, 255);\n"
""));
        rechercher_4 = new QPushButton(tab_4);
        rechercher_4->setObjectName(QStringLiteral("rechercher_4"));
        rechercher_4->setGeometry(QRect(400, 420, 93, 28));
        rechercher_4->setStyleSheet(QLatin1String("QPushButton\n"
"{background-color: rgb(200,133,0);\n"
"color : white;\n"
"font: 10pt Arial;\n"
"            border-radius: 4px;\n"
"            text-shadow: 0 1px 1px rgba(0, 0, 0, 0.2);\n"
"border: 2px solid rgb(200,133,0);\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"border: 2px solid rgb(200,146,0);\n"
"background-color : rgb(200,149,47);\n"
"}"));
        sort_id_buyer = new QPushButton(tab_4);
        sort_id_buyer->setObjectName(QStringLiteral("sort_id_buyer"));
        sort_id_buyer->setGeometry(QRect(470, 260, 121, 31));
        sort_id_buyer->setStyleSheet(QLatin1String("QPushButton\n"
"{background-color: rgb(200,133,0);\n"
"color : white;\n"
"font: 10pt Arial;\n"
"            border-radius: 4px;\n"
"            text-shadow: 0 1px 1px rgba(0, 0, 0, 0.2);\n"
"border: 2px solid rgb(200,133,0);\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"border: 2px solid rgb(200,146,0);\n"
"background-color : rgb(200,149,47);\n"
"}"));
        label_34 = new QLabel(tab_4);
        label_34->setObjectName(QStringLiteral("label_34"));
        label_34->setGeometry(QRect(640, 270, 56, 16));
        label_34->setFont(font1);
        label_34->setStyleSheet(QStringLiteral("color: rgb(255, 255, 255);"));
        update_name = new QLineEdit(tab_4);
        update_name->setObjectName(QStringLiteral("update_name"));
        update_name->setGeometry(QRect(800, 330, 231, 22));
        update_name->setStyleSheet(QStringLiteral("color: rgb(255, 255, 255);"));
        update_mail = new QLineEdit(tab_4);
        update_mail->setObjectName(QStringLiteral("update_mail"));
        update_mail->setGeometry(QRect(800, 460, 231, 22));
        update_mail->setStyleSheet(QStringLiteral("color: rgb(255, 255, 255);"));
        update_num = new QLineEdit(tab_4);
        update_num->setObjectName(QStringLiteral("update_num"));
        update_num->setGeometry(QRect(800, 420, 231, 22));
        update_num->setStyleSheet(QStringLiteral("color: rgb(255, 255, 255);"));
        label_35 = new QLabel(tab_4);
        label_35->setObjectName(QStringLiteral("label_35"));
        label_35->setGeometry(QRect(640, 360, 71, 16));
        label_35->setFont(font1);
        label_35->setStyleSheet(QStringLiteral("color: rgb(255, 255, 255);"));
        update_lastname = new QLineEdit(tab_4);
        update_lastname->setObjectName(QStringLiteral("update_lastname"));
        update_lastname->setGeometry(QRect(800, 300, 231, 22));
        update_lastname->setStyleSheet(QStringLiteral("color: rgb(255, 255, 255);"));
        label_36 = new QLabel(tab_4);
        label_36->setObjectName(QStringLiteral("label_36"));
        label_36->setGeometry(QRect(640, 420, 161, 21));
        label_36->setFont(font1);
        label_36->setStyleSheet(QStringLiteral("color: rgb(255, 255, 255);"));
        label_37 = new QLabel(tab_4);
        label_37->setObjectName(QStringLiteral("label_37"));
        label_37->setGeometry(QRect(640, 460, 61, 16));
        label_37->setFont(font1);
        label_37->setStyleSheet(QStringLiteral("color: rgb(255, 255, 255);"));
        label_41 = new QLabel(tab_4);
        label_41->setObjectName(QStringLiteral("label_41"));
        label_41->setGeometry(QRect(640, 300, 91, 21));
        label_41->setFont(font1);
        label_41->setStyleSheet(QStringLiteral("color: rgb(255, 255, 255);"));
        update_adress = new QLineEdit(tab_4);
        update_adress->setObjectName(QStringLiteral("update_adress"));
        update_adress->setGeometry(QRect(800, 360, 231, 22));
        update_adress->setStyleSheet(QStringLiteral("color: rgb(255, 255, 255);"));
        label_42 = new QLabel(tab_4);
        label_42->setObjectName(QStringLiteral("label_42"));
        label_42->setGeometry(QRect(640, 390, 91, 21));
        label_42->setFont(font1);
        label_42->setStyleSheet(QStringLiteral("color: rgb(255, 255, 255);"));
        label_43 = new QLabel(tab_4);
        label_43->setObjectName(QStringLiteral("label_43"));
        label_43->setGeometry(QRect(640, 330, 56, 16));
        label_43->setFont(font1);
        label_43->setStyleSheet(QStringLiteral("color: rgb(255, 255, 255);"));
        update_request = new QLineEdit(tab_4);
        update_request->setObjectName(QStringLiteral("update_request"));
        update_request->setGeometry(QRect(800, 390, 231, 22));
        update_request->setStyleSheet(QStringLiteral("color: rgb(255, 255, 255);"));
        read = new QPushButton(tab_4);
        read->setObjectName(QStringLiteral("read"));
        read->setGeometry(QRect(1190, 440, 93, 28));
        read->setStyleSheet(QLatin1String("QPushButton\n"
"{background-color: rgb(200,133,0);\n"
"color : white;\n"
"font: 10pt Arial;\n"
"            border-radius: 4px;\n"
"            text-shadow: 0 1px 1px rgba(0, 0, 0, 0.2);\n"
"border: 2px solid rgb(200,133,0);\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"border: 2px solid rgb(200,146,0);\n"
"background-color : rgb(200,149,47);\n"
"}"));
        pushButton_delete = new QPushButton(tab_4);
        pushButton_delete->setObjectName(QStringLiteral("pushButton_delete"));
        pushButton_delete->setGeometry(QRect(230, 520, 93, 28));
        pushButton_delete->setStyleSheet(QLatin1String("QPushButton\n"
"{background-color: rgb(200,133,0);\n"
"color : white;\n"
"font: 10pt Arial;\n"
"            border-radius: 4px;\n"
"            text-shadow: 0 1px 1px rgba(0, 0, 0, 0.2);\n"
"border: 2px solid rgb(200,133,0);\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"border: 2px solid rgb(200,146,0);\n"
"background-color : rgb(200,149,47);\n"
"}"));
        lineEdit_del = new QLineEdit(tab_4);
        lineEdit_del->setObjectName(QStringLiteral("lineEdit_del"));
        lineEdit_del->setGeometry(QRect(90, 520, 113, 21));
        lineEdit_del->setStyleSheet(QStringLiteral("color: rgb(255, 255, 255);"));
        update_id = new QLineEdit(tab_4);
        update_id->setObjectName(QStringLiteral("update_id"));
        update_id->setGeometry(QRect(800, 270, 231, 22));
        update_id->setStyleSheet(QStringLiteral("color: rgb(255, 255, 255);"));
        update = new QPushButton(tab_4);
        update->setObjectName(QStringLiteral("update"));
        update->setGeometry(QRect(900, 500, 93, 28));
        update->setStyleSheet(QLatin1String("QPushButton\n"
"{background-color: rgb(200,133,0);\n"
"color : white;\n"
"font: 10pt Arial;\n"
"            border-radius: 4px;\n"
"            text-shadow: 0 1px 1px rgba(0, 0, 0, 0.2);\n"
"border: 2px solid rgb(200,133,0);\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"border: 2px solid rgb(200,146,0);\n"
"background-color : rgb(200,149,47);\n"
"}"));
        comboBox_buyer_3 = new QComboBox(tab_4);
        comboBox_buyer_3->setObjectName(QStringLiteral("comboBox_buyer_3"));
        comboBox_buyer_3->setGeometry(QRect(860, 550, 73, 22));
        comboBox_buyer_3->setStyleSheet(QStringLiteral("color: rgb(255, 255, 255);"));
        pushButton_13 = new QPushButton(tab_4);
        pushButton_13->setObjectName(QStringLiteral("pushButton_13"));
        pushButton_13->setGeometry(QRect(950, 540, 93, 31));
        pushButton_13->setStyleSheet(QLatin1String("QPushButton\n"
"{background-color: rgb(200,133,0);\n"
"color : white;\n"
"font: 10pt Arial;\n"
"            border-radius: 4px;\n"
"            text-shadow: 0 1px 1px rgba(0, 0, 0, 0.2);\n"
"border: 2px solid rgb(200,133,0);\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"border: 2px solid rgb(200,146,0);\n"
"background-color : rgb(200,149,47);\n"
"}"));
        mailling = new QPushButton(tab_4);
        mailling->setObjectName(QStringLiteral("mailling"));
        mailling->setGeometry(QRect(1190, 350, 93, 28));
        mailling->setStyleSheet(QLatin1String("QPushButton\n"
"{background-color: rgb(200,133,0);\n"
"color : white;\n"
"font: 10pt Arial;\n"
"            border-radius: 4px;\n"
"            text-shadow: 0 1px 1px rgba(0, 0, 0, 0.2);\n"
"border: 2px solid rgb(200,133,0);\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"border: 2px solid rgb(200,146,0);\n"
"background-color : rgb(200,149,47);\n"
"}"));
        tableView2 = new QTableView(tab_4);
        tableView2->setObjectName(QStringLiteral("tableView2"));
        tableView2->setGeometry(QRect(1070, 40, 231, 201));
        tableView2->setStyleSheet(QLatin1String("QTableView {border: 3px solid #5E749C;text-align: top;padding: 4px;border-radius: 7px;border-bottom-left-radius: 7px;background: QLinearGradient( x1: 0, y1: 0, x2: 1, y2: 0,stop: 0 #fff, stop: 1 #eee,stop: 0.5 #ddd,stop: 1 #eee );width: 15px;}\n"
"QTableView::item:focus{selection-background-color: yellow;}\n"
"\n"
"\n"
" QScrollBar{\n"
"         background: QLinearGradient( x1: 0, y1: 0, x2: 1, y2: 0,stop: 0 #fff, stop: 1 #eee,stop: 0.5 #ddd,stop: 1 #eee );\n"
" }\n"
"\n"
" QScrollBar:vertical {\n"
"     border: 3px solid #5E749C;\n"
"     padding: 4px;\n"
"     border-radius: 7px;\n"
"     border-bottom-left-radius: 7px;\n"
"     background: QLinearGradient( x1: 0, y1: 0, x2: 1, y2: 0,stop: 0 #fff, stop: 1 #eee,stop: 0.5 #ddd,stop: 1 #eee );\n"
"     width: 45px;\n"
"     margin: 48px 0 48px 0;\n"
" }\n"
"\n"
" QScrollBar::handle:vertical {\n"
"     background: dark blue;\n"
"     border: 3px solid #5E749C;\n"
"     padding: 0px;\n"
"     border-radius: 7px;\n"
"     border-bottom-left-radius: 7px;\n"
"     m"
                        "in-height: 40px;\n"
" }\n"
" QScrollBar::add-line:vertical {\n"
"     background: dark blue;\n"
"     border: 3px solid #5E749C;\n"
"     padding: 0px;\n"
"     border-radius: 7px;\n"
"     border-bottom-left-radius: 7px;\n"
"     height: 40px;\n"
"     subcontrol-position: bottom;\n"
"     subcontrol-origin: margin;\n"
" }\n"
"\n"
" QScrollBar::sub-line:vertical {\n"
"     background: dark blue;\n"
"     border: 3px solid #5E749C;\n"
"     padding: 0px;\n"
"     border-radius: 7px;\n"
"     border-bottom-left-radius: 7px;\n"
"     height: 40px;\n"
"     subcontrol-position: top;\n"
"     subcontrol-origin: margin;\n"
" }\n"
" QScrollBar::up-arrow:vertical, QScrollBar::down-arrow:vertical {\n"
"     border: 2px solid grey;\n"
"     width: 3px;\n"
"     height: 3px;\n"
"     background: white;\n"
" }\n"
"\n"
" QScrollBar::add-page:vertical, QScrollBar::sub-page:vertical {\n"
"     background: none;\n"
" }\n"
"QHeaderView::section{\n"
"    background-color:rgb(90,90,90);\n"
"      color:rgb(200,200,200);\n"
"   "
                        " border:1px solid rgb(60,60,60);\n"
"    border-bottom:1px solid rgb(70,70,70);\n"
"    height:27px;\n"
"    min-width:55px;\n"
"}\n"
"QHeaderView::section:hover\n"
"{\n"
"    background-color:rgb(80,80,80);\n"
"\n"
"}\n"
"QTableView\n"
"{\n"
"	background: rgb(55,55,55);\n"
"}\n"
"QTableView{\n"
"    selection-background-color:rgb(255,0,0);\n"
"    background-color:rgb(50,50,50);\n"
"    border:1px solid rgb(70,70,70);\n"
"    color:rgb(200,200,200)\n"
"}\n"
"\n"
"QTableView::item\n"
"{\n"
"       border:1px solid rgb(65,65,65);\n"
"	color:rgb(200,200,200);\n"
"\n"
"}\n"
"QTableView::item:hover\n"
"{\n"
"    background-color: rgb(30,30,30);\n"
"    font: 75 9pt \"Microsoft YaHei\";\n"
"    color:rgb(31,163,246);\n"
"}\n"
"QTableView::item::selected\n"
"{\n"
"    background-color: rgb(30,30,30);\n"
"    font: 75 9pt \"Microsoft YaHei\";\n"
"    color:rgb(31,163,246);\n"
"}"));
        label_44 = new QLabel(tab_4);
        label_44->setObjectName(QStringLiteral("label_44"));
        label_44->setGeometry(QRect(1100, 10, 181, 16));
        label_44->setFont(font1);
        label_44->setStyleSheet(QStringLiteral("color: rgb(255, 255, 255);"));
        city = new QLineEdit(tab_4);
        city->setObjectName(QStringLiteral("city"));
        city->setGeometry(QRect(1180, 270, 113, 22));
        recommand = new QPushButton(tab_4);
        recommand->setObjectName(QStringLiteral("recommand"));
        recommand->setGeometry(QRect(1060, 270, 93, 28));
        recommand->setStyleSheet(QLatin1String("QPushButton\n"
"{background-color: rgb(200,133,0);\n"
"color : white;\n"
"font: 10pt Arial;\n"
"            border-radius: 4px;\n"
"            text-shadow: 0 1px 1px rgba(0, 0, 0, 0.2);\n"
"border: 2px solid rgb(200,133,0);\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"border: 2px solid rgb(200,146,0);\n"
"background-color : rgb(200,149,47);\n"
"}"));
        tabWidget->addTab(tab_4, QString());
        stackedWidget->addWidget(page_4);
        page_6 = new QWidget();
        page_6->setObjectName(QStringLiteral("page_6"));
        tabWidget_4 = new QTabWidget(page_6);
        tabWidget_4->setObjectName(QStringLiteral("tabWidget_4"));
        tabWidget_4->setGeometry(QRect(40, 40, 871, 551));
        tabWidget_4->setStyleSheet(QLatin1String("QTabBar::tab\n"
"{\n"
"	font-size: 8pt;\n"
"	font-weight: bold;\n"
"	width: 80px;\n"
"    border: 1px solid #444;\n"
"    border-bottom-style: none;\n"
"	border-top-style: none;\n"
"    background-color: #323232;\n"
"    padding-top: 3px;\n"
"    padding-bottom: 2px;\n"
"    margin-right: -1px;\n"
"\n"
"}\n"
"QTabWidget::pane \n"
"{\n"
"    border: 1px solid qlineargradient(spread:repeat, x1:1, y1:0, x2:1, y2:1, stop:0 rgba(254, 171, 66, 255),stop:1 rgba(255, 153, 0, 255));\n"
"    top: 1px;\n"
"\n"
"}\n"
"\n"
"QTabBar::tab:last\n"
"{\n"
"    margin-right: 0; \n"
"\n"
"}\n"
"\n"
"QTabBar::tab:first:!selected\n"
"{\n"
"	margin-left: 0px; \n"
"\n"
"}\n"
"\n"
"QTabBar::tab:!selected\n"
"{\n"
"    color: #fff;\n"
"    border-bottom-style: solid;\n"
"    margin-top: 3px;\n"
"    background-color: QLinearGradient(x1:0, y1:0, x2:0, y2:1, stop:1 #212121, stop:.4 #343434);\n"
"\n"
"}\n"
"\n"
"QTabBar::tab:selected\n"
"{\n"
"	background-color: qlineargradient(spread:repeat, x1:1, y1:0, x2:1, y2:1, stop:0 rgba(254, 171, "
                        "66, 255),stop:1 rgba(255, 153, 0, 255));\n"
"	color: #000;\n"
"    margin-bottom: 0px;\n"
"\n"
"}\n"
"\n"
"QTabBar::tab:!selected:hover\n"
"{\n"
"    background-color: QLinearGradient(x1:0, y1:0, x2:0, y2:1, stop:1 #212121, stop:0.4 #343434, stop:0.2 #343434, stop:0.1 #ffaa00);\n"
"\n"
"}"));
        tab_6 = new QWidget();
        tab_6->setObjectName(QStringLiteral("tab_6"));
        label_2 = new QLabel(tab_6);
        label_2->setObjectName(QStringLiteral("label_2"));
        label_2->setGeometry(QRect(100, 50, 61, 16));
        label_2->setStyleSheet(QLatin1String("QLabel\n"
"{\n"
"	background-color: transparent;\n"
"	color: #fff;\n"
"	font-size: 14pt;\n"
"	border-color: #000000;\n"
"\n"
"}color:rgb(255, 255, 255)\n"
"\n"
""));
        pb_Add = new QPushButton(tab_6);
        pb_Add->setObjectName(QStringLiteral("pb_Add"));
        pb_Add->setGeometry(QRect(550, 140, 75, 23));
        pb_Add->setStyleSheet(QLatin1String("QPushButton\n"
"{background-color: rgb(200,133,0);\n"
"color : white;\n"
"font: 10pt Arial;\n"
"            border-radius: 4px;\n"
"            text-shadow: 0 1px 1px rgba(0, 0, 0, 0.2);\n"
"border: 2px solid rgb(200,133,0);\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"border: 2px solid rgb(200,146,0);\n"
"background-color : rgb(200,149,47);\n"
"}"));
        label_6 = new QLabel(tab_6);
        label_6->setObjectName(QStringLiteral("label_6"));
        label_6->setGeometry(QRect(80, 310, 91, 16));
        label_6->setStyleSheet(QLatin1String("QLabel\n"
"{\n"
"	background-color: transparent;\n"
"	color: #fff;\n"
"	font-size: 14pt;\n"
"	border-color: #000000;\n"
"\n"
"}"));
        comboBox_3 = new QComboBox(tab_6);
        comboBox_3->setObjectName(QStringLiteral("comboBox_3"));
        comboBox_3->setGeometry(QRect(550, 240, 62, 22));
        comboBox_6 = new QComboBox(tab_6);
        comboBox_6->setObjectName(QStringLiteral("comboBox_6"));
        comboBox_6->setGeometry(QRect(550, 290, 62, 22));
        label_7 = new QLabel(tab_6);
        label_7->setObjectName(QStringLiteral("label_7"));
        label_7->setGeometry(QRect(70, 110, 141, 20));
        label_7->setStyleSheet(QLatin1String("QLabel\n"
"{\n"
"	background-color: transparent;\n"
"	color: #fff;\n"
"	font-size: 14pt;\n"
"	border-color: #000000;\n"
"\n"
"}"));
        num_sel = new QLineEdit(tab_6);
        num_sel->setObjectName(QStringLiteral("num_sel"));
        num_sel->setGeometry(QRect(260, 260, 113, 20));
        num_sel->setStyleSheet(QStringLiteral("color:rgb(255, 255, 255)"));
        mail_sel = new QLineEdit(tab_6);
        mail_sel->setObjectName(QStringLiteral("mail_sel"));
        mail_sel->setGeometry(QRect(260, 310, 113, 20));
        mail_sel->setStyleSheet(QStringLiteral("color:rgb(255, 255, 255)"));
        name_sel = new QLineEdit(tab_6);
        name_sel->setObjectName(QStringLiteral("name_sel"));
        name_sel->setGeometry(QRect(260, 160, 113, 20));
        name_sel->setStyleSheet(QStringLiteral("color:rgb(255, 255, 255)"));
        label_8 = new QLabel(tab_6);
        label_8->setObjectName(QStringLiteral("label_8"));
        label_8->setGeometry(QRect(80, 160, 91, 16));
        label_8->setStyleSheet(QLatin1String("QLabel\n"
"{\n"
"	background-color: transparent;\n"
"	color: #fff;\n"
"	font-size: 14pt;\n"
"	border-color: #000000;\n"
"\n"
"}"));
        id_sel = new QLineEdit(tab_6);
        id_sel->setObjectName(QStringLiteral("id_sel"));
        id_sel->setGeometry(QRect(260, 50, 113, 20));
        id_sel->setStyleSheet(QLatin1String("color:\n"
"rgb(255, 255, 255)"));
        adress_sel = new QLineEdit(tab_6);
        adress_sel->setObjectName(QStringLiteral("adress_sel"));
        adress_sel->setGeometry(QRect(260, 210, 113, 20));
        adress_sel->setStyleSheet(QStringLiteral("color:rgb(255, 255, 255)"));
        label_9 = new QLabel(tab_6);
        label_9->setObjectName(QStringLiteral("label_9"));
        label_9->setGeometry(QRect(80, 220, 111, 16));
        label_9->setStyleSheet(QLatin1String("QLabel\n"
"{\n"
"	background-color: transparent;\n"
"	color: #fff;\n"
"	font-size: 14pt;\n"
"	border-color: #000000;\n"
"\n"
"}"));
        lastname_sel = new QLineEdit(tab_6);
        lastname_sel->setObjectName(QStringLiteral("lastname_sel"));
        lastname_sel->setGeometry(QRect(260, 110, 113, 20));
        lastname_sel->setStyleSheet(QStringLiteral("color:rgb(255, 255, 255)"));
        label_10 = new QLabel(tab_6);
        label_10->setObjectName(QStringLiteral("label_10"));
        label_10->setGeometry(QRect(90, 270, 81, 16));
        label_10->setStyleSheet(QLatin1String("QLabel\n"
"{\n"
"	background-color: transparent;\n"
"	color: #fff;\n"
"	font-size: 14pt;\n"
"	border-color: #000000;\n"
"\n"
"}"));
        generer_pdf = new QPushButton(tab_6);
        generer_pdf->setObjectName(QStringLiteral("generer_pdf"));
        generer_pdf->setGeometry(QRect(540, 190, 91, 23));
        generer_pdf->setStyleSheet(QLatin1String("QPushButton\n"
"{background-color: rgb(200,133,0);\n"
"color : white;\n"
"font: 10pt Arial;\n"
"            border-radius: 4px;\n"
"            text-shadow: 0 1px 1px rgba(0, 0, 0, 0.2);\n"
"border: 2px solid rgb(200,133,0);\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"border: 2px solid rgb(200,146,0);\n"
"background-color : rgb(200,149,47);\n"
"}"));
        tabWidget_4->addTab(tab_6, QString());
        tab_2 = new QWidget();
        tab_2->setObjectName(QStringLiteral("tab_2"));
        tab_seller = new QTableView(tab_2);
        tab_seller->setObjectName(QStringLiteral("tab_seller"));
        tab_seller->setGeometry(QRect(0, 0, 871, 191));
        tab_seller->setStyleSheet(QLatin1String("QTableView {border: 3px solid #5E749C;text-align: top;padding: 4px;border-radius: 7px;border-bottom-left-radius: 7px;background: QLinearGradient( x1: 0, y1: 0, x2: 1, y2: 0,stop: 0 #fff, stop: 1 #eee,stop: 0.5 #ddd,stop: 1 #eee );width: 15px;}\n"
"QTableView::item:focus{selection-background-color: yellow;}\n"
"\n"
"\n"
" QScrollBar{\n"
"         background: QLinearGradient( x1: 0, y1: 0, x2: 1, y2: 0,stop: 0 #fff, stop: 1 #eee,stop: 0.5 #ddd,stop: 1 #eee );\n"
" }\n"
"\n"
" QScrollBar:vertical {\n"
"     border: 3px solid #5E749C;\n"
"     padding: 4px;\n"
"     border-radius: 7px;\n"
"     border-bottom-left-radius: 7px;\n"
"     background: QLinearGradient( x1: 0, y1: 0, x2: 1, y2: 0,stop: 0 #fff, stop: 1 #eee,stop: 0.5 #ddd,stop: 1 #eee );\n"
"     width: 45px;\n"
"     margin: 48px 0 48px 0;\n"
" }\n"
"\n"
" QScrollBar::handle:vertical {\n"
"     background: dark blue;\n"
"     border: 3px solid #5E749C;\n"
"     padding: 0px;\n"
"     border-radius: 7px;\n"
"     border-bottom-left-radius: 7px;\n"
"     m"
                        "in-height: 40px;\n"
" }\n"
" QScrollBar::add-line:vertical {\n"
"     background: dark blue;\n"
"     border: 3px solid #5E749C;\n"
"     padding: 0px;\n"
"     border-radius: 7px;\n"
"     border-bottom-left-radius: 7px;\n"
"     height: 40px;\n"
"     subcontrol-position: bottom;\n"
"     subcontrol-origin: margin;\n"
" }\n"
"\n"
" QScrollBar::sub-line:vertical {\n"
"     background: dark blue;\n"
"     border: 3px solid #5E749C;\n"
"     padding: 0px;\n"
"     border-radius: 7px;\n"
"     border-bottom-left-radius: 7px;\n"
"     height: 40px;\n"
"     subcontrol-position: top;\n"
"     subcontrol-origin: margin;\n"
" }\n"
" QScrollBar::up-arrow:vertical, QScrollBar::down-arrow:vertical {\n"
"     border: 2px solid grey;\n"
"     width: 3px;\n"
"     height: 3px;\n"
"     background: white;\n"
" }\n"
"\n"
" QScrollBar::add-page:vertical, QScrollBar::sub-page:vertical {\n"
"     background: none;\n"
" }"));
        pb_modif = new QPushButton(tab_2);
        pb_modif->setObjectName(QStringLiteral("pb_modif"));
        pb_modif->setGeometry(QRect(730, 440, 75, 23));
        pb_modif->setStyleSheet(QLatin1String("QPushButton\n"
"{background-color: rgb(200,133,0);\n"
"color : white;\n"
"font: 10pt Arial;\n"
"            border-radius: 4px;\n"
"            text-shadow: 0 1px 1px rgba(0, 0, 0, 0.2);\n"
"border: 2px solid rgb(200,133,0);\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"border: 2px solid rgb(200,146,0);\n"
"background-color : rgb(200,149,47);\n"
"}"));
        pb_supp = new QPushButton(tab_2);
        pb_supp->setObjectName(QStringLiteral("pb_supp"));
        pb_supp->setGeometry(QRect(210, 440, 75, 23));
        pb_supp->setStyleSheet(QLatin1String("QPushButton\n"
"{background-color: rgb(200,133,0);\n"
"color : white;\n"
"font: 10pt Arial;\n"
"            border-radius: 4px;\n"
"            text-shadow: 0 1px 1px rgba(0, 0, 0, 0.2);\n"
"border: 2px solid rgb(200,133,0);\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"border: 2px solid rgb(200,146,0);\n"
"background-color : rgb(200,149,47);\n"
"}"));
        Sort_by_id = new QPushButton(tab_2);
        Sort_by_id->setObjectName(QStringLiteral("Sort_by_id"));
        Sort_by_id->setGeometry(QRect(40, 200, 75, 23));
        Sort_by_id->setStyleSheet(QLatin1String("QPushButton\n"
"{background-color: rgb(200,133,0);\n"
"color : white;\n"
"font: 10pt Arial;\n"
"            border-radius: 4px;\n"
"            text-shadow: 0 1px 1px rgba(0, 0, 0, 0.2);\n"
"border: 2px solid rgb(200,133,0);\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"border: 2px solid rgb(200,146,0);\n"
"background-color : rgb(200,149,47);\n"
"}"));
        Sort_by_name = new QPushButton(tab_2);
        Sort_by_name->setObjectName(QStringLiteral("Sort_by_name"));
        Sort_by_name->setGeometry(QRect(164, 200, 91, 23));
        Sort_by_name->setStyleSheet(QLatin1String("QPushButton\n"
"{background-color: rgb(200,133,0);\n"
"color : white;\n"
"font: 10pt Arial;\n"
"            border-radius: 4px;\n"
"            text-shadow: 0 1px 1px rgba(0, 0, 0, 0.2);\n"
"border: 2px solid rgb(200,133,0);\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"border: 2px solid rgb(200,146,0);\n"
"background-color : rgb(200,149,47);\n"
"}"));
        Sort_by_adress = new QPushButton(tab_2);
        Sort_by_adress->setObjectName(QStringLiteral("Sort_by_adress"));
        Sort_by_adress->setGeometry(QRect(304, 200, 91, 23));
        Sort_by_adress->setStyleSheet(QLatin1String("QPushButton\n"
"{background-color: rgb(200,133,0);\n"
"color : white;\n"
"font: 10pt Arial;\n"
"            border-radius: 4px;\n"
"            text-shadow: 0 1px 1px rgba(0, 0, 0, 0.2);\n"
"border: 2px solid rgb(200,133,0);\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"border: 2px solid rgb(200,146,0);\n"
"background-color : rgb(200,149,47);\n"
"}"));
        search_id = new QPushButton(tab_2);
        search_id->setObjectName(QStringLiteral("search_id"));
        search_id->setGeometry(QRect(310, 260, 75, 23));
        search_id->setStyleSheet(QLatin1String("QPushButton\n"
"{background-color: rgb(200,133,0);\n"
"color : white;\n"
"font: 10pt Arial;\n"
"            border-radius: 4px;\n"
"            text-shadow: 0 1px 1px rgba(0, 0, 0, 0.2);\n"
"border: 2px solid rgb(200,133,0);\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"border: 2px solid rgb(200,146,0);\n"
"background-color : rgb(200,149,47);\n"
"}"));
        pb_read = new QPushButton(tab_2);
        pb_read->setObjectName(QStringLiteral("pb_read"));
        pb_read->setGeometry(QRect(430, 200, 75, 23));
        pb_read->setStyleSheet(QLatin1String("QPushButton\n"
"{background-color: rgb(200,133,0);\n"
"color : white;\n"
"font: 10pt Arial;\n"
"            border-radius: 4px;\n"
"            text-shadow: 0 1px 1px rgba(0, 0, 0, 0.2);\n"
"border: 2px solid rgb(200,133,0);\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"border: 2px solid rgb(200,146,0);\n"
"background-color : rgb(200,149,47);\n"
"}"));
        label_11 = new QLabel(tab_2);
        label_11->setObjectName(QStringLiteral("label_11"));
        label_11->setGeometry(QRect(6, 440, 61, 20));
        label_11->setStyleSheet(QLatin1String("QLabel\n"
"{\n"
"	background-color: transparent;\n"
"	color: #fff;\n"
"	font-size: 14pt;\n"
"	border-color: #000000;\n"
"\n"
"}"));
        id_supp = new QLineEdit(tab_2);
        id_supp->setObjectName(QStringLiteral("id_supp"));
        id_supp->setGeometry(QRect(70, 440, 113, 20));
        id_supp->setStyleSheet(QLatin1String("color:\n"
"rgb(255, 255, 255)"));
        label_12 = new QLabel(tab_2);
        label_12->setObjectName(QStringLiteral("label_12"));
        label_12->setGeometry(QRect(570, 200, 71, 16));
        label_12->setStyleSheet(QLatin1String("QLabel\n"
"{\n"
"	background-color: transparent;\n"
"	color: #fff;\n"
"	font-size: 14pt;\n"
"	border-color: #000000;\n"
"\n"
"}"));
        id_modif = new QLineEdit(tab_2);
        id_modif->setObjectName(QStringLiteral("id_modif"));
        id_modif->setGeometry(QRect(680, 200, 113, 20));
        id_modif->setStyleSheet(QStringLiteral("color:rgb(255, 255, 255)"));
        label_13 = new QLabel(tab_2);
        label_13->setObjectName(QStringLiteral("label_13"));
        label_13->setGeometry(QRect(530, 240, 131, 20));
        label_13->setStyleSheet(QLatin1String("QLabel\n"
"{\n"
"	background-color: transparent;\n"
"	color: #fff;\n"
"	font-size: 14pt;\n"
"	border-color: #000000;\n"
"\n"
"}"));
        lastname_modif = new QLineEdit(tab_2);
        lastname_modif->setObjectName(QStringLiteral("lastname_modif"));
        lastname_modif->setGeometry(QRect(680, 240, 113, 20));
        lastname_modif->setStyleSheet(QStringLiteral("color:rgb(255, 255, 255)"));
        label_14 = new QLabel(tab_2);
        label_14->setObjectName(QStringLiteral("label_14"));
        label_14->setGeometry(QRect(570, 280, 91, 16));
        label_14->setStyleSheet(QLatin1String("QLabel\n"
"{\n"
"	background-color: transparent;\n"
"	color: #fff;\n"
"	font-size: 14pt;\n"
"	border-color: #000000;\n"
"\n"
"}"));
        name_modif = new QLineEdit(tab_2);
        name_modif->setObjectName(QStringLiteral("name_modif"));
        name_modif->setGeometry(QRect(680, 280, 113, 20));
        name_modif->setStyleSheet(QStringLiteral("color:rgb(255, 255, 255)"));
        label_15 = new QLabel(tab_2);
        label_15->setObjectName(QStringLiteral("label_15"));
        label_15->setGeometry(QRect(540, 320, 111, 20));
        label_15->setStyleSheet(QLatin1String("QLabel\n"
"{\n"
"	background-color: transparent;\n"
"	color: #fff;\n"
"	font-size: 14pt;\n"
"	border-color: #000000;\n"
"\n"
"}"));
        adress_modif = new QLineEdit(tab_2);
        adress_modif->setObjectName(QStringLiteral("adress_modif"));
        adress_modif->setGeometry(QRect(680, 320, 113, 20));
        adress_modif->setStyleSheet(QStringLiteral("color:rgb(255, 255, 255)"));
        label_57 = new QLabel(tab_2);
        label_57->setObjectName(QStringLiteral("label_57"));
        label_57->setGeometry(QRect(570, 360, 81, 16));
        label_57->setStyleSheet(QLatin1String("QLabel\n"
"{\n"
"	background-color: transparent;\n"
"	color: #fff;\n"
"	font-size: 14pt;\n"
"	border-color: #000000;\n"
"\n"
"}"));
        num_modif = new QLineEdit(tab_2);
        num_modif->setObjectName(QStringLiteral("num_modif"));
        num_modif->setGeometry(QRect(680, 360, 113, 20));
        num_modif->setStyleSheet(QStringLiteral("color:rgb(255, 255, 255)"));
        label_58 = new QLabel(tab_2);
        label_58->setObjectName(QStringLiteral("label_58"));
        label_58->setGeometry(QRect(570, 400, 91, 16));
        label_58->setStyleSheet(QLatin1String("QLabel\n"
"{\n"
"	background-color: transparent;\n"
"	color: #fff;\n"
"	font-size: 14pt;\n"
"	border-color: #000000;\n"
"\n"
"}"));
        mail_modif = new QLineEdit(tab_2);
        mail_modif->setObjectName(QStringLiteral("mail_modif"));
        mail_modif->setGeometry(QRect(680, 400, 113, 20));
        mail_modif->setStyleSheet(QStringLiteral("color:rgb(255, 255, 255)"));
        comboBox = new QComboBox(tab_2);
        comboBox->setObjectName(QStringLiteral("comboBox"));
        comboBox->setGeometry(QRect(650, 440, 62, 22));
        comboBox->setStyleSheet(QStringLiteral("color:rgb(255, 255, 255)"));
        label_59 = new QLabel(tab_2);
        label_59->setObjectName(QStringLiteral("label_59"));
        label_59->setGeometry(QRect(570, 440, 71, 16));
        label_59->setStyleSheet(QLatin1String("QLabel\n"
"{\n"
"	background-color: transparent;\n"
"	color: #fff;\n"
"	font-size: 14pt;\n"
"	border-color: #000000;\n"
"\n"
"}"));
        search_name = new QPushButton(tab_2);
        search_name->setObjectName(QStringLiteral("search_name"));
        search_name->setGeometry(QRect(310, 300, 75, 23));
        search_name->setStyleSheet(QLatin1String("QPushButton\n"
"{background-color: rgb(200,133,0);\n"
"color : white;\n"
"font: 10pt Arial;\n"
"            border-radius: 4px;\n"
"            text-shadow: 0 1px 1px rgba(0, 0, 0, 0.2);\n"
"border: 2px solid rgb(200,133,0);\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"border: 2px solid rgb(200,146,0);\n"
"background-color : rgb(200,149,47);\n"
"}"));
        search_adress = new QPushButton(tab_2);
        search_adress->setObjectName(QStringLiteral("search_adress"));
        search_adress->setGeometry(QRect(310, 350, 75, 23));
        search_adress->setStyleSheet(QLatin1String("QPushButton\n"
"{background-color: rgb(200,133,0);\n"
"color : white;\n"
"font: 10pt Arial;\n"
"            border-radius: 4px;\n"
"            text-shadow: 0 1px 1px rgba(0, 0, 0, 0.2);\n"
"border: 2px solid rgb(200,133,0);\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"border: 2px solid rgb(200,146,0);\n"
"background-color : rgb(200,149,47);\n"
"}"));
        search_id_2 = new QLineEdit(tab_2);
        search_id_2->setObjectName(QStringLiteral("search_id_2"));
        search_id_2->setGeometry(QRect(150, 260, 113, 20));
        search_id_2->setStyleSheet(QStringLiteral("color:rgb(255, 255, 255)"));
        search_name_2 = new QLineEdit(tab_2);
        search_name_2->setObjectName(QStringLiteral("search_name_2"));
        search_name_2->setGeometry(QRect(150, 300, 113, 20));
        search_name_2->setStyleSheet(QStringLiteral("color:rgb(255, 255, 255)"));
        search_adress_2 = new QLineEdit(tab_2);
        search_adress_2->setObjectName(QStringLiteral("search_adress_2"));
        search_adress_2->setGeometry(QRect(150, 350, 113, 20));
        search_adress_2->setStyleSheet(QStringLiteral("color:rgb(255, 255, 255)"));
        label_60 = new QLabel(tab_2);
        label_60->setObjectName(QStringLiteral("label_60"));
        label_60->setGeometry(QRect(40, 260, 61, 16));
        label_60->setStyleSheet(QLatin1String("QLabel\n"
"{\n"
"	background-color: transparent;\n"
"	color: #fff;\n"
"	font-size: 14pt;\n"
"	border-color: #000000;\n"
"\n"
"}"));
        label_61 = new QLabel(tab_2);
        label_61->setObjectName(QStringLiteral("label_61"));
        label_61->setGeometry(QRect(40, 300, 91, 16));
        label_61->setStyleSheet(QLatin1String("QLabel\n"
"{\n"
"	background-color: transparent;\n"
"	color: #fff;\n"
"	font-size: 14pt;\n"
"	border-color: #000000;\n"
"\n"
"}"));
        label_62 = new QLabel(tab_2);
        label_62->setObjectName(QStringLiteral("label_62"));
        label_62->setGeometry(QRect(20, 350, 111, 16));
        label_62->setStyleSheet(QLatin1String("QLabel\n"
"{\n"
"	background-color: transparent;\n"
"	color: #fff;\n"
"	font-size: 14pt;\n"
"	border-color: #000000;\n"
"\n"
"}"));
        todo = new QPushButton(tab_2);
        todo->setObjectName(QStringLiteral("todo"));
        todo->setGeometry(QRect(420, 440, 75, 23));
        todo->setStyleSheet(QLatin1String("QPushButton\n"
"{background-color: rgb(200,133,0);\n"
"color : white;\n"
"font: 10pt Arial;\n"
"            border-radius: 4px;\n"
"            text-shadow: 0 1px 1px rgba(0, 0, 0, 0.2);\n"
"border: 2px solid rgb(200,133,0);\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"border: 2px solid rgb(200,146,0);\n"
"background-color : rgb(200,149,47);\n"
"}"));
        tabWidget_4->addTab(tab_2, QString());
        textEdit = new QTextEdit(page_6);
        textEdit->setObjectName(QStringLiteral("textEdit"));
        textEdit->setGeometry(QRect(310, 0, 261, 61));
        textEdit->setStyleSheet(QStringLiteral(""));
        stackedWidget->addWidget(page_6);
        page_7 = new QWidget();
        page_7->setObjectName(QStringLiteral("page_7"));
        tabWidget_6 = new QTabWidget(page_7);
        tabWidget_6->setObjectName(QStringLiteral("tabWidget_6"));
        tabWidget_6->setGeometry(QRect(40, 0, 971, 631));
        tab_7 = new QWidget();
        tab_7->setObjectName(QStringLiteral("tab_7"));
        frame = new QFrame(tab_7);
        frame->setObjectName(QStringLiteral("frame"));
        frame->setGeometry(QRect(40, 310, 120, 80));
        frame->setStyleSheet(QStringLiteral("background-image: url(C:/Users/Souid/Downloads/Qtvideo.mp4);"));
        frame->setFrameShape(QFrame::StyledPanel);
        frame->setFrameShadow(QFrame::Raised);
        stackedWidget_2 = new QStackedWidget(tab_7);
        stackedWidget_2->setObjectName(QStringLiteral("stackedWidget_2"));
        stackedWidget_2->setGeometry(QRect(10, 0, 831, 561));
        page_9 = new QWidget();
        page_9->setObjectName(QStringLiteral("page_9"));
        pushButton_security_arduino = new QPushButton(page_9);
        pushButton_security_arduino->setObjectName(QStringLiteral("pushButton_security_arduino"));
        pushButton_security_arduino->setGeometry(QRect(370, 110, 75, 23));
        pushButton_security_arduino_2 = new QPushButton(page_9);
        pushButton_security_arduino_2->setObjectName(QStringLiteral("pushButton_security_arduino_2"));
        pushButton_security_arduino_2->setGeometry(QRect(510, 110, 75, 23));
        pushButton_28 = new QPushButton(page_9);
        pushButton_28->setObjectName(QStringLiteral("pushButton_28"));
        pushButton_28->setGeometry(QRect(50, 60, 75, 23));
        label_63 = new QLabel(page_9);
        label_63->setObjectName(QStringLiteral("label_63"));
        label_63->setGeometry(QRect(40, 20, 301, 41));
        label_64 = new QLabel(page_9);
        label_64->setObjectName(QStringLiteral("label_64"));
        label_64->setGeometry(QRect(40, 100, 311, 71));
        stackedWidget_2->addWidget(page_9);
        page_10 = new QWidget();
        page_10->setObjectName(QStringLiteral("page_10"));
        stackedWidget_2->addWidget(page_10);
        tabWidget_6->addTab(tab_7, QString());
        tab_15 = new QWidget();
        tab_15->setObjectName(QStringLiteral("tab_15"));
        groupBox_3 = new QGroupBox(tab_15);
        groupBox_3->setObjectName(QStringLiteral("groupBox_3"));
        groupBox_3->setGeometry(QRect(20, 200, 331, 301));
        groupBox_3->setStyleSheet(QStringLiteral("color: rgb(255, 255, 255);"));
        gridLayout = new QGridLayout(groupBox_3);
        gridLayout->setObjectName(QStringLiteral("gridLayout"));
        label_65 = new QLabel(groupBox_3);
        label_65->setObjectName(QStringLiteral("label_65"));

        gridLayout->addWidget(label_65, 2, 0, 1, 1);

        lineEdit_longitude_prop = new QLineEdit(groupBox_3);
        lineEdit_longitude_prop->setObjectName(QStringLiteral("lineEdit_longitude_prop"));
        lineEdit_longitude_prop->setStyleSheet(QStringLiteral("color : rgb(255, 255, 255) ;"));

        gridLayout->addWidget(lineEdit_longitude_prop, 4, 1, 1, 1);

        lineEdit_price_pro = new QLineEdit(groupBox_3);
        lineEdit_price_pro->setObjectName(QStringLiteral("lineEdit_price_pro"));
        lineEdit_price_pro->setStyleSheet(QStringLiteral("color : rgb(255, 255, 255) ;"));

        gridLayout->addWidget(lineEdit_price_pro, 2, 1, 1, 1);

        label_66 = new QLabel(groupBox_3);
        label_66->setObjectName(QStringLiteral("label_66"));

        gridLayout->addWidget(label_66, 3, 0, 1, 1);

        label_67 = new QLabel(groupBox_3);
        label_67->setObjectName(QStringLiteral("label_67"));

        gridLayout->addWidget(label_67, 4, 0, 1, 1);

        lineEdit_latitude_prop = new QLineEdit(groupBox_3);
        lineEdit_latitude_prop->setObjectName(QStringLiteral("lineEdit_latitude_prop"));
        lineEdit_latitude_prop->setStyleSheet(QStringLiteral("color : rgb(255, 255, 255) ;"));

        gridLayout->addWidget(lineEdit_latitude_prop, 3, 1, 1, 1);

        lineEdit_Id_prop = new QLineEdit(groupBox_3);
        lineEdit_Id_prop->setObjectName(QStringLiteral("lineEdit_Id_prop"));
        lineEdit_Id_prop->setStyleSheet(QStringLiteral("color : rgb(255, 255, 255) ;"));

        gridLayout->addWidget(lineEdit_Id_prop, 0, 1, 1, 1);

        lineEdit_Type_prop = new QLineEdit(groupBox_3);
        lineEdit_Type_prop->setObjectName(QStringLiteral("lineEdit_Type_prop"));
        lineEdit_Type_prop->setStyleSheet(QStringLiteral("color : rgb(255, 255, 255) ;"));

        gridLayout->addWidget(lineEdit_Type_prop, 1, 1, 1, 1);

        label_68 = new QLabel(groupBox_3);
        label_68->setObjectName(QStringLiteral("label_68"));

        gridLayout->addWidget(label_68, 1, 0, 1, 1);

        label_69 = new QLabel(groupBox_3);
        label_69->setObjectName(QStringLiteral("label_69"));

        gridLayout->addWidget(label_69, 0, 0, 1, 1);

        pushButton_29 = new QPushButton(groupBox_3);
        pushButton_29->setObjectName(QStringLiteral("pushButton_29"));
        pushButton_29->setStyleSheet(QLatin1String("QPushButton\n"
"{background-color: rgb(200,133,0);\n"
"color : white;\n"
"font: 10pt Arial;\n"
"            border-radius: 4px;\n"
"            text-shadow: 0 1px 1px rgba(0, 0, 0, 0.2);\n"
"border: 2px solid rgb(200,133,0);\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"border: 2px solid rgb(200,146,0);\n"
"background-color : rgb(200,149,47);\n"
"}"));

        gridLayout->addWidget(pushButton_29, 5, 0, 1, 1);

        lineEdit_2 = new QLineEdit(groupBox_3);
        lineEdit_2->setObjectName(QStringLiteral("lineEdit_2"));

        gridLayout->addWidget(lineEdit_2, 5, 1, 1, 1);

        pushButton_30 = new QPushButton(groupBox_3);
        pushButton_30->setObjectName(QStringLiteral("pushButton_30"));
        pushButton_30->setStyleSheet(QLatin1String("QPushButton\n"
"{background-color: rgb(200,133,0);\n"
"color : white;\n"
"font: 10pt Arial;\n"
"            border-radius: 4px;\n"
"            text-shadow: 0 1px 1px rgba(0, 0, 0, 0.2);\n"
"border: 2px solid rgb(200,133,0);\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"border: 2px solid rgb(200,146,0);\n"
"background-color : rgb(200,149,47);\n"
"}"));

        gridLayout->addWidget(pushButton_30, 6, 0, 1, 1);

        lineEdit_3 = new QLineEdit(groupBox_3);
        lineEdit_3->setObjectName(QStringLiteral("lineEdit_3"));

        gridLayout->addWidget(lineEdit_3, 6, 1, 1, 1);

        pushButton_database_insert = new QPushButton(tab_15);
        pushButton_database_insert->setObjectName(QStringLiteral("pushButton_database_insert"));
        pushButton_database_insert->setGeometry(QRect(0, 520, 191, 23));
        pushButton_database_insert->setStyleSheet(QLatin1String("QPushButton\n"
"{background-color: rgb(200,133,0);\n"
"color : white;\n"
"font: 10pt Arial;\n"
"            border-radius: 4px;\n"
"            text-shadow: 0 1px 1px rgba(0, 0, 0, 0.2);\n"
"border: 2px solid rgb(200,133,0);\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"border: 2px solid rgb(200,146,0);\n"
"background-color : rgb(200,149,47);\n"
"}"));
        tableView_2_prop = new QTableView(tab_15);
        tableView_2_prop->setObjectName(QStringLiteral("tableView_2_prop"));
        tableView_2_prop->setGeometry(QRect(0, 0, 831, 192));
        tableView_2_prop->setStyleSheet(QLatin1String("QTableView {border: 3px solid #5E749C;text-align: top;padding: 4px;border-radius: 7px;border-bottom-left-radius: 7px;background: QLinearGradient( x1: 0, y1: 0, x2: 1, y2: 0,stop: 0 #fff, stop: 1 #eee,stop: 0.5 #ddd,stop: 1 #eee );width: 15px;}\n"
"QTableView::item:focus{selection-background-color: yellow;}\n"
"\n"
"\n"
" \n"
"\n"
" \n"
"\n"
""));
        pushButton_delete_prop = new QPushButton(tab_15);
        pushButton_delete_prop->setObjectName(QStringLiteral("pushButton_delete_prop"));
        pushButton_delete_prop->setGeometry(QRect(630, 510, 116, 23));
        pushButton_delete_prop->setStyleSheet(QLatin1String("QPushButton\n"
"{background-color: rgb(200,133,0);\n"
"color : white;\n"
"font: 10pt Arial;\n"
"            border-radius: 4px;\n"
"            text-shadow: 0 1px 1px rgba(0, 0, 0, 0.2);\n"
"border: 2px solid rgb(200,133,0);\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"border: 2px solid rgb(200,146,0);\n"
"background-color : rgb(200,149,47);\n"
"}"));
        comboBox_7 = new QComboBox(tab_15);
        comboBox_7->setObjectName(QStringLiteral("comboBox_7"));
        comboBox_7->setGeometry(QRect(360, 520, 71, 31));
        comboBox_7->setStyleSheet(QStringLiteral("color : rgb(255, 255, 255) ;"));
        update_prop = new QPushButton(tab_15);
        update_prop->setObjectName(QStringLiteral("update_prop"));
        update_prop->setGeometry(QRect(240, 520, 111, 23));
        update_prop->setStyleSheet(QLatin1String("QPushButton\n"
"{background-color: rgb(200,133,0);\n"
"color : white;\n"
"font: 10pt Arial;\n"
"            border-radius: 4px;\n"
"            text-shadow: 0 1px 1px rgba(0, 0, 0, 0.2);\n"
"border: 2px solid rgb(200,133,0);\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"border: 2px solid rgb(200,146,0);\n"
"background-color : rgb(200,149,47);\n"
"}"));
        comboBox_8 = new QComboBox(tab_15);
        comboBox_8->setObjectName(QStringLiteral("comboBox_8"));
        comboBox_8->setGeometry(QRect(420, 210, 62, 22));
        comboBox_8->setStyleSheet(QStringLiteral("color : rgb(255, 255, 255) ;"));
        comboBox_9 = new QComboBox(tab_15);
        comboBox_9->setObjectName(QStringLiteral("comboBox_9"));
        comboBox_9->setGeometry(QRect(420, 240, 62, 22));
        comboBox_9->setStyleSheet(QStringLiteral("color : rgb(255, 255, 255) ;"));
        label_70 = new QLabel(tab_15);
        label_70->setObjectName(QStringLiteral("label_70"));
        label_70->setGeometry(QRect(370, 210, 47, 14));
        label_70->setStyleSheet(QStringLiteral("color: rgb(255, 255, 255);"));
        label_71 = new QLabel(tab_15);
        label_71->setObjectName(QStringLiteral("label_71"));
        label_71->setGeometry(QRect(370, 240, 47, 14));
        label_71->setStyleSheet(QStringLiteral("color: rgb(255, 255, 255);"));
        label_72 = new QLabel(tab_15);
        label_72->setObjectName(QStringLiteral("label_72"));
        label_72->setGeometry(QRect(500, 200, 141, 41));
        label_72->setStyleSheet(QStringLiteral("color : rgb(255, 255, 255) ;"));
        label_73 = new QLabel(tab_15);
        label_73->setObjectName(QStringLiteral("label_73"));
        label_73->setGeometry(QRect(500, 240, 141, 41));
        label_73->setStyleSheet(QStringLiteral("color : rgb(255, 255, 255) ;"));
        label_74 = new QLabel(tab_15);
        label_74->setObjectName(QStringLiteral("label_74"));
        label_74->setGeometry(QRect(500, 280, 151, 41));
        label_74->setStyleSheet(QStringLiteral("color : rgb(255, 255, 255) ;"));
        lineEdit_find_id_prop = new QLineEdit(tab_15);
        lineEdit_find_id_prop->setObjectName(QStringLiteral("lineEdit_find_id_prop"));
        lineEdit_find_id_prop->setGeometry(QRect(700, 210, 111, 31));
        lineEdit_find_type_prop = new QLineEdit(tab_15);
        lineEdit_find_type_prop->setObjectName(QStringLiteral("lineEdit_find_type_prop"));
        lineEdit_find_type_prop->setGeometry(QRect(700, 250, 111, 31));
        lineEdit_find_price_prop = new QLineEdit(tab_15);
        lineEdit_find_price_prop->setObjectName(QStringLiteral("lineEdit_find_price_prop"));
        lineEdit_find_price_prop->setGeometry(QRect(700, 290, 111, 31));
        pushButton_31 = new QPushButton(tab_15);
        pushButton_31->setObjectName(QStringLiteral("pushButton_31"));
        pushButton_31->setGeometry(QRect(850, 210, 75, 23));
        pushButton_31->setStyleSheet(QLatin1String("QPushButton\n"
"{background-color: rgb(200,133,0);\n"
"color : white;\n"
"font: 10pt Arial;\n"
"            border-radius: 4px;\n"
"            text-shadow: 0 1px 1px rgba(0, 0, 0, 0.2);\n"
"border: 2px solid rgb(200,133,0);\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"border: 2px solid rgb(200,146,0);\n"
"background-color : rgb(200,149,47);\n"
"}"));
        pushButton_32 = new QPushButton(tab_15);
        pushButton_32->setObjectName(QStringLiteral("pushButton_32"));
        pushButton_32->setGeometry(QRect(850, 250, 75, 23));
        pushButton_32->setStyleSheet(QLatin1String("QPushButton\n"
"{background-color: rgb(200,133,0);\n"
"color : white;\n"
"font: 10pt Arial;\n"
"            border-radius: 4px;\n"
"            text-shadow: 0 1px 1px rgba(0, 0, 0, 0.2);\n"
"border: 2px solid rgb(200,133,0);\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"border: 2px solid rgb(200,146,0);\n"
"background-color : rgb(200,149,47);\n"
"}"));
        pushButton_33 = new QPushButton(tab_15);
        pushButton_33->setObjectName(QStringLiteral("pushButton_33"));
        pushButton_33->setGeometry(QRect(850, 290, 75, 23));
        pushButton_33->setStyleSheet(QLatin1String("QPushButton\n"
"{background-color: rgb(200,133,0);\n"
"color : white;\n"
"font: 10pt Arial;\n"
"            border-radius: 4px;\n"
"            text-shadow: 0 1px 1px rgba(0, 0, 0, 0.2);\n"
"border: 2px solid rgb(200,133,0);\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"border: 2px solid rgb(200,146,0);\n"
"background-color : rgb(200,149,47);\n"
"}"));
        pushButton_34 = new QPushButton(tab_15);
        pushButton_34->setObjectName(QStringLiteral("pushButton_34"));
        pushButton_34->setGeometry(QRect(850, 0, 81, 23));
        pushButton_34->setStyleSheet(QLatin1String("QPushButton\n"
"{background-color: rgb(200,133,0);\n"
"color : white;\n"
"font: 10pt Arial;\n"
"            border-radius: 4px;\n"
"            text-shadow: 0 1px 1px rgba(0, 0, 0, 0.2);\n"
"border: 2px solid rgb(200,133,0);\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"border: 2px solid rgb(200,146,0);\n"
"background-color : rgb(200,149,47);\n"
"}"));
        pushButton_35 = new QPushButton(tab_15);
        pushButton_35->setObjectName(QStringLiteral("pushButton_35"));
        pushButton_35->setGeometry(QRect(850, 30, 81, 23));
        pushButton_35->setStyleSheet(QLatin1String("QPushButton\n"
"{background-color: rgb(200,133,0);\n"
"color : white;\n"
"font: 10pt Arial;\n"
"            border-radius: 4px;\n"
"            text-shadow: 0 1px 1px rgba(0, 0, 0, 0.2);\n"
"border: 2px solid rgb(200,133,0);\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"border: 2px solid rgb(200,146,0);\n"
"background-color : rgb(200,149,47);\n"
"}"));
        pushButton_36 = new QPushButton(tab_15);
        pushButton_36->setObjectName(QStringLiteral("pushButton_36"));
        pushButton_36->setGeometry(QRect(850, 60, 81, 23));
        pushButton_36->setStyleSheet(QLatin1String("QPushButton\n"
"{background-color: rgb(200,133,0);\n"
"color : white;\n"
"font: 10pt Arial;\n"
"            border-radius: 4px;\n"
"            text-shadow: 0 1px 1px rgba(0, 0, 0, 0.2);\n"
"border: 2px solid rgb(200,133,0);\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"border: 2px solid rgb(200,146,0);\n"
"background-color : rgb(200,149,47);\n"
"}"));
        plainTextEdit_2 = new QPlainTextEdit(tab_15);
        plainTextEdit_2->setObjectName(QStringLiteral("plainTextEdit_2"));
        plainTextEdit_2->setGeometry(QRect(520, 340, 431, 141));
        plainTextEdit_2->setStyleSheet(QStringLiteral("color: rgb(255,255,255);"));
        label_75 = new QLabel(tab_15);
        label_75->setObjectName(QStringLiteral("label_75"));
        label_75->setGeometry(QRect(370, 390, 151, 41));
        label_75->setStyleSheet(QStringLiteral("color : rgb(255, 255, 255) ;"));
        pushButton_5 = new QPushButton(tab_15);
        pushButton_5->setObjectName(QStringLiteral("pushButton_5"));
        pushButton_5->setGeometry(QRect(380, 300, 75, 23));
        pushButton_5->setStyleSheet(QLatin1String("QPushButton\n"
"{background-color: rgb(200,133,0);\n"
"color : white;\n"
"font: 10pt Arial;\n"
"            border-radius: 4px;\n"
"            text-shadow: 0 1px 1px rgba(0, 0, 0, 0.2);\n"
"border: 2px solid rgb(200,133,0);\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"border: 2px solid rgb(200,146,0);\n"
"background-color : rgb(200,149,47);\n"
"}"));
        pushButton_37 = new QPushButton(tab_15);
        pushButton_37->setObjectName(QStringLiteral("pushButton_37"));
        pushButton_37->setGeometry(QRect(850, 100, 101, 31));
        pushButton_37->setStyleSheet(QLatin1String("QPushButton\n"
"{background-color: rgb(200,133,0);\n"
"color : white;\n"
"font: 10pt Arial;\n"
"            border-radius: 4px;\n"
"            text-shadow: 0 1px 1px rgba(0, 0, 0, 0.2);\n"
"border: 2px solid rgb(200,133,0);\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"border: 2px solid rgb(200,146,0);\n"
"background-color : rgb(200,149,47);\n"
"}"));
        pushButton_38 = new QPushButton(tab_15);
        pushButton_38->setObjectName(QStringLiteral("pushButton_38"));
        pushButton_38->setGeometry(QRect(850, 150, 101, 31));
        pushButton_38->setStyleSheet(QLatin1String("QPushButton\n"
"{background-color: rgb(200,133,0);\n"
"color : white;\n"
"font: 10pt Arial;\n"
"            border-radius: 4px;\n"
"            text-shadow: 0 1px 1px rgba(0, 0, 0, 0.2);\n"
"border: 2px solid rgb(200,133,0);\n"
"}\n"
"\n"
"QPushButton:hover {\n"
"border: 2px solid rgb(200,146,0);\n"
"background-color : rgb(200,149,47);\n"
"}"));
        comboBox_10 = new QComboBox(tab_15);
        comboBox_10->setObjectName(QStringLiteral("comboBox_10"));
        comboBox_10->setGeometry(QRect(760, 510, 101, 22));
        comboBox_10->setStyleSheet(QStringLiteral("color : rgb(255,255,255);"));
        tabWidget_6->addTab(tab_15, QString());
        stackedWidget->addWidget(page_7);
        page_5 = new QWidget();
        page_5->setObjectName(QStringLiteral("page_5"));
        plainTextEdit = new QPlainTextEdit(page_5);
        plainTextEdit->setObjectName(QStringLiteral("plainTextEdit"));
        plainTextEdit->setGeometry(QRect(0, 20, 1011, 481));
        plainTextEdit->setStyleSheet(QStringLiteral("color: rgb(255, 255, 255)"));
        lineEdit = new QLineEdit(page_5);
        lineEdit->setObjectName(QStringLiteral("lineEdit"));
        lineEdit->setGeometry(QRect(440, 340, 271, 71));
        lineEdit->setStyleSheet(QStringLiteral("color : rgb(255,255,255);"));
        chat = new QPushButton(page_5);
        chat->setObjectName(QStringLiteral("chat"));
        chat->setGeometry(QRect(230, 340, 191, 61));
        chat->setStyleSheet(QLatin1String("background-color: qlineargradient(spread:repeat, x1:1, y1:0, x2:1, y2:1, stop:0 rgba(254, 171, 66, 255),stop:1 rgba(255, 153, 0, 255));\n"
"	color: #000;\n"
"	font-size: 14pt;\n"
"	border-radius: 4px;\n"
"	padding: 10px;\n"
""));
        chat->setIcon(icon3);
        pushButton_24 = new QPushButton(page_5);
        pushButton_24->setObjectName(QStringLiteral("pushButton_24"));
        pushButton_24->setGeometry(QRect(30, 440, 221, 51));
        pushButton_24->setStyleSheet(QLatin1String("background-color: qlineargradient(spread:repeat, x1:1, y1:0, x2:1, y2:1, stop:0 rgba(254, 171, 66, 255),stop:1 rgba(255, 153, 0, 255));\n"
"	color: #000;\n"
"	font-size: 14pt;\n"
"	border-radius: 4px;\n"
"	padding: 10px;\n"
""));
        pushButton_24->setIcon(icon2);
        lineEdit_login_3 = new QLineEdit(page_5);
        lineEdit_login_3->setObjectName(QStringLiteral("lineEdit_login_3"));
        lineEdit_login_3->setGeometry(QRect(800, 430, 113, 22));
        comboBox_2 = new QComboBox(page_5);
        comboBox_2->setObjectName(QStringLiteral("comboBox_2"));
        comboBox_2->setGeometry(QRect(782, 341, 141, 51));
        combo = new QPushButton(page_5);
        combo->setObjectName(QStringLiteral("combo"));
        combo->setGeometry(QRect(480, 440, 51, 21));
        combo->setStyleSheet(QLatin1String("background-color: qlineargradient(spread:repeat, x1:1, y1:0, x2:1, y2:1, stop:0 rgba(254, 171, 66, 255),stop:1 rgba(255, 153, 0, 255));\n"
"	color: #000;\n"
"	font-size: 14pt;\n"
"	border-radius: 4px;\n"
"	padding: 10px;\n"
""));
        combo->setIcon(icon3);
        stackedWidget->addWidget(page_5);
        MainWindow->setCentralWidget(centralwidget);
        menubar = new QMenuBar(MainWindow);
        menubar->setObjectName(QStringLiteral("menubar"));
        menubar->setGeometry(QRect(0, 0, 1570, 26));
        MainWindow->setMenuBar(menubar);
        statusbar = new QStatusBar(MainWindow);
        statusbar->setObjectName(QStringLiteral("statusbar"));
        MainWindow->setStatusBar(statusbar);

        retranslateUi(MainWindow);

        stackedWidget->setCurrentIndex(6);
        tabWidget_5->setCurrentIndex(1);
        tabWidget_3->setCurrentIndex(1);
        tabWidget_2->setCurrentIndex(0);
        tabWidget->setCurrentIndex(0);
        tabWidget_4->setCurrentIndex(0);
        tabWidget_6->setCurrentIndex(0);


        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QApplication::translate("MainWindow", "MainWindow", Q_NULLPTR));
        pushButton_7->setText(QApplication::translate("MainWindow", "Agent", Q_NULLPTR));
        pushButton_14->setText(QApplication::translate("MainWindow", "Buyer ", Q_NULLPTR));
        pushButton_18->setText(QApplication::translate("MainWindow", "Seller", Q_NULLPTR));
        pushButton_19->setText(QApplication::translate("MainWindow", "Partners", Q_NULLPTR));
        pushButton_20->setText(QApplication::translate("MainWindow", "Subscription", Q_NULLPTR));
        pushButton_21->setText(QApplication::translate("MainWindow", "Propreties", Q_NULLPTR));
        pushButton_22->setText(QApplication::translate("MainWindow", "Deals", Q_NULLPTR));
        pushButton_9->setText(QApplication::translate("MainWindow", "Previous page", Q_NULLPTR));
        pushButton_10->setText(QApplication::translate("MainWindow", "Logout", Q_NULLPTR));
        label_4->setText(QApplication::translate("MainWindow", "<html><head/><body><p align=\"center\"><span style=\" font-size:28pt; font-weight:600; color:#ffffff;\">Partners  Page</span></p></body></html>", Q_NULLPTR));
        label_96->setText(QApplication::translate("MainWindow", "Add Partner", Q_NULLPTR));
        label_97->setText(QApplication::translate("MainWindow", "name", Q_NULLPTR));
        label_98->setText(QApplication::translate("MainWindow", "type", Q_NULLPTR));
        label_99->setText(QApplication::translate("MainWindow", "duration", Q_NULLPTR));
        label_100->setText(QApplication::translate("MainWindow", "contract language", Q_NULLPTR));
        label_101->setText(QApplication::translate("MainWindow", "sub number", Q_NULLPTR));
        name_par_2->setText(QString());
        add_2->setText(QApplication::translate("MainWindow", "Add", Q_NULLPTR));
        label_103->setText(QApplication::translate("MainWindow", "id", Q_NULLPTR));
        tabWidget_5->setTabText(tabWidget_5->indexOf(tab_8), QApplication::translate("MainWindow", "Add", Q_NULLPTR));
        sort_par_2->setText(QApplication::translate("MainWindow", "sort by id", Q_NULLPTR));
        sort_par->setText(QApplication::translate("MainWindow", "sort by name", Q_NULLPTR));
        sort_par_3->setText(QApplication::translate("MainWindow", "sort by language", Q_NULLPTR));
        label_104->setText(QApplication::translate("MainWindow", "ID to find", Q_NULLPTR));
        label_105->setText(QApplication::translate("MainWindow", "Name to find", Q_NULLPTR));
        supprimer_2->setText(QApplication::translate("MainWindow", "Delete", Q_NULLPTR));
        label_106->setText(QApplication::translate("MainWindow", "ID", Q_NULLPTR));
        label_107->setText(QApplication::translate("MainWindow", "ID", Q_NULLPTR));
        type_up_2->setText(QString());
        label_108->setText(QApplication::translate("MainWindow", "duration", Q_NULLPTR));
        name_up_2->setText(QString());
        label_109->setText(QApplication::translate("MainWindow", "Mail", Q_NULLPTR));
        label_110->setText(QApplication::translate("MainWindow", "NAME", Q_NULLPTR));
        id_up_2->setText(QString());
        duration_up_2->setText(QString());
        label_111->setText(QApplication::translate("MainWindow", "contract laguage", Q_NULLPTR));
        label_112->setText(QApplication::translate("MainWindow", "Type", Q_NULLPTR));
        conlang_up_2->setText(QString());
        update_3->setText(QApplication::translate("MainWindow", "UPDATE", Q_NULLPTR));
        id_dell_2->setText(QString());
        pushButton_42->setText(QApplication::translate("MainWindow", "load by id", Q_NULLPTR));
        subnum_up_2->setText(QString());
        label_113->setText(QApplication::translate("MainWindow", "sub num", Q_NULLPTR));
        tri_stock_7->setText(QApplication::translate("MainWindow", "pdf eng", Q_NULLPTR));
        tri_stock_8->setText(QApplication::translate("MainWindow", "excel", Q_NULLPTR));
        tri_stock_9->setText(QApplication::translate("MainWindow", "pdf fr", Q_NULLPTR));
        tri_stock_10->setText(QApplication::translate("MainWindow", "pdf esp", Q_NULLPTR));
        tabWidget_5->setTabText(tabWidget_5->indexOf(tab_13), QApplication::translate("MainWindow", "Read", Q_NULLPTR));
        ig_2->setText(QApplication::translate("MainWindow", "ig", Q_NULLPTR));
        fb_2->setText(QApplication::translate("MainWindow", "fb", Q_NULLPTR));
        linkedin_2->setText(QApplication::translate("MainWindow", "linkedin", Q_NULLPTR));
        label_114->setText(QString());
        label_115->setText(QString());
        label_116->setText(QString());
        tabWidget_5->setTabText(tabWidget_5->indexOf(tab_14), QApplication::translate("MainWindow", "media", Q_NULLPTR));
        label_76->setText(QApplication::translate("MainWindow", "Add Subscription", Q_NULLPTR));
        pb_add_2->setText(QApplication::translate("MainWindow", "Add", Q_NULLPTR));
        label_77->setText(QApplication::translate("MainWindow", "End Date", Q_NULLPTR));
        label_79->setText(QApplication::translate("MainWindow", "Type", Q_NULLPTR));
        label_80->setText(QApplication::translate("MainWindow", "IdBuy", Q_NULLPTR));
        label_81->setText(QApplication::translate("MainWindow", "Price", Q_NULLPTR));
        label_82->setText(QApplication::translate("MainWindow", "Start Date", Q_NULLPTR));
        label_83->setText(QApplication::translate("MainWindow", "Number", Q_NULLPTR));
        label_84->setText(QApplication::translate("MainWindow", "Duration", Q_NULLPTR));
        tabWidget_3->setTabText(tabWidget_3->indexOf(tab_9), QApplication::translate("MainWindow", "Add", Q_NULLPTR));
        sortByType_2->setText(QApplication::translate("MainWindow", "Sort by type", Q_NULLPTR));
        sortById_2->setText(QApplication::translate("MainWindow", "Sort by id", Q_NULLPTR));
        sortByPrice_2->setText(QApplication::translate("MainWindow", "Sort by price", Q_NULLPTR));
        searchnum_2->setText(QApplication::translate("MainWindow", "Search", Q_NULLPTR));
        label_85->setText(QApplication::translate("MainWindow", "Number to find", Q_NULLPTR));
        label_86->setText(QApplication::translate("MainWindow", "Type to find", Q_NULLPTR));
        searchType_2->setText(QApplication::translate("MainWindow", "Search", Q_NULLPTR));
        label_87->setText(QApplication::translate("MainWindow", "Start Date to find ", Q_NULLPTR));
        searchStartDate_2->setText(QApplication::translate("MainWindow", "Search", Q_NULLPTR));
        label_88->setText(QApplication::translate("MainWindow", "Number", Q_NULLPTR));
        label_89->setText(QApplication::translate("MainWindow", "Price", Q_NULLPTR));
        label_90->setText(QApplication::translate("MainWindow", "Start Date", Q_NULLPTR));
        label_91->setText(QApplication::translate("MainWindow", "End Date", Q_NULLPTR));
        label_92->setText(QApplication::translate("MainWindow", "Type", Q_NULLPTR));
        label_93->setText(QApplication::translate("MainWindow", "Id Buyer", Q_NULLPTR));
        label_94->setText(QApplication::translate("MainWindow", "Duration", Q_NULLPTR));
        pb_delete_2->setText(QApplication::translate("MainWindow", "Delete", Q_NULLPTR));
        pd_update_2->setText(QApplication::translate("MainWindow", "Update", Q_NULLPTR));
        pb_read_2->setText(QApplication::translate("MainWindow", "Read", Q_NULLPTR));
        pbExport_2->setText(QApplication::translate("MainWindow", "Export", Q_NULLPTR));
        tabWidget_3->setTabText(tabWidget_3->indexOf(tab_10), QApplication::translate("MainWindow", "Read", Q_NULLPTR));
        tabWidget_3->setTabText(tabWidget_3->indexOf(tab_11), QApplication::translate("MainWindow", "Statistics", Q_NULLPTR));
        pb_history_2->setText(QApplication::translate("MainWindow", "Open TextFile", Q_NULLPTR));
        tabWidget_3->setTabText(tabWidget_3->indexOf(tab_12), QApplication::translate("MainWindow", "Text History", Q_NULLPTR));
        groupBox_2->setTitle(QApplication::translate("MainWindow", "GroupBox", Q_NULLPTR));
        pushButton_12->setText(QApplication::translate("MainWindow", "Previous page", Q_NULLPTR));
        label_25->setText(QApplication::translate("MainWindow", "<html><head/><body><p><span style=\" font-size:12pt;\">Mail</span></p></body></html>", Q_NULLPTR));
        label_23->setText(QApplication::translate("MainWindow", "<html><head/><body><p><span style=\" font-size:12pt;\">Adress</span></p></body></html>", Q_NULLPTR));
        label_19->setText(QApplication::translate("MainWindow", "<html><head/><body><p><span style=\" font-size:12pt;\">CIN</span></p></body></html>", Q_NULLPTR));
        label_21->setText(QApplication::translate("MainWindow", "<html><head/><body><p><span style=\" font-size:12pt;\">Name</span></p></body></html>", Q_NULLPTR));
        label_24->setText(QApplication::translate("MainWindow", "<html><head/><body><p><span style=\" font-size:12pt;\">Function</span></p><p><br/></p></body></html>", Q_NULLPTR));
        label_20->setText(QApplication::translate("MainWindow", "<html><head/><body><p><span style=\" font-size:12pt;\">Login</span></p></body></html>", Q_NULLPTR));
        lineEdit_function_2->setText(QString());
        label_17->setText(QApplication::translate("MainWindow", "<html><head/><body><p><span style=\" font-size:12pt;\">Number</span></p><p><br/></p></body></html>", Q_NULLPTR));
        label_18->setText(QApplication::translate("MainWindow", "<html><head/><body><p><span style=\" font-size:12pt;\">LastName</span></p></body></html>", Q_NULLPTR));
        label_22->setText(QApplication::translate("MainWindow", "<html><head/><body><p><span style=\" font-size:12pt;\">Password</span></p></body></html>", Q_NULLPTR));
        pushButton_6->setText(QApplication::translate("MainWindow", "UPDATE", Q_NULLPTR));
        label->setText(QApplication::translate("MainWindow", "<html><head/><body><p><span style=\" font-size:12pt;\">CIN_ag</span></p></body></html>", Q_NULLPTR));
        pushButton_15->setText(QApplication::translate("MainWindow", "Tri  CIN", Q_NULLPTR));
        pushButton_16->setText(QApplication::translate("MainWindow", " tri Name", Q_NULLPTR));
        pushButton_17->setText(QApplication::translate("MainWindow", " tri function", Q_NULLPTR));
        label_38->setText(QApplication::translate("MainWindow", "Recherche name", Q_NULLPTR));
        label_39->setText(QApplication::translate("MainWindow", "Recherche cin", Q_NULLPTR));
        pushButton_23->setText(QApplication::translate("MainWindow", "Supprimer ", Q_NULLPTR));
        label_40->setText(QApplication::translate("MainWindow", "Recherche function", Q_NULLPTR));
        chat_2->setText(QApplication::translate("MainWindow", "UPDATE", Q_NULLPTR));
        tabWidget_2->setTabText(tabWidget_2->indexOf(tab), QApplication::translate("MainWindow", " VIEW", Q_NULLPTR));
        logout->setText(QApplication::translate("MainWindow", "Logout", Q_NULLPTR));
        groupBox->setTitle(QApplication::translate("MainWindow", "GroupBox", Q_NULLPTR));
        label_16->setText(QString());
        pushButton_25->setText(QApplication::translate("MainWindow", "Previous page", Q_NULLPTR));
        label_45->setText(QApplication::translate("MainWindow", "<html><head/><body><p align=\"center\"><span style=\" font-size:24pt; color:#ff0000;\">Created Agent</span></p></body></html>", Q_NULLPTR));
        add_ag->setText(QApplication::translate("MainWindow", "ADD Agent", Q_NULLPTR));
        label_46->setText(QApplication::translate("MainWindow", "<html><head/><body><p><span style=\" font-size:12pt;\">LastName</span></p></body></html>", Q_NULLPTR));
        label_47->setText(QApplication::translate("MainWindow", "<html><head/><body><p><span style=\" font-size:12pt;\">CIN</span></p></body></html>", Q_NULLPTR));
        label_48->setText(QApplication::translate("MainWindow", "<html><head/><body><p><span style=\" font-size:12pt;\">Name</span></p></body></html>", Q_NULLPTR));
        label_49->setText(QApplication::translate("MainWindow", "<html><head/><body><p><span style=\" font-size:12pt;\">Number</span></p><p><br/></p></body></html>", Q_NULLPTR));
        label_50->setText(QApplication::translate("MainWindow", "<html><head/><body><p><span style=\" font-size:12pt;\">Mail</span></p></body></html>", Q_NULLPTR));
        label_51->setText(QApplication::translate("MainWindow", "<html><head/><body><p><span style=\" font-size:12pt;\">Adress</span></p></body></html>", Q_NULLPTR));
        label_53->setText(QApplication::translate("MainWindow", "<html><head/><body><p><span style=\" font-size:12pt;\">Function</span></p><p><br/></p></body></html>", Q_NULLPTR));
        label_54->setText(QApplication::translate("MainWindow", "<html><head/><body><p><span style=\" font-size:12pt;\">Login</span></p></body></html>", Q_NULLPTR));
        label_56->setText(QApplication::translate("MainWindow", "<html><head/><body><p><span style=\" font-size:12pt;\">Password</span></p></body></html>", Q_NULLPTR));
        photo_2->setText(QApplication::translate("MainWindow", "ADD Picture ", Q_NULLPTR));
        lbl_image_2->setText(QString());
        tabWidget_2->setTabText(tabWidget_2->indexOf(tab_5), QApplication::translate("MainWindow", "ADD", Q_NULLPTR));
        label_3->setText(QApplication::translate("MainWindow", "Add buyer", Q_NULLPTR));
        valider->setText(QApplication::translate("MainWindow", "Add", Q_NULLPTR));
        inserer_photo->setText(QApplication::translate("MainWindow", "import request", Q_NULLPTR));
        label_26->setText(QApplication::translate("MainWindow", "Mail", Q_NULLPTR));
        label_5->setText(QApplication::translate("MainWindow", "Lastname", Q_NULLPTR));
        label_55->setText(QApplication::translate("MainWindow", "request", Q_NULLPTR));
        label_27->setText(QApplication::translate("MainWindow", "adress", Q_NULLPTR));
        label_52->setText(QApplication::translate("MainWindow", "Num telephone", Q_NULLPTR));
        label_28->setText(QApplication::translate("MainWindow", "ID", Q_NULLPTR));
        label_29->setText(QApplication::translate("MainWindow", "Name", Q_NULLPTR));
        label_30->setText(QApplication::translate("MainWindow", "ID_AG", Q_NULLPTR));
        tabWidget->setTabText(tabWidget->indexOf(tab_3), QApplication::translate("MainWindow", "Add", Q_NULLPTR));
        sort_request_buyer->setText(QApplication::translate("MainWindow", "sort by requsest", Q_NULLPTR));
        sort_name_buyer->setText(QApplication::translate("MainWindow", "sort by name", Q_NULLPTR));
        sort_adress_buyer->setText(QApplication::translate("MainWindow", "sort by adress", Q_NULLPTR));
        rechercher_2->setText(QApplication::translate("MainWindow", "Search", Q_NULLPTR));
        label_31->setText(QApplication::translate("MainWindow", "ID to find", Q_NULLPTR));
        label_32->setText(QApplication::translate("MainWindow", "Name to find", Q_NULLPTR));
        rechercher_3->setText(QApplication::translate("MainWindow", "Search", Q_NULLPTR));
        label_33->setText(QApplication::translate("MainWindow", "request to find ", Q_NULLPTR));
        rechercher_4->setText(QApplication::translate("MainWindow", "Search", Q_NULLPTR));
        sort_id_buyer->setText(QApplication::translate("MainWindow", "sort by id", Q_NULLPTR));
        label_34->setText(QApplication::translate("MainWindow", "ID", Q_NULLPTR));
        label_35->setText(QApplication::translate("MainWindow", "Adress", Q_NULLPTR));
        label_36->setText(QApplication::translate("MainWindow", "Num telephone", Q_NULLPTR));
        label_37->setText(QApplication::translate("MainWindow", "Mail", Q_NULLPTR));
        label_41->setText(QApplication::translate("MainWindow", "Lastname", Q_NULLPTR));
        label_42->setText(QApplication::translate("MainWindow", "Request", Q_NULLPTR));
        label_43->setText(QApplication::translate("MainWindow", "Name", Q_NULLPTR));
        read->setText(QApplication::translate("MainWindow", "Read", Q_NULLPTR));
        pushButton_delete->setText(QApplication::translate("MainWindow", "delete", Q_NULLPTR));
        update->setText(QApplication::translate("MainWindow", "Update", Q_NULLPTR));
        pushButton_13->setText(QApplication::translate("MainWindow", "Read Info", Q_NULLPTR));
        mailling->setText(QApplication::translate("MainWindow", "Mailling", Q_NULLPTR));
        label_44->setText(QApplication::translate("MainWindow", "Recommandation", Q_NULLPTR));
        recommand->setText(QApplication::translate("MainWindow", "recommand", Q_NULLPTR));
        tabWidget->setTabText(tabWidget->indexOf(tab_4), QApplication::translate("MainWindow", "Read", Q_NULLPTR));
        label_2->setText(QApplication::translate("MainWindow", "ID_SEL", Q_NULLPTR));
        pb_Add->setText(QApplication::translate("MainWindow", "Add", Q_NULLPTR));
        label_6->setText(QApplication::translate("MainWindow", "MAIL_SEL", Q_NULLPTR));
        label_7->setText(QApplication::translate("MainWindow", "LASTNAME_SEL", Q_NULLPTR));
        label_8->setText(QApplication::translate("MainWindow", "NAME_SEL", Q_NULLPTR));
        label_9->setText(QApplication::translate("MainWindow", "ADRESS_SEL", Q_NULLPTR));
        label_10->setText(QApplication::translate("MainWindow", "NUM_SEL", Q_NULLPTR));
        generer_pdf->setText(QApplication::translate("MainWindow", "Generate Pdf", Q_NULLPTR));
        tabWidget_4->setTabText(tabWidget_4->indexOf(tab_6), QApplication::translate("MainWindow", "Add ", Q_NULLPTR));
        pb_modif->setText(QApplication::translate("MainWindow", "Modify", Q_NULLPTR));
        pb_supp->setText(QApplication::translate("MainWindow", "Delete ", Q_NULLPTR));
        Sort_by_id->setText(QApplication::translate("MainWindow", "sort by id", Q_NULLPTR));
        Sort_by_name->setText(QApplication::translate("MainWindow", "sort by name", Q_NULLPTR));
        Sort_by_adress->setText(QApplication::translate("MainWindow", "sort by adress", Q_NULLPTR));
        search_id->setText(QApplication::translate("MainWindow", "search", Q_NULLPTR));
        pb_read->setText(QApplication::translate("MainWindow", "read", Q_NULLPTR));
        label_11->setText(QApplication::translate("MainWindow", "ID_SEL", Q_NULLPTR));
        label_12->setText(QApplication::translate("MainWindow", "ID_SEL", Q_NULLPTR));
        label_13->setText(QApplication::translate("MainWindow", "LASTNAME_SEL", Q_NULLPTR));
        label_14->setText(QApplication::translate("MainWindow", "NAME_SEL", Q_NULLPTR));
        label_15->setText(QApplication::translate("MainWindow", "ADRESS_SEL", Q_NULLPTR));
        label_57->setText(QApplication::translate("MainWindow", "NUM_SEL", Q_NULLPTR));
        label_58->setText(QApplication::translate("MainWindow", "MAIL_SEL", Q_NULLPTR));
        label_59->setText(QApplication::translate("MainWindow", "ID_SEL ", Q_NULLPTR));
        search_name->setText(QApplication::translate("MainWindow", "search", Q_NULLPTR));
        search_adress->setText(QApplication::translate("MainWindow", "search", Q_NULLPTR));
        label_60->setText(QApplication::translate("MainWindow", "ID_SEL", Q_NULLPTR));
        label_61->setText(QApplication::translate("MainWindow", "NAME_SEL", Q_NULLPTR));
        label_62->setText(QApplication::translate("MainWindow", "ADRESS_SEL", Q_NULLPTR));
        todo->setText(QApplication::translate("MainWindow", "ToDo", Q_NULLPTR));
        tabWidget_4->setTabText(tabWidget_4->indexOf(tab_2), QApplication::translate("MainWindow", "Display ", Q_NULLPTR));
        textEdit->setHtml(QApplication::translate("MainWindow", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'MS Shell Dlg 2'; font-size:7.8pt; font-weight:400; font-style:normal;\">\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-family:'MS Shell Dlg 2'; font-size:14pt; font-weight:600; color:#ffffff;\">Seller Management </span></p></body></html>", Q_NULLPTR));
        pushButton_security_arduino->setText(QApplication::translate("MainWindow", "Yes", Q_NULLPTR));
        pushButton_security_arduino_2->setText(QApplication::translate("MainWindow", "No", Q_NULLPTR));
        pushButton_28->setText(QApplication::translate("MainWindow", "View IMAGE", Q_NULLPTR));
        label_63->setText(QApplication::translate("MainWindow", "No one Is Detected", Q_NULLPTR));
        label_64->setText(QApplication::translate("MainWindow", "No One is Detected to launch alarm", Q_NULLPTR));
        tabWidget_6->setTabText(tabWidget_6->indexOf(tab_7), QApplication::translate("MainWindow", "Security", Q_NULLPTR));
        groupBox_3->setTitle(QApplication::translate("MainWindow", "Property ", Q_NULLPTR));
        label_65->setText(QApplication::translate("MainWindow", "Property price", Q_NULLPTR));
        label_66->setText(QApplication::translate("MainWindow", "longitude", Q_NULLPTR));
        label_67->setText(QApplication::translate("MainWindow", "latitude", Q_NULLPTR));
        label_68->setText(QApplication::translate("MainWindow", "Property Type", Q_NULLPTR));
        label_69->setText(QApplication::translate("MainWindow", "Id_maison", Q_NULLPTR));
        pushButton_29->setText(QApplication::translate("MainWindow", "Add Video", Q_NULLPTR));
        pushButton_30->setText(QApplication::translate("MainWindow", "Add Image", Q_NULLPTR));
        pushButton_database_insert->setText(QApplication::translate("MainWindow", "InsertingtoDatabase", Q_NULLPTR));
        pushButton_delete_prop->setText(QApplication::translate("MainWindow", "Delete Property", Q_NULLPTR));
        update_prop->setText(QApplication::translate("MainWindow", "update", Q_NULLPTR));
        label_70->setText(QApplication::translate("MainWindow", "buyer", Q_NULLPTR));
        label_71->setText(QApplication::translate("MainWindow", "seller", Q_NULLPTR));
        label_72->setText(QApplication::translate("MainWindow", "Search by ID", Q_NULLPTR));
        label_73->setText(QApplication::translate("MainWindow", "Search by Type", Q_NULLPTR));
        label_74->setText(QApplication::translate("MainWindow", "Search by exact Price", Q_NULLPTR));
        pushButton_31->setText(QApplication::translate("MainWindow", "Search", Q_NULLPTR));
        pushButton_32->setText(QApplication::translate("MainWindow", "Search", Q_NULLPTR));
        pushButton_33->setText(QApplication::translate("MainWindow", "Search", Q_NULLPTR));
        pushButton_34->setText(QApplication::translate("MainWindow", "Sort by ID", Q_NULLPTR));
        pushButton_35->setText(QApplication::translate("MainWindow", "Sort by Type", Q_NULLPTR));
        pushButton_36->setText(QApplication::translate("MainWindow", "Sort by Price", Q_NULLPTR));
        label_75->setText(QApplication::translate("MainWindow", "House Description :", Q_NULLPTR));
        pushButton_5->setText(QApplication::translate("MainWindow", "Empty", Q_NULLPTR));
        pushButton_37->setText(QApplication::translate("MainWindow", "Pause Video", Q_NULLPTR));
        pushButton_38->setText(QApplication::translate("MainWindow", "Play Video", Q_NULLPTR));
        tabWidget_6->setTabText(tabWidget_6->indexOf(tab_15), QApplication::translate("MainWindow", "Add Property", Q_NULLPTR));
        chat->setText(QApplication::translate("MainWindow", "send message", Q_NULLPTR));
        pushButton_24->setText(QApplication::translate("MainWindow", "Previous page", Q_NULLPTR));
        combo->setText(QApplication::translate("MainWindow", "send message", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
