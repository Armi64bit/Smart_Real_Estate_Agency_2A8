#include "mainwindow.h"
#include "login.h"
#include "connection.h"
#include <QApplication>
#include <QMessageBox>
#include <QFile>


int main(int argc, char *argv[])
{
    QApplication a(argc, argv);

    Connection c;
    bool test=c.createconnect();
    QFile styleSheetFile("Incrypt.qss");
        styleSheetFile.open(QFile::ReadOnly);
        QString styleSheet= QLatin1String(styleSheetFile.readAll());
        a.setStyleSheet(styleSheet);


    MainWindow w;
    login t;

    if(test)
    {t.show();
        QMessageBox::information(nullptr, QObject::tr("database is open"),
                    QObject::tr("connection successful.\n"
                                "Click Cancel to exit."), QMessageBox::Cancel);

}
    else
        QMessageBox::critical(nullptr, QObject::tr("database is not open"),
                    QObject::tr("connection failed.\n"
                                "Click Cancel to exit."), QMessageBox::Cancel);
    return a.exec();
}
