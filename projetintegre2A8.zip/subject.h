#ifndef SUBJECT_H
#define SUBJECT_H


class subject
{
public:
    subject();
};

#endif // SUBJECT_H